# Herramientas para la monitorización y análisis de procesos de modelado 3D en Blender
# Copyright (C) 2026 María Molina Goyena
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# at your option any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.

"""Private dependency management for the classic Ize Insights add-on.

Checks are cached and run in Blender's current Python process.  No child
process is created during normal panel redraws.  Installation only runs after
the user presses the dependency installation button.
"""
from __future__ import annotations

import importlib
import importlib.machinery
import os
import shutil
import subprocess
import sys
import platform
import uuid
from functools import lru_cache
from pathlib import Path
from typing import Iterable

ADDON_DIR = Path(__file__).resolve().parent
REQUIREMENTS_FILE = ADDON_DIR / "requirements.txt"
REQUIRED_MODULES = ("numpy", "matplotlib")
SITE_PACKAGES_DIR = ADDON_DIR / "site-packages"
INSTALL_STATE_FILE = ADDON_DIR / "_install_state.txt"
INSTALL_MARKER_FILE = SITE_PACKAGES_DIR / ".ize_insights_install_id"
FRESH_INSTALL_SENTINEL = "FRESH"


def _legacy_external_site_packages(addon_dir: Path = ADDON_DIR) -> Path:
    """Return the dependency cache used by older Ize Insights builds."""
    base = Path(addon_dir).resolve()
    parent = base.parent
    scripts_root = parent.parent if parent.name.lower() in {"addons", "addons_core"} else parent
    py_tag = f"py{sys.version_info.major}{sys.version_info.minor}"
    return scripts_root / "modules" / f"Ize_Insights_deps_{py_tag}" / "site-packages"


LEGACY_EXTERNAL_SITE_PACKAGES_DIR = _legacy_external_site_packages()


def _read_installation_id() -> str:
    try:
        value = INSTALL_STATE_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        value = ""
    return value


def _write_installation_id(value: str) -> None:
    INSTALL_STATE_FILE.write_text(str(value).strip(), encoding="utf-8")


def _best_effort_remove(path: Path) -> bool:
    if not path.exists():
        return True
    try:
        shutil.rmtree(path)
        return True
    except Exception:
        return False


def prepare_addon_installation() -> str:
    """Initialize one physical add-on installation.

    The distributed ZIP always contains ``_install_state.txt`` with ``FRESH``.
    Therefore installing the ZIP again resets this state even when the same ZIP
    is used.  On first registration we discard dependencies from any older
    installation and assign a new installation id. Dependencies are accepted
    only when their marker matches this id.
    """
    current = _read_installation_id()
    if current and current != FRESH_INSTALL_SENTINEL:
        return current

    new_id = uuid.uuid4().hex
    _best_effort_remove(SITE_PACKAGES_DIR)

    # Remove the cache used by previous releases. It is never used again.
    external = LEGACY_EXTERNAL_SITE_PACKAGES_DIR
    _best_effort_remove(external)
    try:
        parent = external.parent
        if parent.is_dir() and not any(parent.iterdir()):
            parent.rmdir()
    except Exception:
        pass

    _write_installation_id(new_id)
    invalidate_dependency_cache()
    return new_id


def _dependencies_belong_to_current_installation() -> bool:
    current = _read_installation_id()
    if not current or current == FRESH_INSTALL_SENTINEL:
        return False
    try:
        marker = INSTALL_MARKER_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return False
    return marker == current


def add_local_site_packages(addon_dir: str | os.PathLike[str] | None = None) -> None:
    """Place dependencies for this installation at the front of ``sys.path``."""
    del addon_dir  # Dependencies intentionally live only inside this add-on.
    private_dir = SITE_PACKAGES_DIR
    private_path = str(private_dir)

    cleaned: list[str] = []
    current_norm = os.path.normcase(os.path.abspath(private_path))
    for entry in list(sys.path):
        try:
            normalized = os.path.normcase(os.path.abspath(entry))
        except Exception:
            cleaned.append(entry)
            continue
        lowered = normalized.lower().replace("\\", "/")
        if lowered.endswith("/site-packages") and normalized != current_norm:
            if "ize_insights" in lowered or "analysis3d" in lowered:
                continue
        cleaned.append(entry)
    sys.path[:] = cleaned

    if private_dir.is_dir() and _dependencies_belong_to_current_installation():
        if private_path in sys.path:
            sys.path.remove(private_path)
        sys.path.insert(0, private_path)


def _is_inside_private_site_packages(module_file: str | None) -> bool:
    """Return True only when a module was loaded from this add-on's private folder."""
    if not module_file:
        return False
    try:
        module_path = Path(module_file).resolve()
        private_path = SITE_PACKAGES_DIR.resolve()
        return module_path == private_path or private_path in module_path.parents
    except Exception:
        return False


@lru_cache(maxsize=8)
def _cached_dependency_diagnostics(modules: tuple[str, ...]) -> tuple[tuple[str, str], ...]:
    """Check whether dependencies exist in this add-on's private folder.

    This deliberately does not import the modules. NumPy may already be loaded
    globally by Blender or another add-on; importing it again would return that
    cached global module and incorrectly report that the private installation
    failed.
    """
    if not SITE_PACKAGES_DIR.is_dir() or not _dependencies_belong_to_current_installation():
        return tuple((module, "Not installed for this Ize Insights installation") for module in modules)

    private_search_path = [str(SITE_PACKAGES_DIR)]
    diagnostics: list[tuple[str, str]] = []
    for module in modules:
        try:
            spec = importlib.machinery.PathFinder.find_spec(module, private_search_path)
        except Exception as exc:
            diagnostics.append((module, f"{type(exc).__name__}: {exc}"))
            continue
        if spec is None or not spec.origin:
            diagnostics.append(
                (module, "Not installed in the add-on private site-packages folder")
            )
    return tuple(diagnostics)


def invalidate_dependency_cache() -> None:
    _cached_dependency_diagnostics.cache_clear()


def dependency_diagnostics(
    modules: Iterable[str] = REQUIRED_MODULES, *, force: bool = False
) -> dict[str, str]:
    normalized = tuple(str(module) for module in modules)
    if force:
        invalidate_dependency_cache()
    return dict(_cached_dependency_diagnostics(normalized))


def missing_dependencies(
    modules: Iterable[str] = REQUIRED_MODULES, *, force: bool = False
) -> list[str]:
    return list(dependency_diagnostics(modules, force=force).keys())


def dependencies_available(*, force: bool = False) -> bool:
    return not missing_dependencies(force=force)


def ensure_modules(modules: Iterable[str], *, install: bool = False) -> list[str]:
    missing = missing_dependencies(modules)
    if install and missing:
        install_dependencies()
        return missing_dependencies(modules, force=True)
    return missing


def _run(command: list[str]) -> None:
    completed = subprocess.run(command, text=True, capture_output=True, check=False)
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout or "Command failed").strip()
        raise RuntimeError(detail[-5000:])


def _bundled_python_executable() -> str | None:
    """Return Blender's bundled standalone Python executable when available."""
    candidates = []
    for prefix in (Path(sys.prefix), Path(sys.base_prefix)):
        candidates.extend(
            [
                prefix / "bin" / "python.exe",
                prefix / "python.exe",
                prefix / "bin" / "python3.13.exe",
                prefix / "bin" / "python3.11.exe",
                prefix / "bin" / "python3.exe",
            ]
        )

    executable = Path(sys.executable)
    if executable.name.lower().startswith("python"):
        candidates.insert(0, executable)

    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate).lower()
        if key in seen:
            continue
        seen.add(key)
        if candidate.is_file():
            return str(candidate)
    return None


def _validate_python_313_runtime() -> None:
    """Require the runtime this distribution was built for."""
    py = sys.version_info[:2]
    machine = platform.machine().lower()
    is_x64 = machine in {"amd64", "x86_64", "x64"}
    if sys.platform != "win32" or py != (3, 13) or not is_x64:
        raise RuntimeError(
            "Esta edición de Ize Insights requiere Windows x64 + Python 3.13. "
            f"Este Blender informa: plataforma={sys.platform}, Python={py[0]}.{py[1]}, "
            f"arquitectura={platform.machine()}."
        )


def _ensure_pip(python_exe: str) -> None:
    """Ensure pip is available in Blender's bundled Python."""
    check = subprocess.run(
        [python_exe, "-m", "pip", "--version"],
        text=True, capture_output=True, check=False,
    )
    if check.returncode == 0:
        return
    bootstrap = subprocess.run(
        [python_exe, "-m", "ensurepip", "--upgrade"],
        text=True, capture_output=True, check=False,
    )
    if bootstrap.returncode != 0:
        detail = (bootstrap.stderr or bootstrap.stdout or "ensurepip failed").strip()
        raise RuntimeError(detail[-5000:])


def _install_python313_dependencies() -> None:
    """Download CPython 3.13 binary wheels from PyPI into this installation."""
    _validate_python_313_runtime()
    python_exe = _bundled_python_executable()
    if not python_exe:
        raise RuntimeError("No se encontró el ejecutable de Python incluido con Blender.")
    _ensure_pip(python_exe)
    command = [
        python_exe, "-m", "pip", "install",
        "--disable-pip-version-check",
        "--no-cache-dir",
        "--only-binary=:all:",
        "--upgrade",
        "--target", str(SITE_PACKAGES_DIR),
        "-r", str(REQUIREMENTS_FILE),
    ]
    _run(command)


def _remove_private_dependencies() -> None:
    if SITE_PACKAGES_DIR.exists():
        try:
            shutil.rmtree(SITE_PACKAGES_DIR)
        except Exception as exc:
            raise RuntimeError(
                "No se pudo reemplazar la carpeta privada de dependencias. "
                "Cierra las demás ventanas de Blender y vuelve a intentarlo. "
                f"Error original: {exc}"
            ) from exc


def _cleanup_legacy_private_dependencies() -> None:
    """Remove the external cache used by older releases; never reuse it."""
    _best_effort_remove(LEGACY_EXTERNAL_SITE_PACKAGES_DIR)


def _verify_private_imports(modules: Iterable[str] = REQUIRED_MODULES) -> None:
    """Verify dependencies with Blender's bundled standalone Python when possible."""
    python_exe = _bundled_python_executable()
    if not python_exe:
        # Structural dependency_diagnostics() already confirmed that the modules
        # exist. Blender will load the compiled modules after the requested restart.
        return

    module_list = tuple(str(name) for name in modules)
    script = f"""
import pathlib
import sys
private = pathlib.Path({str(SITE_PACKAGES_DIR)!r}).resolve()
sys.path.insert(0, str(private))
names = {module_list!r}
bad = []
for name in names:
    try:
        mod = __import__(name)
        origin = pathlib.Path(getattr(mod, '__file__', '')).resolve()
        if private != origin and private not in origin.parents:
            bad.append(f"{{name}}: loaded from {{origin}}")
    except Exception as exc:
        bad.append(f"{{name}}: {{type(exc).__name__}}: {{exc}}")
if bad:
    raise SystemExit("\\n".join(bad))
"""
    completed = subprocess.run(
        [python_exe, "-S", "-c", script],
        text=True,
        capture_output=True,
        check=False,
    )
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout or "Private import verification failed").strip()
        raise RuntimeError(detail[-5000:])

def install_dependencies() -> None:
    """Install Python 3.13 dependencies for this concrete add-on installation."""
    installation_id = prepare_addon_installation()
    _cleanup_legacy_private_dependencies()
    _remove_private_dependencies()
    SITE_PACKAGES_DIR.mkdir(parents=True, exist_ok=True)

    try:
        _install_python313_dependencies()
    except Exception:
        # Do not leave a half-installed private environment behind.
        try:
            shutil.rmtree(SITE_PACKAGES_DIR)
        except Exception:
            pass
        SITE_PACKAGES_DIR.mkdir(parents=True, exist_ok=True)
        raise

    INSTALL_MARKER_FILE.write_text(installation_id, encoding="utf-8")
    importlib.invalidate_caches()
    invalidate_dependency_cache()
    diagnostics = dependency_diagnostics(force=True)
    if diagnostics:
        detail = "\n\n".join(f"{name}: {error}" for name, error in diagnostics.items())
        raise RuntimeError("Dependency verification failed / Falló la verificación:\n" + detail)

    _verify_private_imports()
    add_local_site_packages()


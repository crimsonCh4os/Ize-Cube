# Herramientas para la monitorización y análisis de procesos de modelado 3D en Blender
# Copyright (C) 2026 María Molina Goyena
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# at your option any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.

"""Lógica analítica pura para CSVs de interacción.

Este módulo no depende de Blender UI ni registra clases/paneles. Está diseñado
para poder probarse con unittest/pytest fuera de la capa de presentación.
"""
from __future__ import annotations
from .texts import UI_TEXT

import logging
import re
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping, Sequence

import numpy as np

try:  # Blender runtime
    from mathutils import Vector as _BlenderVector
except Exception:  # CPython tests
    _BlenderVector = None

from .constants import DEFAULT_BREAK_SPEED, DEFAULT_MAX_REASONABLE_SPEED

logger = logging.getLogger(__name__)
ReportFn = Callable[[set[str], str], None]


@dataclass(frozen=True)
class _Vec3:
    x: float
    y: float
    z: float

    def __sub__(self, other: "_Vec3") -> "_Vec3":
        return _Vec3(self.x - other.x, self.y - other.y, self.z - other.z)

    @property
    def length(self) -> float:
        return float((self.x ** 2 + self.y ** 2 + self.z ** 2) ** 0.5)


def _vector3(values: Sequence[float]):
    if _BlenderVector is not None:
        return _BlenderVector(values)
    return _Vec3(float(values[0]), float(values[1]), float(values[2]))

ANALYSIS = {
    # Order and categories follow "Datos y categorias.xlsx".
    "A1":  {"label": UI_TEXT['SESSION_DURATION'],      "typology": UI_TEXT['TEMPORAL_ACTIVITY']},
    "A2":  {"label": UI_TEXT['PAUSES'],                "typology": UI_TEXT['TEMPORAL_ACTIVITY']},
    "A4":  {"label": UI_TEXT['VIEW_SPEED'],            "typology": UI_TEXT['VIEW_NAVIGATION']},
    "A5":  {"label": UI_TEXT['DISTANCE_TO_OBJECT'],    "typology": UI_TEXT['VIEW_NAVIGATION']},
    "A6":  {"label": UI_TEXT['VIEW_MOVEMENT_PEAKS'],  "typology": UI_TEXT['VIEW_NAVIGATION']},
    "A17": {"label": UI_TEXT['OCCLUSION'],             "typology": UI_TEXT['VIEW_NAVIGATION']},
    "A19": {"label": UI_TEXT['ORTHOGRAPHIC_VIEW'],     "typology": UI_TEXT['VIEW_NAVIGATION']},
    "A12": {"label": UI_TEXT['VERTEX_CHANGES'],        "typology": UI_TEXT['MODEL_EVOLUTION']},
    "A13": {"label": UI_TEXT['MESH_ISSUE_CHANGES'],    "typology": UI_TEXT['MODEL_EVOLUTION']},
    "A16": {"label": UI_TEXT['OBJECT_CHANGES'],        "typology": UI_TEXT['MODEL_EVOLUTION']},
    "A14": {"label": UI_TEXT['WORK_MODE'],             "typology": UI_TEXT['TOOLS_ACTIONS']},
    "A10": {"label": UI_TEXT['SHORTCUT_REUSE'],        "typology": UI_TEXT['TOOLS_ACTIONS']},
    "A11": {"label": UI_TEXT['MODIFIER_CHANGES'],      "typology": UI_TEXT['TOOLS_ACTIONS']},
    "A15": {"label": UI_TEXT['UV_WORK'],               "typology": UI_TEXT['TOOLS_ACTIONS']},
    "A18": {"label": UI_TEXT['UNDO_ACTIONS'],          "typology": UI_TEXT['TOOLS_ACTIONS']},
}


def safe_float(row: Mapping[str, Any], key: str, default: float = 0.0, report: ReportFn | None = None) -> float:
    try:
        raw = row.get(key, default)
        if raw in (None, "", "None"):
            return default
        return float(raw)
    except (ValueError, TypeError) as exc:
        msg = f"[safe_float] No se pudo convertir '{key}': {exc}"
        logger.warning(msg)
        if report is not None:
            report({"ERROR"}, msg)
        return default


def sanitize_name(value: Any) -> str:
    return re.sub(r"[^A-Za-z0-9_\-]+", "_", str(value or "item"))


def series_to_array(values: Iterable[Any] | None) -> np.ndarray:
    if values is None:
        return np.asarray([], dtype=float)
    arr = np.asarray(list(values), dtype=float)
    return arr[np.isfinite(arr)] if arr.size else arr


def clamp_outliers(values: Iterable[Any] | None) -> np.ndarray:
    """Clamp outliers with a simple IQR rule, preserving the original sample count.

    G1 uses this to keep interaction curves readable when a CSV contains a few
    extreme spikes. Values are clipped to the Tukey fences instead of removed,
    so X/Y arrays stay aligned and no UI option is needed.
    """
    arr = series_to_array(values)
    if arr.size < 4:
        return arr

    q1, q3 = np.percentile(arr, [25.0, 75.0])
    iqr = q3 - q1
    if not np.isfinite(q1) or not np.isfinite(q3) or not np.isfinite(iqr) or iqr <= 0:
        return arr

    low = q1 - 1.5 * iqr
    high = q3 + 1.5 * iqr
    if low >= high:
        return arr
    return np.clip(arr, low, high)


def _csv_float(row: Mapping[str, Any], *keys: str, default: float = 0.0, report: ReportFn | None = None) -> float:
    """Lee un número aceptando varios nombres de columna y encabezados con espacios/BOM."""
    if not hasattr(row, "items"):
        return default
    normalized = {str(k).strip().lstrip("\ufeff").lower(): v for k, v in row.items()}
    for key in keys:
        norm_key = str(key).strip().lstrip("\ufeff").lower()
        if norm_key in normalized and normalized.get(norm_key) not in (None, ""):
            try:
                return float(str(normalized.get(norm_key)).strip().replace(",", "."))
            except (ValueError, TypeError) as exc:
                msg = f"[_csv_float] No se pudo convertir '{key}': {exc}"
                logger.warning(msg)
                if report is not None:
                    report({"ERROR"}, msg)
    return default



def _csv_has_value(row: Mapping[str, Any], *keys: str) -> bool:
    """True when at least one alias exists and contains a non-empty value."""
    if not hasattr(row, "items"):
        return False
    normalized = {str(k).strip().lstrip("\ufeff").lower(): v for k, v in row.items()}
    for key in keys:
        value = normalized.get(str(key).strip().lstrip("\ufeff").lower(), None)
        if value not in (None, "", "None"):
            return True
    return False


def _signed_change(
    row: Mapping[str, Any],
    delta_keys: Sequence[str],
    created_keys: Sequence[str],
    deleted_keys: Sequence[str],
) -> float:
    """Read a signed change, preferring explicit created/deleted counters.

    Recent logger schemas expose both components. Using them prevents a stale or
    missing *Delta field from making object/modifier changes disappear. Legacy
    CSVs continue to fall back to the signed delta column.
    """
    if _csv_has_value(row, *created_keys) or _csv_has_value(row, *deleted_keys):
        created = _csv_float(row, *created_keys, default=0.0)
        deleted = _csv_float(row, *deleted_keys, default=0.0)
        return created - deleted
    return _csv_float(row, *delta_keys, default=0.0)

def _row_time(row: Mapping[str, Any]) -> float:
    ts = _csv_float(row, "TimeStamp", "Timestamp", "timestamp", default=None)

    if ts is not None:
        # Detecta timestamps UNIX en milisegundos
        if ts > 1e12:
            ts /= 1000.0

        # Detecta timestamps UNIX absolutos
        if ts > 1e9:
            return ts

        return ts

    minute = _csv_float(row, "Minute", "Minutes", default=0.0)
    second = _csv_float(row, "Second", "Seconds", default=0.0)

    return minute * 60.0 + second


def _row_edit_event(row: Mapping[str, Any]) -> float:
    """Active de edición/modelado registrada en la fila."""
    keys = (
        "VertexDelta", "NgonDelta", "TriDelta", "NormalDelta", "NonManifoldDelta",
        "ObjectDelta", "ObjectTransform", "ObjDeltaX", "ObjDeltaY", "ObjDeltaZ", "ObjDeltaRadius",
        "ModifierDelta", "Duplicate", "Instance", "CtrlV", "ShiftD", "AltD", "Merge",
        "UVDeploy", "UVAction", "UV", "ModeChanged"
    )
    return sum(abs(_csv_float(row, k, default=0.0)) for k in keys)


def _row_object_local_size(row: Mapping[str, Any]) -> float:
    """Devuelve el tamaño local del objeto en unidades del CSV.

    Se aceptan varios nombres habituales de columna. La prioridad es:
    dimensiones locales X/Y/Z, escala local X/Y/Z, tamaño escalar y radio.
    Si solo hay radio, se informa diámetro local.
    """
    dim_x = _csv_float(row, "ObjDimX", "ObjDimensionX", "ObjectDimX", "ObjectDimensionX", "ObjSizeX", "ObjectSizeX", default=0.0)
    dim_y = _csv_float(row, "ObjDimY", "ObjDimensionY", "ObjectDimY", "ObjectDimensionY", "ObjSizeY", "ObjectSizeY", default=0.0)
    dim_z = _csv_float(row, "ObjDimZ", "ObjDimensionZ", "ObjectDimZ", "ObjectDimensionZ", "ObjSizeZ", "ObjectSizeZ", default=0.0)
    dims = [abs(v) for v in (dim_x, dim_y, dim_z) if abs(v) > 0.0]
    if dims:
        return float(max(dims))

    scale_x = _csv_float(row, "ObjScaleX", "ObjectScaleX", "LocalScaleX", "ScaleX", default=0.0)
    scale_y = _csv_float(row, "ObjScaleY", "ObjectScaleY", "LocalScaleY", "ScaleY", default=0.0)
    scale_z = _csv_float(row, "ObjScaleZ", "ObjectScaleZ", "LocalScaleZ", "ScaleZ", default=0.0)
    scales = [abs(v) for v in (scale_x, scale_y, scale_z) if abs(v) > 0.0]
    if scales:
        return float(max(scales))

    size = _csv_float(row, "ObjSize", "ObjectSize", "LocalSize", "BoundingBoxSize", default=0.0)
    if abs(size) > 0.0:
        return abs(size)

    radius = _csv_float(row, "ObjRadius", "ObjectRadius", "SceneRadius", default=0.0)
    return abs(radius) * 2.0 if abs(radius) > 0.0 else 0.0



def _compute_metrics_for_single_session(data: Sequence[Mapping[str, Any]], BREAK_SPEED: float = DEFAULT_BREAK_SPEED, max_reasonable_speed: float = DEFAULT_MAX_REASONABLE_SPEED) -> dict[str, list[float]]:
    """
    Calcula las métricas del botón 'Calculate CSV Metric Stats' para CSVs con columnas:
    TimeStamp/Minute/Second, UserX/Y/Z, ObjX/Y/Z, ObjRadius, dimensiones/escala local, *Delta, ObjModeState/EditModeState, etc.
    No toca el operador 'Calculate Metrics' de mallas.
    """
    metrics = {mid: [] for mid in ANALYSIS.keys()}
    if not data:
        return metrics

    times_abs = [_row_time(row) for row in data]
    first_time = times_abs[0]
    elapsed = [max(t - first_time, 0.0) for t in times_abs]
    total_time = elapsed[-1] if elapsed else 0.0

    positions = [_vector3((
        _csv_float(row, "UserX", "X"),
        _csv_float(row, "UserY", "Y"),
        _csv_float(row, "UserZ", "Z")
    )) for row in data]
    obj_positions = [_vector3((
        _csv_float(row, "ObjX"),
        _csv_float(row, "ObjY"),
        _csv_float(row, "ObjZ")
    )) for row in data]

    dts = [0.0]
    distances = [0.0]
    speeds = [0.0]
    for i in range(1, len(data)):
        dt = max(times_abs[i] - times_abs[i-1], 0.0)
        dist = (positions[i] - positions[i-1]).length
        dts.append(dt)
        distances.append(dist)
        speed = dist / dt if dt > 0 else 0.0

        # Filtra glitches absurdos
        if speed > float(max_reasonable_speed):
            speed = 0.0

        speeds.append(speed)

    positive_dts = [dt for dt in dts[1:] if dt > 0]
    # A2: parada larga = intervalo temporal por encima de media + 2 desviaciones típicas.
    pause_threshold = float(np.mean(positive_dts) + 2.0 * np.std(positive_dts)) if positive_dts else 0.0

    positive_speeds = [v for v in speeds[1:] if v > 0]
    # A6-A9: peaks espaciales = velocidad por encima de media + 2 desviaciones típicas.
    speed_threshold = float(np.mean(positive_speeds) + 2.0 * np.std(positive_speeds)) if positive_speeds else 0.0

    # A1: serie de tiempo transcurrido en minutos; la vista de detalle usa el último valor.
    metrics["A1"] = [t / 60.0 for t in elapsed]

    # A2: pausas largas sin events de edición; duración de cada pausa, 0 si no es pausa.
    # Si el CSV tiene saltos grandes de tiempo, esto los detecta aunque la posición cambie poco.
    metrics["A2"] = [0.0]
    for i in range(1, len(data)):
        no_edit = _row_edit_event(data[i]) <= 0.0
        is_pause = dts[i] >= pause_threshold and no_edit
        metrics["A2"].append((dts[i] / 60.0) if is_pause else 0.0)

    # Espaciales. Vertex/Mesh issue series are reconstructed as cumulative
    # net state relative to the beginning of each session. The CSV stores deltas,
    # not absolute initial counts, so 0 means "session baseline" rather than an
    # absolute mesh count.

    for i, row in enumerate(data):
        local_size = _row_object_local_size(row)
        local_radius = local_size * 0.5 if local_size > 0.0 else 0.0
        dist_to_obj = max((positions[i] - obj_positions[i]).length - local_radius, 0.0)
        speed_m_per_min = speeds[i] * 60.0
        is_speed_peak = 1.0 if speed_threshold > 0 and speeds[i] >= speed_threshold else 0.0
        metrics["A4"].append(speed_m_per_min)
        metrics["A5"].append(dist_to_obj)
        metrics["A6"].append(is_speed_peak)

        # A10: duplication/instancing actions per row. Ctrl+V and Shift+D are
        # both semantic duplicates; Alt+D is instancing. If a future logger
        # writes Duplicate/Instance directly those columns take precedence.
        duplicate = abs(_csv_float(row, "Duplicate", "DuplicateAction", default=0.0))
        if not _csv_has_value(row, "Duplicate", "DuplicateAction"):
            duplicate = max(
                abs(_csv_float(row, "CtrlV", "ControlV", "Ctrl_V", "Ctrl+V")),
                abs(_csv_float(row, "ShiftD", "Shift_D", "Shift+D")),
            )
        instance = abs(_csv_float(row, "Instance", "InstanceAction", default=0.0))
        if not _csv_has_value(row, "Instance", "InstanceAction"):
            instance = abs(_csv_float(row, "AltD", "Alt_D", "Alt+D"))
        metrics["A10"].append(duplicate + instance)

        # A11: signed modifier balance per row.
        # Positive = created, negative = deleted. Explicit component columns are
        # preferred because some logger builds leave ModifierDelta stale/empty.
        metrics["A11"].append(_signed_change(
            row,
            ("ModifierDelta", "Modifier", "Modifier actionsDelta", "Modifier actions"),
            ("ModifierCreated", "ModifiersCreated"),
            ("ModifierDeleted", "ModifiersDeleted"),
        ))

        # A12: signed vertex balance per row.
        # Net result = sum of additions and removals.
        metrics["A12"].append(
            _csv_float(row, "VertexDelta", "VerticesDelta", "VertDelta", "Vertex")
        )

        # A13: signed mesh-issue balance per row.
        # Positive adds issues; negative removes/fixes them.
        metrics["A13"].append(
            _csv_float(row, "NgonDelta", "NGonDelta", "NgonsDelta")
            + _csv_float(row, "TriDelta", "TriangleDelta", "TrianglesDelta")
            + _csv_float(row, "NormalDelta", "NormalsDelta")
            + _csv_float(row, "NonManifoldDelta", "NonmanifoldDelta", "NonManifold", "Nonmanifold")
        )
        # A14: modo de trabajo. Columnas reales: ObjModeState/EditModeState.
        obj_mode = _csv_float(row, "ObjModeState", "ObjMode")
        edit_mode = _csv_float(row, "EditModeState", "EditMode")
        if edit_mode > 0:
            metrics["A14"].append(2.0)
        elif obj_mode > 0:
            metrics["A14"].append(1.0)
        else:
            metrics["A14"].append(0.0)
        # A15: UV unwrap/deploy only. New logger files expose UVDeploy directly.
        # Legacy files without UVDeploy fall back to the old generic UV flag.
        if "UVDeploy" in row:
            uv_deploy = int(abs(_csv_float(row, "UVDeploy")) > 0.0)
        else:
            uv_deploy = int(abs(_csv_float(row, "UVAction", "UV", "UVDelta", "UvDelta", "UVWork", "UVState")) > 0.0)
        metrics["A15"].append(float(uv_deploy))

        # A16: signed object balance per row.
        # Positive = created, negative = deleted.
        metrics["A16"].append(_signed_change(
            row,
            ("ObjectDelta", "ObjectsDelta"),
            ("ObjectCreated", "ObjectsCreated"),
            ("ObjectDeleted", "ObjectsDeleted"),
        ))

        # A17: 0/1 see-through state (X-Ray or Wireframe).
        metrics["A17"].append(
            1.0 if abs(_csv_float(row, "Occlusion", "OcclusionState", "Occluded")) > 0.0 else 0.0
        )

        # A18: completed Undo actions.
        metrics["A18"].append(
            1.0 if abs(_csv_float(row, "Undo", "UndoAction")) > 0.0 else 0.0
        )

        # A19: 0/1 orthographic viewport state.
        metrics["A19"].append(
            1.0 if abs(_csv_float(row, "Orthographic", "OrthoState", "OrthographicState")) > 0.0 else 0.0
        )


    return metrics


def _csv_session_key(row: Mapping[str, Any], fallback_index: int = 0) -> str:
    """Return a stable session key used to keep grouped CSV files independent."""
    for key in ("SessionID", "SessionId", "session_id", "UserID", "UserId", "user_id"):
        value = row.get(key)
        if value not in (None, ""):
            return str(value)
    return "__default_session"


def compute_metrics_for_csv(
    data: Sequence[Mapping[str, Any]],
    BREAK_SPEED: float = DEFAULT_BREAK_SPEED,
    max_reasonable_speed: float = DEFAULT_MAX_REASONABLE_SPEED,
) -> dict[str, list[float]]:
    """Compute metrics while treating every CSV/session as an independent run.

    CSV groups are materialized as one virtual CSV, but their rows retain a
    distinct SessionID.  This wrapper computes each session independently, so
    the last row of one source file is never compared with the first row of the
    next one.  Metric series are then pooled into one result.  A1 (elapsed time)
    is offset cumulatively so the grouped source has the sum of all durations.
    Downstream means, medians, totals and graph statistics therefore operate on
    all observations from all member CSV files as one grouped source.
    """
    metrics = {mid: [] for mid in ANALYSIS.keys()}
    if not data:
        return metrics

    sessions: list[list[Mapping[str, Any]]] = []
    current: list[Mapping[str, Any]] = []
    current_key: str | None = None
    previous_time: float | None = None

    for index, row in enumerate(data):
        key = _csv_session_key(row, index)
        row_time = _row_time(row)
        new_session = (
            current
            and (key != current_key or (previous_time is not None and row_time < previous_time))
        )
        if new_session:
            sessions.append(current)
            current = []
        current.append(row)
        current_key = key
        previous_time = row_time

    if current:
        sessions.append(current)

    elapsed_offset_minutes = 0.0
    for session_rows in sessions:
        session_metrics = _compute_metrics_for_single_session(
            session_rows,
            BREAK_SPEED=BREAK_SPEED,
            max_reasonable_speed=max_reasonable_speed,
        )
        for metric_id, values in session_metrics.items():
            if metric_id == "A1":
                adjusted = [float(value) + elapsed_offset_minutes for value in values]
                metrics[metric_id].extend(adjusted)
                if values:
                    elapsed_offset_minutes = adjusted[-1]
            else:
                metrics[metric_id].extend(values)

    return metrics

def summarize_csv_metrics_for_correlation(
    metrics: Mapping[str, Iterable[Any]],
) -> dict[str, float]:
    """Return one representative numeric value for each CSV analysis metric.

    The summary follows the same semantics used by the CSV metric-statistics and
    radar views: duration uses the last elapsed value, event metrics use counts,
    speed/distance use means, and accumulated change metrics use absolute sums.
    The result is intentionally pure Python/NumPy so it can be tested outside
    Blender and correlated across multiple CSV/model pairs.
    """
    result: dict[str, float] = {}
    for metric_key in ANALYSIS:
        values = series_to_array(metrics.get(metric_key, []))
        if values.size == 0:
            result[metric_key] = float("nan")
            continue

        if metric_key == "A1":
            value = float(values[-1])
        elif metric_key in {"A2", "A3", "A6", "A7", "A8", "A9"}:
            value = float(np.sum(values > 0.0))
        elif metric_key in {"A4", "A5", "A14"}:
            value = float(np.mean(values))
        elif metric_key in {"A17", "A19"}:
            value = float(np.mean(values))
        elif metric_key in {"A10", "A11", "A12", "A13", "A15", "A16", "A18"}:
            value = float(np.sum(np.abs(values)))
        else:
            value = float(np.mean(values))

        result[metric_key] = value if np.isfinite(value) else float("nan")
    return result


def _numeric_value(value: Any) -> float:
    """Convert Blender/Python scalar values to finite floats for correlation."""
    if isinstance(value, bool):
        return float(int(value))
    try:
        number = float(value)
    except (TypeError, ValueError):
        return float("nan")
    return number if np.isfinite(number) else float("nan")


def pearson_cross_correlation(
    csv_rows: Sequence[Mapping[str, Any]],
    model_rows: Sequence[Mapping[str, Any]],
    *,
    csv_keys: Sequence[str] | None = None,
    model_keys: Sequence[str] | None = None,
    minimum_pairs: int = 3,
) -> tuple[np.ndarray, list[str], list[str], np.ndarray]:
    """Calculate a rectangular Pearson matrix between two metric families.

    Each position in ``csv_rows`` must refer to the same observation as the
    corresponding position in ``model_rows``. At least three paired observations
    are required by default: with one pair Pearson is undefined, while two
    non-constant pairs always produce +1 or -1. Cells with fewer than
    ``minimum_pairs`` valid observations or with a constant input series are
    returned as NaN. ``valid_counts`` stores the number of paired values used by
    each cell.
    """
    if len(csv_rows) != len(model_rows):
        raise ValueError("CSV and model metric rows must have the same length.")
    if len(csv_rows) < minimum_pairs:
        raise ValueError(
            f"At least {minimum_pairs} paired CSV/model observations are required."
        )

    if csv_keys is None:
        csv_keys = list(dict.fromkeys(
            key for row in csv_rows for key in row.keys()
        ))
    else:
        csv_keys = list(csv_keys)

    if model_keys is None:
        model_keys = list(dict.fromkeys(
            key for row in model_rows for key in row.keys()
        ))
    else:
        model_keys = list(model_keys)

    matrix = np.full((len(csv_keys), len(model_keys)), np.nan, dtype=float)
    valid_counts = np.zeros(matrix.shape, dtype=int)

    for row_index, csv_key in enumerate(csv_keys):
        x_all = np.asarray(
            [_numeric_value(row.get(csv_key)) for row in csv_rows],
            dtype=float,
        )
        for column_index, model_key in enumerate(model_keys):
            y_all = np.asarray(
                [_numeric_value(row.get(model_key)) for row in model_rows],
                dtype=float,
            )
            valid = np.isfinite(x_all) & np.isfinite(y_all)
            count = int(np.sum(valid))
            valid_counts[row_index, column_index] = count
            if count < minimum_pairs:
                continue

            x = x_all[valid]
            y = y_all[valid]
            if np.ptp(x) <= 1e-12 or np.ptp(y) <= 1e-12:
                continue

            coefficient = float(np.corrcoef(x, y)[0, 1])
            if np.isfinite(coefficient):
                matrix[row_index, column_index] = float(
                    np.clip(coefficient, -1.0, 1.0)
                )

    return matrix, csv_keys, model_keys, valid_counts


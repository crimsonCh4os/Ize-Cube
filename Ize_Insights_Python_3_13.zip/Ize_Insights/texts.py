# Herramientas para la monitorización y análisis de procesos de modelado 3D en Blender
# Copyright (C) 2026 María Molina Goyena.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# at your option any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.

"""Centralised bilingual user-interface text and responsive text helpers."""

from __future__ import annotations

import textwrap
from typing import Any

try:
    import bpy
except ModuleNotFoundError:
    bpy = None

LANG_EN = "EN"
LANG_ES = "ES"


# GUÍA RÁPIDA PARA EDITAR TEXTOS
#
# 1) UI_TEXT contiene los textos ingleses que los demás módulos referencian por
#    una clave estable. Para cambiar el texto inglés de un botón, etiqueta o
#    mensaje, modifica SOLO el valor de la clave correspondiente. No cambies la
#    clave, porque el resto del add-on la utiliza como identificador.
#
# 2) ES contiene la traducción al español. Su clave es el texto inglés y su
#    valor es la versión española. Si cambias un texto inglés en UI_TEXT, busca
#    también la antigua frase inglesa en ES y actualiza esa entrada.
#
# 3) HELP_EN y HELP_ES contienen textos largos de ayuda contextual.
#
# 4) Los diccionarios están divididos por bloques temáticos para localizar los
#    textos rápidamente: dependencias, datos, modelo, gráficos, tablas, acciones,
#    avisos, interacción, ayuda y etiquetas generales.


# Central registry for every user-facing source string referenced by UI modules.
UI_TEXT = {

    # ── 01 · Dependencias e instalación ──
    'ANALYSIS_3D_DEPENDENCIES_DEPENDENCIAS': 'Ize Insights — Dependencies / Dependencias',
    'DEPENDENCIES_INSTALLED_DEPENDENCIAS_INSTALADAS': 'Dependencies installed / Dependencias instaladas',
    'DEPENDENCIES_INSTALLED': 'Dependencies installed',
    'REINSTALL_DEPENDENCIES': 'Reinstall dependencies',
    'INSTALL_DEPENDENCIES': 'Install dependencies',
    'INSTALL_DEPENDENCIES_INSTALAR_DEPENDENCIAS': 'Install dependencies / Instalar dependencias',
    'INSTALL_THE_BUNDLED_NUMPY_AND_MATPLOTLIB_PACKAGES_IN_THE_PRIVATE_ADD_O': ('Install the bundled NumPy and Matplotlib packages in the private add-on folder / Instala NumPy y '
     'Matplotlib incluidos en la carpeta privada del add-on'),
    'REQUIRED_LIBRARIES_ARE_MISSING': 'Required libraries are missing',
    'RESTART_BLENDER_AFTERWARDS_REINICIA_BLENDER_DESPU_S': 'Restart Blender afterwards / Reinicia Blender después',
    'RESTART_BLENDER_REINICIA_BLENDER': 'Restart Blender / Reinicia Blender',
    'USA_LOS_PAQUETES_INCLUIDOS_EN_EL_ZIP': 'Usa los paquetes incluidos en el ZIP',
    'USES_BUNDLED_PACKAGES_RESTART_BLENDER_AFTERWARDS': 'Uses bundled packages. Restart Blender afterwards.',


    'TAB_DATA': '📊 Data',
    'TAB_MODELS': '📐 Models',
    'TAB_TABLES': '▦ Tables',
    'TAB_GRAPHS': '🎨 Graphs',
    'TAB_DATA_DESC': 'Import and organise Logger CSV files, create data groups and calculate session statistics.',
    'TAB_MODELS_DESC': 'Calculate and import model metrics, select references and associate recorded data with models.',
    'TAB_TABLES_DESC': 'Configure and create 3D tables from recorded data metrics or calculated model metrics.',
    'TAB_GRAPHS_DESC': 'Configure and generate Timeline, Forest, Radar and correlation visualisations from the selected data.',
    'TAB_DATA_HELP': ('Use Data to load Ize Logger CSV files, organise several recordings into groups and calculate descriptive metrics for individual sessions or groups. '
                      'This is the starting point for most analyses because the selected data sources are reused by Tables and Graphs.'),
    'TAB_MODELS_HELP': ('Use Models to calculate geometric metrics for Blender meshes, import model metrics written by Ize Logger, choose a reference model and create Data ↔ Model associations. '
                        'These model observations can then be used by Tables and comparative Graphs.'),
    'TAB_TABLES_HELP': ('Use Tables to build readable 3D tables inside the Blender scene. Choose whether the table displays recorded session data or model metrics, select the metrics to include, '
                        'then control creation, layout and pagination from the sections below.'),
    'TAB_GRAPHS_HELP': ('Use Graphs to configure and generate the available 3D visualisations. Select the graph type, the data and model metrics to include, and the graph-specific settings before creating the visualisation.'),
    'DURATION': 'Duration',
    'MINUTES_ABBR': 'min',
    'UV_AREA_PERCENT': 'UV area (%)',
    'UV_STRETCH_PERCENT': 'UV stretch (%)',
    'NON_MANIFOLD_COUNT': 'Non-manifold vertices (count)',
    'NON_MANIFOLD_PERCENT': 'Non-manifold vertices (% of vertices)',
    'IZE_INSIGHTS': 'Ize Insights',
    'UV_DEPLOY_EVENTS': 'Unwrap / deploy events',
    'UV_WORK': 'UV work',
    'FREQUENCY': 'Frequency',
    'EVENTS': 'events',
    'EVENTS_PER_MIN': 'events/min',

    # ── 02 · Idioma ──
    'LANGUAGE': 'Language',
    'LANGUAGE_IDIOMA': 'Language / Idioma',

    # ── 03 · Datos, CSV e importación ──
    'ACROSS_SELECTED_DATA_FILES': 'across selected data files',
    'ADD_A_ROW_THAT_ASSOCIATES_ONE_DATA_FILE_WITH_ONE_CALCULATED_MODEL': 'Add a row that associates one data file with one calculated model',
    'CALCULATE_CSV_METRICS_FOR_SELECTED_CSV_FILES_WITH_DESCRIPTIONS_QUARTIL': 'Calculate CSV metrics for selected CSV files with descriptions, quartiles, and per-block context',
    'CALCULATE_CSV_METRIC_STATS': 'Calculate CSV Metric Stats',
    'CHOOSE_A_CALCULATED_SCENE_MODEL_OR_AN_IMPORTED_DATA_LOGGER_MODEL_OBSER': 'Choose a calculated scene model or an imported Data Logger model observation',
    'CREATE_A_READABLE_3D_DATA_TABLE_FROM_THE_SELECTED_CSV_FILES_AND_METRIC': 'Create a readable 3D data table from the selected CSV files and metrics',
    'CREATE_CSV_GROUP': 'Create CSV Group',
    'CREATE_GROUP': 'Create group',
    'CREATE_ONE_VIRTUAL_CSV_SOURCE_FROM_THE_CURRENTLY_SELECTED_CSV_FILES': 'Create one virtual CSV source from the currently selected CSV files',
    'CREATE_THE_CONFIGURED_3D_GRAPH_USING_THE_SELECTED_CSV_FILES_AND_METRIC': 'Create the configured 3D graph using the selected CSV files and metrics',
    'CSV_AND_MODEL_OBSERVATIONS_ARE_PAIRED_BY_NAME_OR_ORDER_WHEN_BOTH_METRI': 'CSV and model observations are paired by name or order when both metric families are selected.',
    'CSV_FILES': 'CSV files',
    'CSV_FILES_DETECTED': 'CSV files detected',
    'CSV_GROUP_CREATED': 'CSV group created',
    'CSV_USER': 'CSV / User',
    'DATA_FILE': 'Data file',
    'DATA_FILES_SELECTED': 'Data files selected',
    'DATA_GROUPS_SELECTED': 'Data groups selected',
    'DATA_TABLE_SELECTED_CSV_METRICS': 'Data table · selected CSV metrics',
    'EXTERNAL_JSON_OR_CSV_FILE_CONTAINING_DATA_LOGGER_MESH_METRICS': 'External .json or .csv file containing Data Logger mesh metrics',
    'FIND_CSV_FILES_IN_THE_SELECTED_FOLDER_AND_REFRESH_THE_LIST_WHILE_KEEPI': 'Find CSV files in the selected folder and refresh the list while keeping prior selections',
    'FRAME_FILA_CSV': 'Frame / fila CSV',
    'GROUP_NAME': 'Group name',
    'IMPORTED_MESH_FILES': 'Imported mesh files',
    'IMPORTED_MESH_OBSERVATIONS': 'Imported mesh observations',
    'IMPORT_DATA_LOGGER_MESH_METRICS': 'Import Data Logger Mesh Metrics',
    'IMPORT_DATA_LOGGER_MODEL_METRICS': 'Import Data Logger model metrics',
    'MEMBERS': 'Members',
    'NO_CSV_GROUP_SELECTED': 'No CSV group selected',
    'NO_CSV_SELECTED': 'No CSV selected',
    'NO_DATA_FILE_SELECTED': 'No data file selected',
    'RAW_DATA_TABLE_SELECTED_CSV_METRICS': 'Raw data table · selected CSV metrics',
    'REMOVE_CSV_GROUP': 'Remove CSV Group',
    'REMOVE_GROUP': 'Remove group',
    'REMOVE_THE_SELECTED_ASSOCIATION_BETWEEN_A_DATA_FILE_AND_A_MODEL': 'Remove the selected association between a data file and a model',
    'REMOVE_THE_SELECTED_CSV_GROUP_WITHOUT_DELETING_ITS_SOURCE_FILES': 'Remove the selected CSV group without deleting its source files',
    'SCAN_CSV': 'Scan CSV',
    'SELECT_AT_LEAST_ONE_CSV_FILE': 'Select at least one CSV file',
    'SELECT_AT_LEAST_THREE_DATA_FILES_IN_THE_DATA_TAB_PEARSON_IS_UNDEFINED_': ('Select at least three data files in the Data tab. Pearson is undefined with one observation and '
     'always ±1 with only two varying observations.'),
    'SELECT_AT_LEAST_TWO_CSV_FILES_TO_CREATE_A_GROUP': 'Select at least two CSV files to create a group',
    'SELECT_A_FOLDER_OR_CSV_AND_UPDATE_THE_ANALYZABLE_FILE_LIST': 'Select a folder or CSV and update the analyzable file list',
    'SELECT_CSV_FILES_IN_THE_DATA_TAB': 'Select CSV files in the Data tab',
    'SELECT_FOLDER_OR_CSV': 'Select folder or CSV',
    'SELECT_GROUP_MEMBERS': 'Select Group Members',
    'SELECT_ONE_OR_MORE_JSON_OR_CSV_FILES_AND_IMPORT_THEIR_MODEL_OBSERVATIO': 'Select one or more .json or .csv files and import their model observations',
    'SELECT_ONE_OR_MORE_VALID_JSON_OR_CSV_DATA_LOGGER_MESH_METRICS_FILES': 'Select one or more valid JSON or CSV Data Logger mesh metrics files',
    'SELECT_ORIGINAL_MEMBERS': 'Select original members',
    'SELECT_THE_ORIGINAL_FILES_CONTAINED_IN_THE_ACTIVE_GROUP': 'Select the original files contained in the active group',
    'SHOW_DATA_IMPORT': 'Show Data Import',
    'USE_GROUP': 'Use group',
    'IMPORTED_MODEL_OBSERVATION_FROM_THIS_DATA_LOGGER_JSON_OR_CSV_FILE': 'Imported model observation from this Data Logger JSON or CSV file',
    'IMPORTED_DATA_LOGGER_OBSERVATION_MATCHING_A_SCENE_MODEL': 'Imported Data Logger observation matching a scene model',
    'CSV': 'CSV',

    # ── 04 · Modelo y métricas de malla ──
    '0_OTHER_1_OBJECT_MODE_2_EDIT_MODE': '0 = Other · 1 = Object Mode · 2 = Edit Mode',
    '3D_DATA_MESH_PEARSON_CORRELATION_HEATMAP': '3D Data ↔ Mesh Pearson correlation heatmap',
    '3D_MESH_MESH_PEARSON_CORRELATION_HEATMAP': '3D Mesh ↔ Mesh Pearson correlation heatmap',
    'ABSOLUTE_CHANGES_IN_N_GONS_TRIANGLES_AND_INVERTED_NORMALS': 'Absolute changes in n-gons, triangles and inverted normals',
    'ABSOLUTE_NUMBER_OF_MODIFIER_CHANGES_RECORDED_IN_EACH_ROW': 'Absolute number of modifier changes recorded in each row',
    'ACROSS_ANALYSED_MESH_OBJECTS': 'across analysed mesh objects',
    'ADD_DATA_MESH_PAIR': 'Add data–mesh pair',
    'CALCULATED_MESH_OBSERVATIONS': 'Calculated mesh observations',
    'CALCULATED_MODEL_OBSERVATIONS': 'Calculated model observations',
    'CALCULATE_GEOMETRIC_METRICS_FOR_THE_ACTIVE_MODEL_AND_IF_AVAILABLE_COMP': 'Calculate geometric metrics for the active model and, if available, compare them with a reference',
    'CALCULATE_MESH_METRICS_BEFORE_CREATING_THE_TABLE': 'Calculate mesh metrics before creating the table',
    'CALCULATE_MODEL_METRICS': 'Calculate model metrics',
    'CALCULATE_MODEL_METRICS_FOR_AT_LEAST_THREE_MESH_OBJECTS_IN_THE_MESHES_': ('Calculate model metrics for at least three mesh objects in the Meshes tab. Pearson is undefined '
     'with one observation and always ±1 with only two varying observations.'),
    'CHOOSE_WHETHER_THE_TABLE_DISPLAYS_RECORDED_DATA_METRICS_OR_CALCULATED_': 'Choose whether the table displays recorded data metrics or calculated model metrics',
    'CHOOSE_WHICH_MESH_METRICS_ARE_INCLUDED_IN_G2_AND_G3': 'Choose which mesh metrics are included in G2 and G3',
    'CHOOSE_WHICH_MESH_METRICS_ARE_INCLUDED_IN_THE_CORRELATION_GRAPH': 'Choose which mesh metrics are included in the correlation graph',
    'COULD_NOT_CREATE_AT_LEAST_THREE_DATA_MESH_PAIRS_USE_MATCHING_NAMES_OR_': ('Could not create at least three data/mesh pairs. Use matching names or calculate the same number '
     'of data and mesh observations.'),
    'DATA_LOGGER_MESH_DATA_COULD_NOT_BE_READ': 'Data Logger mesh data could not be read',
    'DATA_LOGGER_MESH_METRICS_FILE': 'Data Logger mesh metrics file',
    'DATA_LOGGER_MESH_OBSERVATIONS': 'Data Logger mesh observations',
    'DATA_MODEL': 'Data ↔ Model',
    'DISTANCE_TO_OBJECT': 'Distance to object',
    'EMPTY_RADIAL_MARGIN_KEPT_INSIDE_AND_OUTSIDE_THE_NORMALIZED_RADAR_DATA': 'Empty radial margin kept inside and outside the normalized radar data',
    'FOREST_PLOT_NEEDS_AT_LEAST_ONE_VALID_DATA_OR_MESH_METRIC': 'Forest plot needs at least one valid data or mesh metric',
    'HIDDEN_SCENE_OBJECTS_RESTORED': 'Hidden scene objects restored',
    'LEGACY_MESH': 'Legacy mesh',
    'MAXIMUM_OCTREE_DEPTH_USED_BY_GEOMETRIC_SIMILARITY': 'Maximum octree depth used by geometric similarity',
    'MAXIMUM_VERTICES_STORED_IN_AN_OCTREE_LEAF': 'Maximum vertices stored in an octree leaf',
    'MESH_DATA': 'Mesh data',
    'MESH_ISSUE_CHANGES': 'Mesh issue changes',
    'MESH_ISSUE_CHANGES_IN_VISIBLE_DATA_COUNT': 'Mesh issue changes in visible data: {count}',
    'MESH_METRICS': 'Mesh metrics',
    'MESH_METRICS_TABLE': 'Mesh metrics table',
    'MESH_METRICS_TABLE_GENERATED': 'Mesh metrics table generated',
    'MESH_OBJECT': 'Mesh object',
    'MODEL_DATA': 'Model data',
    'MODEL_METRICS': 'Model metrics',
    'MODEL_MODEL': 'Model ↔ Model',
    'MODIFIER_CHANGES': 'Modifier changes',
    'MODIFIER_CHANGES_IN_VISIBLE_DATA_COUNT': 'Modifier changes in visible data: {count}',
    'NEGATIVE_OBJECTS_REMOVED_POSITIVE_OBJECTS_ADDED': 'Negative = objects removed · Positive = objects added',
    'NET_OBJECT_CHANGE_VALUE': 'Net object change: {value}',
    'NET_VERTEX_CHANGE_VALUE': 'Net vertex change: {value}',
    'NO_ACTIVE_MODEL_FOUND': 'No active model found.',
    'NO_DATA_LOGGER_MESH_METRICS_WERE_FOUND_IN_THE_SELECTED_FILES': 'No Data Logger mesh metrics were found in the selected files',
    'NO_DATA_LOGGER_MESH_METRICS_WERE_FOUND_IN_THIS_BLEND_FILE': 'No Data Logger mesh metrics were found in this .blend file',
    'OBJECT': 'Object',
    'OBJECT_CHANGES': 'Object changes',
    'OBJECT_MODEL': 'Object model',
    'OBJECT_OBJECT_PCT_EDIT_EDIT_PCT_OTHER_OTHER_PCT': 'Object {object_pct}% · Edit {edit_pct}% · Other {other_pct}%',
    'OCCLUSION': 'Occlusion',
    'OCTREE_LIMIT': 'Octree limit',
    'PAIRED_USING_THE_CONFIGURED_DATA_MESH_ASSOCIATIONS': 'paired using the configured Data ↔ Mesh associations',
    'PER_METRIC_MIN_MAX_NORMALIZATION': 'Per-metric min-max normalization',
    'RADAR_PLOT_NEEDS_AT_LEAST_TWO_VALID_DATA_MESH_OR_PAIRED_OBSERVATIONS': 'Radar plot needs at least two valid data, mesh, or paired observations',
    'REFERENCE_MODEL': 'Reference model',
    'REFERENCE_OBJECT': 'Reference Object',
    'REMOVE_DATA_MESH_PAIR': 'Remove data–mesh pair',
    'RESTORE_OBJECTS': 'Restore objects',
    'RESTORE_SCENE_OBJECTS': 'Restore scene objects',
    'SELECT_AT_LEAST_ONE_DATA_METRIC_AND_ONE_MESH_METRIC_FOR_THE_DATA_MESH_': 'Select at least one data metric and one mesh metric for the Data ↔ Mesh graph.',
    'SELECT_AT_LEAST_ONE_MESH_METRIC': 'Select at least one mesh metric',
    'SELECT_AT_LEAST_TWO_MESH_METRICS_FOR_THE_MESH_MESH_GRAPH': 'Select at least two mesh metrics for the Mesh ↔ Mesh graph.',
    'SELECT_A_MESH_AND_CALCULATE_METRICS': 'Select a mesh and calculate metrics.',
    'SELECT_A_MESH_OBJECT': 'Select a MESH object',
    'SELECT_DATA_LOGGER_MESH_METRICS_FILES': 'Select Data Logger Mesh Metrics Files',
    'SHOW_DATA_AND_MESH_ASSOCIATIONS': 'Show Data and Mesh Associations',
    'SHOW_MESH_METRICS': 'Show Mesh Metrics',
    'UNHIDE_MODELS_AND_OTHER_SCENE_OBJECTS_HIDDEN_BY_GRAPH_VISUALIZATION': 'Unhide models and other scene objects hidden by graph visualization',
    'USE_THE_MODEL_METRICS_EMBEDDED_BY_DATA_LOGGER_3D_FOR_TABLES_AND_GRAPHS': ('Use the model metrics embedded by Data Logger 3D for tables and graphs without recalculating the '
     'models'),
    'VERTEX_CHANGES': 'Vertex changes',
    'CALCULATED_MODEL_OBSERVATION_FROM_THE_CURRENT_BLENDER_SCENE': 'Calculated model observation from the current Blender scene',

    # ── 05 · Gráficos y visualización ──
    '3D_DATA_DATA_PEARSON_CORRELATION_HEATMAP': '3D Data ↔ Data Pearson correlation heatmap',
    'BANDS': 'Bands',
    'CHANGE_INTERACTION_GRAPH_WINDOW': 'Change Timeline window',
    'CHOOSE_WHICH_DATA_METRICS_ARE_INCLUDED_IN_THE_CORRELATION_GRAPH': 'Choose which data metrics are included in the correlation graph',
    'CHOOSE_WHICH_METRIC_FAMILIES_ARE_CORRELATED_IN_THE_PEARSON_HEATMAP': 'Choose which metric families are correlated in the Pearson heatmap',
    'CLEAR_GRAPHS': 'Clear graphs',
    'CLEAR_THE_3D_GRAPHS_GENERATED_BY_THE_ADD_ON_FROM_THE_SCENE': 'Clear the 3D graphs generated by the add-on from the scene',
    'COLOR_PALETTE': 'Color palette',
    'COMPARATIVE_RADAR': 'Comparative radar',
    'COMPARATIVE_RADAR_GENERATED': 'Comparative radar generated',
    'CORRELATION_HEATMAP_EXPERIMENTAL': 'Correlation heatmap',
    'CORRELATION_TYPE': 'Correlation type',
    'FOREST_PLOT_EXPERIMENTAL': 'Forest plot',
    'FOREST_PLOT_GENERATED': 'Forest plot generated',
    'FOREST_PLOT_NEEDS_AT_LEAST_ONE_SELECTED_METRIC': 'Forest plot needs at least one selected metric',
    'G1_AVAILABLE_ROWS': 'G1 available rows',
    'G1_DISPLAY_MODE': 'G1 display mode',
    'G1_GLOBAL_VIEW': 'G1 global view',
    'G1_WINDOW_PERCENTAGE': 'G1 window percentage',
    'G1_WINDOW_START': 'G1 window start',
    'G4_GENERATED_WITH_THE_MINIMUM_OF_THREE_PAIRS_TREAT_THE_COEFFICIENTS_AS': ('G4 generated with the minimum of three pairs. Treat the coefficients as exploratory and add more '
     'observations for stable conclusions.'),
    'GRAPH': 'Graph',
    'GRAPHS_GENERATED': 'Graphs generated',
    'METRICS_SHOWN_IN_THE_CORRELATION_GRAPH': 'Metrics shown in the correlation graph',
    'MOVE_TO_THE_PREVIOUS_OR_NEXT_G1_DATA_WINDOW_AND_REDRAW_THE_GRAPH': 'Move to the previous or next Timeline data window and redraw the graph',
    'NO_PEARSON_COEFFICIENTS_COULD_BE_CALCULATED_THE_METRICS_MAY_BE_CONSTAN': ('No Pearson coefficients could be calculated. The metrics may be constant or contain too few '
     'distinct observations.'),
    'OVERLAY': 'Overlay',
    'OVERLAY_INDEPENDENT_Y_SCALE_PER_METRIC': 'Overlay · independent Y scale per metric',
    'PERCENTAGE_OF_THE_AVAILABLE_ROWS_SHOWN_IN_EACH_INTERACTION_GRAPH_WINDO': 'Percentage of the available rows shown in each Timeline window',
    'RADAR_MARGIN': 'Radar margin',
    'RADAR_PLOT_EXPERIMENTAL': 'Radar plot',
    'RADAR_PLOT_NEEDS_AT_LEAST_ONE_SELECTED_METRIC': 'Radar plot needs at least one selected metric',
    'RADAR_PLOT_NEEDS_AT_LEAST_THREE_SELECTED_DATA_OR_MODEL_METRICS': 'Radar plot needs at least three selected Data or Model metrics in total',
    'SCALE_X': 'Scale X',
    'SCALE_Y': 'Scale Y',
    'SCALE_Z': 'Scale Z',
    'SELECT_AT_LEAST_TWO_DATA_METRICS_FOR_THE_DATA_DATA_GRAPH': 'Select at least two data metrics for the DATA ↔ DATA graph.',
    'SHOW_ALL_AVAILABLE_INTERACTION_GRAPH_DATA_BEFORE_THE_NUMBERED_WINDOW': 'Show all available Timeline data before the numbered window',
    'SHOW_METRICS_IN_SEPARATE_BANDS_OR_SUPERIMPOSED_WITH_AN_INDEPENDENT_REA': 'Show metrics in separate bands or superimposed with an independent real range per metric',
    'VISUALIZE_3D_GRAPH': 'Visualize 3D graph',
    'VISUALIZE_GRAPH': 'Visualize Graph',
    'ZERO_BASED_FIRST_ROW_OF_THE_INTERACTION_GRAPH_WINDOW': 'Zero-based first row of the Timeline window',

    # ── 06 · Tablas y paginación ──
    'CHANGE_TABLE_PAGE': 'Change Table Page',
    'CLEAR_DATA_TABLES': 'Clear Data Tables',
    'CLEAR_TABLE': 'Clear table',
    'COLUMNS': 'columns',
    'COLUMNS_2': 'Columns',
    'COLUMNS_PER_PAGE': 'Columns per page',
    'COLUMN_PAGE': 'Column page',
    'CREATE_3D_TABLE': 'Create 3D table',
    'DATA_TABLE_GENERATED': 'Data table generated',
    'MOVE_TO_ANOTHER_TABLE_PAGE_AND_REGENERATE_THE_3D_TABLE': 'Move to another table page and regenerate the 3D table',
    'NO_VALID_DATA_COULD_BE_LOADED_FOR_THE_TABLE': 'No valid data could be loaded for the table',
    'REMOVE_THE_3D_DATA_TABLES_GENERATED_BY_THE_ADD_ON': 'Remove the 3D data tables generated by the add-on',
    'ROW': 'Row',
    'ROWS': 'rows',
    'ROWS_2': 'Rows',
    'ROWS_PER_PAGE': 'Rows per page',
    'ROWS_PER_WINDOW': 'Rows per window (%)',
    'ROW_PAGE': 'Row page',
    'SHORTCUT_EVENTS_PER_ROW_CTRL_V_SHIFT_D_AND_ALT_D': 'Shortcut events per row: Ctrl+V, Shift+D and Alt+D',
    'SHOW_TABLE_CONTROLSETTINGS': 'Show Table ControlSettings',
    'SHOW_TABLE_LAYOUT_SETTINGS': 'Show Table Layout Settings',
    'SHOW_TABLE_SETTINGS': 'Show Table Settings',
    'TABLE_DATA_SOURCE': 'Table data source',
    'VISUALIZE_DATA_TABLE': 'Visualize Data Table',

    # ── 07 · Botones, acciones y controles ──
    '0_NO_UV_TOPOLOGY_CHANGE_1_UV_TOPOLOGY_CHANGE': '0 = No UV topology change · 1 = UV topology change',
    'ADD_ASSOCIATION': 'Add association',
    'CALCULATE_DATA_METRIC_STATS': 'Calculate Data Metric Stats',
    'CALCULATE_METRICS': 'Calculate Metrics',
    'DATA_VISUALIZER': 'Data visualizer',
    'INTERACTION_NEEDS_AT_LEAST_ONE_SELECTED_Y_METRIC_X_IS_ALWAYS_TIME': 'Timeline needs at least one selected Y metric; X is always time',
    'METRICS_SELECTED': 'Metrics selected',
    'METRIC_STATISTICS_CALCULATED': 'Metric statistics calculated',
    'NEGATIVE_VERTICES_REMOVED_POSITIVE_VERTICES_ADDED': 'Negative = vertices removed · Positive = vertices added',
    'NO_METRICS_CALCULATED_YET': 'No metrics calculated yet.',
    'REFRESH_LIST': 'Refresh list',
    'REMOVE_ASSOCIATION': 'Remove association',
    'SELECT': 'Select',
    'SELECT_AT_LEAST_ONE_METRIC': 'Select at least one metric',
    'SHOW_BINDING': 'Show Binding',
    'SHOW_GLOBAL_METRICS': 'Show Global Metrics',
    'SHOW_RENDER_CONTROLS': 'Show Render Controls',
    'SHOW_VISUAL_SETTINGS': 'Show Visual Settings',
    'THE_SELECTED_METRICS_CONTAIN_NO_VALID_VALUES': 'The selected metrics contain no valid values',

    # ── 08 · Avisos, validaciones y errores ──
    '0_NO_PAUSE_1_DETECTED_PAUSE': '0 = No pause · 1 = Detected pause',
    '0_NO_PEAK_1_DETECTED_PEAK': '0 = No peak · 1 = Detected peak',
    'INTERACTION_COMPARISON_COULD_NOT_GENERATE_DATA_FOR_THIS_WINDOW': 'Timeline could not generate data for this window',
    'MISSING': 'Missing',
    'NO_AGGREGATION': 'no aggregation',
    'NO_CHANGE': 'No change',
    'NO_PAUSE': 'No pause',
    'NO_PEAK': 'No peak',
    'SKIPPED_FILES': 'Skipped files',
    'VALID_ASSOCIATIONS': 'Valid associations',
    'MISSING_FALTAN_PREFIX': 'Missing / Faltan: ',

    # ── 09 · Métricas de interacción y sesión ──
    'ACTIVE_MOVEMENT_PEAKS': 'Active movement peaks',
    'DETECTED_PAUSES_IN_VISIBLE_DATA_COUNT': 'Detected pauses in visible data: {count}',
    'DETECTED_PEAKS_IN_VISIBLE_DATA_COUNT': 'Detected peaks in visible data: {count}',
    'IDLE_MOVEMENT_PEAKS': 'Idle movement peaks',
    'PAUSE': 'Pause',
    'PAUSES': 'Pauses',
    'PAUSES_BY_PHASE': 'Pauses by phase',
    'PEAK': 'Peak',
    'SESSION_DURATION': 'Session duration',
    'SESSION_DURATION_H': 'Session duration (h)',
    'SESSION_PROGRESS': 'Session progress (%)',
    'SHORTCUT_EVENTS_IN_VISIBLE_DATA_COUNT': 'Shortcut events in visible data: {count}',
    'SHORTCUT_REUSE': 'Shortcut reuse',
    'SPATIAL': 'Spatial',
    'TEMPORAL': 'Temporal',
    'TRAVEL_PEAKS': 'Travel peaks',
    'UV_CHANGE': 'UV change',
    'UV_CHANGES_IN_VISIBLE_DATA_COUNT': 'UV changes in visible data: {count}',
    'UV_WORK': 'UV work',
    'VIEW_MOVEMENT_PEAKS': 'View movement peaks',
    'VIEW_SPEED': 'View speed',
    'WORK_MODE': 'Work mode',

    # ── 10 · Ayudas y tooltips ──
    'CONTEXT_HELP': 'Context Help',
    'MAXIMUM_SUBDIVISIONS': 'Maximum subdivisions',
    'OPEN_DETAILED_CONTEXTUAL_HELP': 'Open detailed contextual help',

    # ── 11 · Etiquetas generales ──
    '3D_DATA_ANALYSIS_METRICS': '3D Data Analysis + Metrics',
    'ADVANCED_DATA_ANALYSIS_SYSTEM_WITH_AUTOMATIC_METRICS_AND_3D_VISUALIZAT': 'Advanced data analysis system with automatic metrics and 3D visualization',
    'ALL_DATA': 'All data',
    'ALL_RECORDED_VALUES': 'All recorded values',
    'AND': 'and',
    'ASSOCIATION': 'Association',
    'AVERAGE_STATE': 'Average state',
    'COMPACT_LABELS': 'Compact labels',
    'DATA': 'Data',
    'DATA_DATA': 'Data ↔ Data',
    'DATA_METRICS': 'Data metrics',
    'DATA_SIZE': 'Data Size',
    'DATA_X': 'Data X',
    'DATA_Y': 'Data Y',
    'DATA_Z': 'Data Z',
    'DISPLAYED_VALUE': 'Displayed value',
    'EDIT': 'Edit',
    'ELEMENTS_PER_NODE': 'Elements per node',
    'FALTAN_BIBLIOTECAS_NECESARIAS': 'Faltan bibliotecas necesarias',
    'GLOBAL': 'Global',
    'INDEPENDENT_Y_RANGES': 'Independent Y ranges',
    'INTERACTION_EXPERIMENTAL': 'Timeline',
    'LOG_SCALE': 'Log scale',
    'MARGIN': 'margin',
    'MEAN': 'Mean',
    'METRICS': 'metrics',
    'METRICS_2': 'Metrics',
    'MINIMUM_OBSERVATIONS_3': 'Minimum observations: 3',
    'MIN_MAX': 'min-max',
    'MODE': 'Mode',
    'OBSERVATIONS': 'Observations',
    'OF': 'of',
    'OTHER': 'Other',
    'PAIRED_BY_NAME': 'paired by name',
    'PAIRED_BY_ORDER': 'paired by order',
    'PAIRED_USING_CONFIGURED_ASSOCIATIONS_AND_AUTOMATIC_MATCHING': 'paired using configured associations and automatic matching',
    'RANGE_OF_SAMPLES': 'Range of samples',
    'RAW_OBSERVATIONS': 'raw observations',
    'SAMPLES': 'samples',
    'SECTION': 'Section',
    'SHOWING': 'Showing',
    'STRATEGY': 'Strategy',
    'TWO_DECIMALS': 'two decimals',
    'USES_THE_PACKAGES_INCLUDED_IN_THE_ZIP': 'Uses the packages included in the ZIP',
    'VALUE': 'Value',
    'VALUES': 'values',
    'VALUES_SHOWN_WITH_TWO_DECIMALS': 'values shown with two decimals',
    'Z_SCORE': 'z-score',
    'PER_METRIC_MIN_MAX': 'per-metric min-max',
    'METRIC': 'Metric',
    'SEPARATES_MODIFIERS_CREATED_AND_DELETED_NET_CHANGE_IS_CREATED_MINUS_DELETED_QUAR': 'Separates modifiers created and deleted. Net change is created minus deleted; quartiles show the signed balance in each quarter.',
    'CREATED': 'Created',
    'DELETED': 'Deleted',
    'NET_CHANGE': 'Net change',
    'FREQUENCY': 'Frequency',
    'MODIFIERS': 'modifiers',
    'NET_MODIFIERS': 'net modifiers',
    'EVENTS_MIN': 'events/min',
    'GEOMETRY_AND_OBJECT_CHANGES': 'Geometry and object changes',
    'ADDITIONS_CREATIONS_ARE_POSITIVE_AND_REMOVALS_DELETIONS_ARE_NEGATIVE_QUARTILES_S': 'Additions/creations are positive and removals/deletions are negative. Quartiles show the algebraic balance inside each quarter.',
    'SHOWS_VERTICES_ADDED_REMOVED_AND_THEIR_NET_RESULT': 'Shows vertices added, removed, and their net result.',
    'ADDED': 'Added',
    'REMOVED': 'Removed',
    'VERTICES': 'vertices',
    'NET_VERTICES': 'net vertices',
    'POSITIVE_VALUES_ADD_ISSUES_AND_NEGATIVE_VALUES_REMOVE_FIX_THEM': 'Positive values add issues and negative values remove/fix them.',
    'ISSUES': 'issues',
    'CHANGES': 'changes',
    'NET_ISSUES': 'net issues',
    'SHOWS_OBJECTS_CREATED_DELETED_AND_THEIR_NET_BALANCE': 'Shows objects created, deleted, and their net balance.',
    'OBJECTS': 'objects',
    'NET_OBJECTS': 'net objects',
    'PERCENTAGE_OF_TIME_IN_OBJECT_MODE_AND_EDIT_MODE_PLUS_MODE_SWITCH_FREQUENCY': 'Percentage of time in Object Mode and Edit Mode, plus mode-switch frequency.',
    'OBJECT_MODE': 'Object Mode',
    'EDIT_MODE': 'Edit Mode',
    'MODE_CHANGES': 'Mode changes',
    'CHG_MIN': 'chg/min',
    'OBJECT': '% Object',
    'EDIT': '% Edit',
    'COUNTS_CTRL_V_SHIFT_D_AND_ALT_D_SEPARATELY_TOTAL_AND_FREQUENCY_REMAIN_AVAILABLE': 'Counts Ctrl+V, Shift+D and Alt+D separately; total and frequency remain available.',
    'COUNTS_THE_THREE_TRACKED_MODELLING_SHORTCUTS_SEPARATELY_THE_TOTAL_IS_NOT_USED_AS': 'Counts the three tracked modelling shortcuts separately. The total is not used as a substitute for the individual behaviours.',
    'TOTAL': 'Total',
    'EVENTS': 'events',
    'COMPLETED_UV_ACTIONS_SEPARATED_INTO_UNWRAP_DEPLOY_TRANSFORMS_AND_OTHER_UV_OPERAT': 'Completed UV actions separated into unwrap/deploy, transforms and other UV operations.',
    'COUNTS_COMPLETED_UV_ACTIONS_DEPLOYMENT_TRANSFORMS_AND_OTHER_UV_OPERATIONS_ARE_SE': 'Counts completed UV actions. Deployment, transforms and other UV operations are separated so the metric is interpretable.',
    'DEPLOY_UNWRAP': 'Deploy / unwrap',
    'UV_TRANSFORMS': 'UV transforms',
    'OTHER_UV_ACTIONS': 'Other UV actions',
    'OCCLUSION_SEE_THROUGH': 'Occlusion / see-through',
    'X_RAY_WIREFRAME_USE_MEASURED_AS_STATE_ACTIVATIONS_ACTIVE_MINUTES_AND_PERCENTAGE_': 'X-Ray/Wireframe use measured as state: activations, active minutes and percentage of session.',
    'MEASURES_USE_OF_X_RAY_OR_WIREFRAME_AS_A_STATE_ACTIVATIONS_ACTIVE_TIME_AND_PERCEN': 'Measures use of X-Ray or Wireframe as a state: activations, active time and percentage of session. It no longer counts every active row as a separate event.',
    'ACTIVATIONS': 'Activations',
    'ACTIVE_TIME': 'Active time',
    'SESSION_ACTIVE': 'Session active',
    'ACTIVATION_FREQUENCY': 'Activation frequency',
    'ACTIVE': '% active',
    'SIGNED_MODIFIER_BALANCE_PER_ROW_POSITIVE_CREATED_NEGATIVE_DELETED': 'Signed modifier balance per row: positive created, negative deleted.',
    'SIGNED_VERTEX_BALANCE_PER_ROW_POSITIVE_ADDED_NEGATIVE_REMOVED': 'Signed vertex balance per row: positive added, negative removed.',
    'SIGNED_MESH_ISSUE_BALANCE_PER_ROW_POSITIVE_ADDED_NEGATIVE_FIXED_REMOVED': 'Signed mesh-issue balance per row: positive added, negative fixed/removed.',
    'SIGNED_OBJECT_BALANCE_PER_ROW_POSITIVE_CREATED_NEGATIVE_DELETED': 'Signed object balance per row: positive created, negative deleted.',
    'TRACKED_SHORTCUT_EVENTS_PER_ROW_CTRL_V_SHIFT_D_AND_ALT_D': 'Tracked shortcut events per row: Ctrl+V, Shift+D and Alt+D.',
    'SHORTCUT_EVENTS_IN_VISIBLE_DATA_VALUE': 'Shortcut events in visible data: {value}',
    '0_NO_COMPLETED_UV_ACTION_1_COMPLETED_UV_ACTION': '0 = no completed UV action; 1 = completed UV action.',
    'NO_UV_ACTION': 'No UV action',
    'UV_ACTION': 'UV action',
    'UV_ACTIONS_IN_VISIBLE_DATA_VALUE': 'UV actions in visible data: {value}',
    'SEE_THROUGH_STATE_1_WHEN_X_RAY_OR_WIREFRAME_IS_ACTIVE': 'See-through state: 1 when X-Ray or Wireframe is active.',
    'OFF': 'Off',
    'ON': 'On',
    'ACTIVE_SAMPLES_VALUE': 'Active samples: {value}%',
    'MODIFIER_Δ': 'modifier Δ',
    'VERTEX_Δ': 'vertex Δ',
    'ISSUE_Δ': 'issue Δ',
    'OBJECT_Δ': 'object Δ',
    'STATE': 'state',
    'NET_MODIFIERS_MIN': 'net modifiers/min',
    'NET_VERTICES_MIN': 'net vertices/min',
    'NET_ISSUES_MIN': 'net issues/min',
    'NET_OBJECTS_MIN': 'net objects/min',
    'UV_WORK_EXPLICIT_HELP': 'Completed explicit UV actions separated into unwrap/deploy, transforms and other UV operations. Mesh topology changes alone are not counted as UV work.',
}

# Spanish translations for English source strings that are used by the add-on.
ES = {

    '📊 Data': '📊 Datos',
    '📐 Models': '📐 Modelos',
    '▦ Tables': '▦ Tablas',
    '🎨 Graphs': '🎨 Gráficos',
    'Import and organise Logger CSV files, create data groups and calculate session statistics.': 'Importa y organiza archivos CSV de Logger, crea grupos de datos y calcula estadísticas de sesión.',
    'Calculate and import model metrics, select references and associate recorded data with models.': 'Calcula e importa métricas de modelos, selecciona referencias y asocia datos registrados con modelos.',
    'Configure and create 3D tables from recorded data metrics or calculated model metrics.': 'Configura y crea tablas 3D a partir de métricas de datos registrados o métricas de modelos calculadas.',
    'Configure and generate Timeline, Forest, Radar and correlation visualisations from the selected data.': 'Configura y genera visualizaciones de Línea de tiempo, Forest, Radar y correlación a partir de los datos seleccionados.',
    'Use Data to load Ize Logger CSV files, organise several recordings into groups and calculate descriptive metrics for individual sessions or groups. This is the starting point for most analyses because the selected data sources are reused by Tables and Graphs.': 'Usa Datos para cargar archivos CSV de Ize Logger, organizar varias grabaciones en grupos y calcular métricas descriptivas de sesiones individuales o grupos. Es el punto de partida de la mayoría de los análisis porque las fuentes de datos seleccionadas se reutilizan en Tablas y Gráficos.',
    'Use Models to calculate geometric metrics for Blender meshes, import model metrics written by Ize Logger, choose a reference model and create Data ↔ Model associations. These model observations can then be used by Tables and comparative Graphs.': 'Usa Modelos para calcular métricas geométricas de mallas de Blender, importar métricas de modelo escritas por Ize Logger, elegir un modelo de referencia y crear asociaciones Datos ↔ Modelo. Estas observaciones de modelo pueden utilizarse después en Tablas y Gráficos comparativos.',
    'Use Tables to build readable 3D tables inside the Blender scene. Choose whether the table displays recorded session data or model metrics, select the metrics to include, then control creation, layout and pagination from the sections below.': 'Usa Tablas para crear tablas 3D legibles dentro de la escena de Blender. Elige si la tabla muestra datos de sesión registrados o métricas de modelos, selecciona las métricas que quieres incluir y controla después la creación, el diseño y la paginación desde las secciones inferiores.',
    'Use Graphs to configure and generate the available 3D visualisations. Select the graph type, the data and model metrics to include, and the graph-specific settings before creating the visualisation.': 'Usa Gráficos para configurar y generar las visualizaciones 3D disponibles. Selecciona el tipo de gráfico, las métricas de datos y de modelo que quieres incluir y los ajustes específicos del gráfico antes de crear la visualización.',
    'Duration': 'Duración',
    'min': 'min',
    'UV area (%)': 'Área UV (%)',
    '3D surface area': 'Área superficial 3D',
    'Faces by mesh': 'Caras por malla',
    'UV stretch (%)': 'Estiramiento UV (%)',
    'Non-manifold edges (count)': 'Aristas non-manifold (cantidad)',
    'Non-manifold edges (% of vertices)': 'Aristas non-manifold (% de vértices)',
    'Ize Insights': 'Ize Insights',
    'Unwrap / deploy events': 'Eventos de despliegue / unwrap',
    'UV work': 'Trabajo UV',
    'Frequency': 'Frecuencia',
    'events': 'eventos',
    'events/min': 'eventos/min',
    'Only completed unwrap/deployment operations are counted. Ordinary UV editing is ignored.': 'Solo se cuentan las operaciones de despliegue/unwrap completadas. La edición UV normal se ignora.',
    'Duplication / instancing': 'Duplicación / instanciación',
    'Ctrl+V and Shift+D are shown together as Duplicate. Alt+D is shown as Instance.': 'Ctrl+V y Shift+D se muestran juntos como Duplicar. Alt+D se muestra como Instanciar.',
    'Duplicate': 'Duplicar',
    'Instance': 'Instanciar',
    'New issues and resolved issues are separated. Error totals count only issues introduced, not their later resolution.': 'Los errores nuevos y los resueltos se muestran por separado. El total de errores cuenta solo los errores generados, no su resolución posterior.',
    'Errors generated': 'Errores generados',
    'Errors resolved': 'Errores resueltos',
    'Ngons generated': 'N-gons generados',
    'Triangles generated': 'Triángulos generados',
    'Normals generated': 'Normales invertidas generadas',
    'Non-manifold generated': 'Non-manifold generados',
    'Generation rate': 'Tasa de generación',
    'UV subcategories can overlap: one UV event may be both unwrap/deploy and transform. Total counts unique UV-event rows, so it is not the sum of the subcategories.': 'Las subcategorías UV pueden solaparse: un mismo evento UV puede ser unwrap/desplegado y transformación. El total cuenta eventos UV únicos, por lo que no es la suma de las subcategorías.',
    'Events with unwrap / deploy': 'Eventos con unwrap / desplegado',
    'Events with UV transform': 'Eventos con transformación UV',
    'Events with other UV action': 'Eventos con otra acción UV',
    'Unique UV events': 'Eventos UV únicos',
    'Duplication events per row: Ctrl+V/Shift+D = Duplicate; Alt+D = Instance.': 'Eventos de duplicación por fila: Ctrl+V/Shift+D = Duplicar; Alt+D = Instanciar.',

    # ── 01 · Dependencias e instalación ──
    'Install dependencies': 'Instalar dependencias',
    'Dependencies installed': 'Dependencias instaladas',
    'Reinstall dependencies': 'Reinstalar dependencias',
    'Required libraries are missing': 'Faltan bibliotecas necesarias',
    'Uses bundled packages. Restart Blender afterwards.': 'Usa los paquetes incluidos. Reinicia Blender después.',

    # ── 02 · Idioma ──
    'English': 'Inglés',
    'Language': 'Idioma',

    # ── 03 · Datos, CSV e importación ──
    '1. Data import': '1. Importar Datos',
    'CSV / User': 'CSV / Usuario',
    'Total duration of the CSV recording, expressed in minutes.': 'Duración total del registro CSV, expresada en minutos.',
    'Counts shortcut reuse and modifier changes recorded in the CSV, helping identify repeated actions and changes in the modelling workflow.': ('Cuenta la reutilización de atajos y los cambios de modificadores registrados en el CSV, lo que '
     'permite identificar acciones repetidas y cambios en el flujo de trabajo de modelado.'),
    'Occlusion events recorded directly in the CSV by Data Logger, showing when visibility conditions such as X-Ray or wireframe mode were active during the session.': ('Eventos de oclusión registrados directamente en el CSV por Data Logger, que muestran cuándo '
     'estuvieron activas durante la sesión condiciones de visibilidad como el modo Rayos X o el modo '
     'alámbrico.'),
    'Counts the exact CSV fields CtrlV, ShiftD, and AltD and their total frequency.': 'Cuenta los campos CSV exactos CtrlV, ShiftD y AltD, así como su frecuencia total.',
    'Add a row that associates one data file with one calculated model': 'Añada una fila que asocie un archivo de datos con un modelo calculado.',
    'Remove the selected association between a data file and a model': 'Eliminar la asociación seleccionada entre un archivo de datos y un modelo.',
    'Calculate CSV metrics for selected CSV files with descriptions, quartiles, and per-block context': ('Calcular métricas CSV para los archivos CSV seleccionados, incluyendo descripciones, cuartiles y '
     'contexto por bloque.'),
    'Display metrics calculated from the selected data files': 'Mostrar métricas calculadas a partir de los archivos de datos seleccionados',
    'CSV file': 'Archivo CSV',
    'CSV files': 'archivos CSV',
    'CSV group created': 'Grupo CSV creado',
    'Create group': 'Crear grupo',
    'Create CSV Group': 'Crear grupo de datos',
    'Data file': 'Archivo de datos',
    'Data files and statistics': 'Archivos de datos y estadísticas',
    'Data files selected': 'Archivos de datos seleccionados',
    'Data groups selected': 'Grupos de datos seleccionados',
    'Data table · selected CSV metrics': 'Tabla de datos · métricas CSV seleccionadas',
    'Import Data Logger model metrics': 'Importar métricas de modelo de Data Logger',
    'No CSV group selected': 'No hay ningún grupo CSV seleccionado',
    'No data file selected': 'No hay ningún archivo de datos seleccionado',
    'Raw data table · selected CSV metrics': 'Tabla de datos brutos · métricas CSV seleccionadas',
    'Remove CSV Group': 'Eliminar grupo de datos',
    'Remove group': 'Eliminar grupo',
    'Remove the selected CSV group without deleting its source files': 'Elimina el grupo de datos seleccionado sin borrar sus archivos de origen',
    'Scan CSV': 'Buscar archivos de datos',
    'CSV and model observations are paired by name or order when both metric families are selected.': ('Las observaciones del archivo CSV y del modelo se emparejan por nombre o por orden cuando se '
     'seleccionan ambas familias de métricas.'),
    'Select CSV files in the Data tab': 'Selecciona archivos CSV en la pestaña Datos',
    'Select a folder or CSV and update the analyzable file list': 'Selecciona una carpeta o archivo de datos y actualiza la lista analizable',
    'Select at least one CSV file': 'Selecciona al menos un archivo CSV',
    'Select at least two CSV files to create a group': 'Selecciona al menos dos archivos CSV para crear un grupo',
    'Select folder or CSV': 'Seleccionar carpeta o archivo de datos',
    'Select the original files contained in the active group': 'Selecciona los archivos originales incluidos en el grupo activo',
    'Select one or more .json or .csv files and import their model observations': 'Selecciona uno o varios archivos .json o .csv e importa sus observaciones de modelos',
    'Select one or more valid JSON or CSV Data Logger model metrics files': 'Selecciona uno o varios archivos JSON o CSV válidos con métricas de modelos de Data Logger',
    'Find CSV files in the selected folder and refresh the list while keeping prior selections': ('Busca archivos de datos en la carpeta seleccionada y actualiza la lista conservando las '
     'selecciones anteriores'),
    'Create one virtual CSV source from the currently selected CSV files': 'Crea una fuente virtual con los archivos de datos seleccionados',
    'Select Group Members': 'Seleccionar miembros del grupo',
    'Calculate CSV Metric Stats': 'Calcular estadísticas de datos',
    'Import Data Logger Model Metrics': 'Importar métricas de modelos de Data Logger',
    'Create the configured 3D graph using the selected CSV files and metrics': 'Crea el gráfico 3D configurado con los archivos de datos y métricas seleccionados',
    'Create a readable 3D data table from the selected CSV files and metrics': 'Crea una tabla 3D legible con los archivos de datos y métricas seleccionados',
    'Select a .blend, .json or .csv file containing Data Logger mesh metrics': 'Selecciona un archivo .blend, .json o .csv que contenga métricas de modelo de Data Logger',
    'External .blend, .json or .csv file containing Data Logger model metrics': 'Archivo externo .blend, .json o .csv que contiene métricas de modelo de Data Logger',
    'Select a JSON or CSV Data Logger model metrics file': 'Selecciona un archivo JSON o CSV válido con métricas de modelo de Data Logger',
    'Select a .json or .csv file containing Data Logger model metrics': 'Selecciona un archivo .json o .csv que contenga métricas de modelo de Data Logger',
    'Compare central values and spread across files, groups or model observations': 'Compara valores centrales y dispersión entre archivos, grupos u observaciones de modelos',

    # ── 04 · Modelo y métricas de malla ──
    '1. Model selector': '1. Selector de modelos',
    '2. Model Metrics': '2. Métricas del modelo',
    '3. Data ↔ Model associations': '3. Asociaciones Datos ↔ Modelos',
    'Unhide models and other scene objects hidden by graph visualization': 'Mostrar los modelos y otros objetos de la escena ocultos por la visualización del grafo',
    '3D Data ↔ Model Pearson correlation heatmap': 'Mapa de calor 3D de correlación de Pearson Datos ↔ Modelo',
    '3D Model ↔ Model Pearson correlation heatmap': 'Mapa de calor 3D de correlación de Pearson Modelo ↔ Modelo',
    'Absolute changes in n-gons, triangles and inverted normals': 'Cambios absolutos en n-gons, triángulos y normales invertidas',
    'Absolute number of modifier changes recorded in each row': 'Número absoluto de cambios de modificadores registrados en cada fila',
    'Vertices, mesh errors, and mesh/object changes are separated so that each type of activity can be analysed independently; every section includes its own quartiles.': ('Los vértices, los errores de malla y los cambios en la malla o el objeto se presentan por '
     'separado para permitir el análisis independiente de cada tipo de actividad; cada sección incluye '
     'sus propios cuartiles.'),
    'Modifier use or equivalent row-level changes detected per row.': 'Cambios en el uso de modificadores o cambios equivalentes a nivel de fila para cada fila.',
    'Occlusion events showing when visibility conditions such as X-Ray or wireframe mode were active during the session.': ('Eventos de oclusión que muestran cuándo estuvieron activas condiciones de visualización como el '
     'modo de rayos X o el modo de estructura alámbrica durante la sesión.'),
    'Vertex evolution shown as total delta, rate, and quartiles.': 'Evolución de los vértices representada como delta total, tasa y cuartiles.',
    'Mesh error evolution separated by registered error type: ngons, triangles, and normals.': ('Evolución del error de malla desglosada por tipo de error registrado: n-gonos, triángulos y '
     'normales.'),
    'Mesh/object change events plus estimated mesh/object count at the end of each quartile.': ('Eventos de cambio de malla u objeto, además del recuento estimado de mallas u objetos al final '
     'de cada cuartil.'),
    'Choose whether the table displays recorded data metrics or calculated model metrics': 'Seleccione si la tabla muestra métricas de datos registrados o métricas de modelo calculados.',
    'Display metrics calculated for analysed model objects': 'Mostrar métricas calculadas para los objetos de modelos analizados.',
    'Model metrics': 'Métricas de modelo',
    'Calculate model metrics before creating the table': 'Calcula las métricas del modelo antes de crear la tabla',
    'Calculate model metrics': 'Calcular métricas del modelo',
    'Calculated model observations': 'Observaciones de modelos calculadas',
    'Data Logger model observations': 'Observaciones del modelo de Data Logger',
    'Data ↔ Model': 'Datos ↔ Modelo',
    'Descriptive forest plot · z-score normalized metrics': 'Diagrama forest descriptivo · métricas normalizadas con puntuación z',
    'Duplicate vertices (%)': 'Vértices duplicados (%)',
    'Duplicate vertices (count)': 'Vértices duplicados (cantidad)',
    'Face count': 'Cantidad de caras',
    'Faces per connected part': 'Caras por parte conectada',
    'Geometry and object changes': 'Cambios de geometría y objetos',
    'Inverted normals (%)': 'Normales invertidas (%)',
    'Maximum octree depth used by geometric similarity': 'Profundidad máxima del octree usada por la similitud geométrica',
    'Maximum vertices stored in an octree leaf': 'Máximo de vértices almacenados en una hoja del octree',
    'Mesh': 'Malla',
    'Model analysis': 'Análisis del modelo',
    'Mesh issue changes': 'Cambios de problemas de malla',
    'Mesh issue changes in visible data: {count}': 'Cambios de problemas de malla en los datos visibles: {count}',
    'Model data': 'Datos de modelo',
    'Model metrics': 'Métricas de modelo',
    'Model metrics table': 'Tabla de métricas de modelo',
    'Model metrics table generated': 'Tabla de métricas de modelo generada',
    'Model object': 'Objeto de modelo',
    'Model ↔ Model': 'Modelo ↔ Modelo',
    'Model': 'Modelo',
    'Modifier changes': 'Cambios de modificadores',
    'Modifier changes in visible data: {count}': 'Cambios de modificadores en los datos visibles: {count}',
    'Negative = vertices removed · Positive = vertices added': 'Negativo = vértices eliminados · Positivo = vértices añadidos',
    'Net vertex change: {value}': 'Cambio neto de vértices: {value}',
    'Ngons': 'N-gons',
    'No Data ↔ Model associations have been created.': 'No se ha creado ninguna asociación Datos ↔ Modelo.',
    'No active model found.': 'No se encontró un modelo activo.',
    'Non-quad faces (%)': 'Caras no cuadrangulares (%)',
    'Normalized speed': 'Velocidad normalizada',
    'Normals': 'Normales',
    'Object model': 'Modelo',
    'Occlusion': 'Oclusión',
    'Per-metric min-max normalization': 'Normalización mínimo-máximo por métrica',
    'Reference model': 'Modelo de referencia',
    'Select a MODEL object': 'Selecciona un objeto de tipo MODELO',
    'Select a model and calculate metrics.': 'Selecciona una modelo y calcula las métricas.',
    'Select at least one model metric': 'Selecciona al menos una métrica de modelo',
    'Select at least two model metrics for the Model ↔ Model graph.': 'Selecciona al menos dos métricas de modelo para el gráfico Modelo ↔ Modelo.',
    'Empty radial margin kept inside and outside the normalized radar data': 'Margen radial vacío mantenido dentro y fuera de los datos de radar normalizados.',
    'Stop after the selected maximum octree depth': 'Detiene el cálculo al alcanzar la profundidad máxima seleccionada del octree',
    'Vertex changes': 'Cambios de vértices',
    'across analysed model objects': 'entre los objetos de modelo analizados',
    'faces': 'caras',
    'faces/part': 'caras/parte',
    'mesh mean': 'media de malla',
    'models': 'modelos',
    'vertices': 'vértices',
    'verts/min': 'vértices/min',
    'Select Data Logger Model Metrics Files': 'Seleccionar archivos de métricas de modelo de Data Logger',
    'No Data Logger model metrics were found in the selected files': 'No se encontraron métricas de modelos de Data Logger en los archivos seleccionados',
    'Imported model files': 'Archivos de modelos importados',
    'No Data Logger model metrics were found in this .blend file': 'No se encontraron métricas de modelo de Data Logger en este archivo .blend',
    'Data Logger model data could not be read': 'No se pudieron leer los datos de modelos de Data Logger',
    'Calculate geometric metrics for the active model and, if available, compare them with a reference': 'Calcula métricas geométricas de la modelos activa y, cuando exista, la compara con una referencia',
    'Use the model metrics embedded by Data Logger 3D for tables and graphs without recalculating the models': ('Usa en tablas y gráficos las métricas de modelos incrustadas por Data Logger 3D sin recalcular '
     'los modelos'),
    'Add data–model pair': 'Añadir pareja datos-modelo',
    'Remove data–model pair': 'Eliminar pareja datos–model',
    'Select Data Logger model Metrics File': 'Seleccionar archivo de métricas de modelo de Data Logger',
    'Data Logger model metrics file': 'Archivo de métricas de modelo de Data Logger',
    'Select a valid Data Logger model metrics file': 'Selecciona un archivo válido de métricas de modelo de Data Logger',
    'No Data Logger model metrics were found in the selected file': 'No se encontraron métricas de modelo de Data Logger en el archivo seleccionado',
    'Choose a calculated scene model or an imported Data Logger model observation': 'Elige un modelo calculado de la escena o una observación de modelo importada desde Data Logger',
    'No model observations': 'No hay observaciones de modelo',
    'Calculate or import model metrics first': 'Calcula o importa primero las métricas de modelo',
    'Compare normalized multivariate profiles from data metrics, model metrics or associations': ('Compara perfiles multivariantes normalizados de métricas de datos, métricas de modelos o '
     'asociaciones'),
    'Inspect Pearson correlations between selected data and/or model metrics': 'Examina correlaciones de Pearson entre las métricas de datos y/o de modelos seleccionadas',

    # ── 05 · Gráficos y visualización ──
    '3D Data ↔ Data Pearson correlation heatmap': 'Mapa de calor 3D de correlación de Pearson Datos ↔ Datos',
    'Accessible categorical palette': 'Paleta categórica accesible',
    'Broad high-contrast rainbow palette': 'Paleta arcoíris amplia de alto contraste',
    'Clear graphs': 'Borrar gráficos',
    'Color palette': 'Paleta de colores',
    'Color-vision-friendly uniform palette': 'Paleta uniforme apta para deficiencias de visión cromática',
    'Comparative radar generated': 'Radar comparativo generado',
    'Correlation type': 'Tipo de correlación',
    'Dark purple-to-yellow palette': 'Paleta oscura de morado a amarillo',
    'Diverging blue-to-red palette': 'Paleta divergente de azul a rojo',
    'Forest plot generated': 'Gráfico Forest generado',
    'Forest plot needs at least one selected metric': 'El forest plot necesita al menos una métrica seleccionada',
    'Graph': 'Gráfico',
    'Graph configuration': 'Configuración de gráficos',
    'Graphs generated': 'Gráficos generados',
    'High-contrast perceptually uniform palette': 'Paleta perceptualmente uniforme de alto contraste',
    'Metrics shown in the correlation graph': 'Métricas mostradas en el gráfico de correlación',
    'Mesh metrics': 'Métricas de malla',
    'Meshes count': 'Cantidad de mallas',
    'N meshes': 'N mallas',
    'Overlay': 'Solapado',
    'Overlay · independent Y scale per metric': 'Solapado · escala Y independiente por métrica',
    'Pearson correlation heatmap': 'Mapa de calor 3D de correlación de Pearson',
    'Percentage of the available rows shown in each Interaction Graph window': 'Porcentaje de las filas disponibles mostrado en cada ventana del gráfico de interacción',
    'Perceptually uniform palette': 'Paleta perceptualmente uniforme',
    'Radar margin': 'Margen del radar',
    'Radar plot needs at least three selected Data or Model metrics in total': 'El radar necesita al menos tres métricas seleccionadas en total entre Data Metrics y Model Metrics',
    'All selected': 'Todo lo seleccionado',
    'One radar with every selected metric': 'Un radar con todas las métricas seleccionadas',
    'Generate separate Temporal, Navigation, Editing and Workflow radars': 'Genera radares separados para Temporal, Navegación, Edición y Flujo de trabajo',
    'Navigation': 'Navegación',
    'Editing': 'Edición',
    'Workflow': 'Flujo de trabajo',
    'Only selected temporal metrics': 'Solo las métricas temporales seleccionadas',
    'Only selected navigation metrics': 'Solo las métricas de navegación seleccionadas',
    'Only selected editing metrics': 'Solo las métricas de edición seleccionadas',
    'Only selected workflow metrics': 'Solo las métricas de flujo de trabajo seleccionadas',
    'Percentage of the available rows shown in each interaction graph window': 'Porcentaje de las filas disponibles que se muestran en cada ventana de gráfico de interacción.',
    'Zero-based first row of the interaction graph window': 'Primera fila (con índice base cero) de la ventana del grafo de interacción',
    'Show all available interaction graph data before the numbered window': 'Mostrar todos los datos disponibles del grafo de interacciones antes de la ventana numerada.',
    'Clear the 3D graphs generated by the add-on from the scene': 'Elimina de la escena los gráficos 3D generados por el complemento.',
    'Visualize 3D graph': 'Visualizar gráfico 3D',
    'Visualize Graph': 'Visualizar gráfico',
    'Vivid purple-to-yellow palette': 'Paleta intensa de morado a amarillo',
    'Comparative radar': 'Radar comparativo',

    # ── 06 · Tablas y paginación ──
    '1. Table content': '1. Contenido de la tabla',
    '3D metric tables': 'Tablas 3D de métricas',
    'Average user speed calculated based on displacement and the time between rows. The local size is the bounding box used as a reference.': ('Velocidad media del usuario calculada en función del desplazamiento y del tiempo entre filas. El '
     'tamaño local es el cuadro delimitador utilizado como referencia.'),
    'Clear table': 'Borrar tabla',
    'Column page': 'Página de columnas',
    'Columns': 'Columnas',
    'Create 3D table': 'Crear tabla 3D',
    'Data table generated': 'Tabla de datos generada',
    'Next rows': 'Filas siguientes',
    'No valid data could be loaded for the table': 'No se pudieron cargar datos válidos para la tabla',
    'Previous rows': 'Filas anteriores',
    'Remove the 3D data tables generated by the add-on': 'Elimina las tablas de datos 3D generadas por el complemento.',
    'Row': 'Fila',
    'Row page': 'Página de filas',
    'Rows': 'Filas',
    'Rows per window (%)': 'Filas por ventana (%)',
    'Shortcut events per row: Ctrl+V, Shift+D and Alt+D': 'Eventos de atajo por fila: Ctrl+V, Shift+D y Alt+D',
    'Table data source': 'Fuente de datos de la tabla',
    'Zero-based first row of the G1 window': 'Primera fila de la ventana G1, empezando en cero',
    'columns': 'columnas',
    'rows': 'filas',
    'Visualize Data Table': 'Visualizar tabla de datos',

    # ── 07 · Botones, acciones y controles ──
    '2. Create / Control': '2. Crear / Controlar',
    'UV work events calculated as total, rate, and quartiles.': 'Eventos del modo de trabajo relacionados con la textura UV calculada como total, tasa y cuartiles.',
    'Calculate Data Metric Stats': 'Calcular estadísticas de los datos',
    'Calculate Metrics': 'Calcular métricas',
    'Compare the selected observations': 'Compara las observaciones seleccionadas',
    'Describe the selected observations': 'Describe las observaciones seleccionadas',
    'Hidden scene objects restored': 'Objetos ocultos de la escena restaurados',
    'Metric statistics calculated': 'Estadísticas de métricas calculadas',
    'Metrics selected': 'Métricas seleccionadas',
    'Negative = objects removed · Positive = objects added': 'Negativo = objetos eliminados · Positivo = objetos añadidos',
    'No metrics calculated yet.': 'Todavía no se han calculado métricas.',
    'Refresh list': 'Actualizar lista',
    'Remove association': 'Eliminar asociación',
    'Restore objects': 'Restaurar objetos',
    'Restore scene objects': 'Restaurar objetos de escena',
    'Select': 'Seleccionar',
    'Select at least one metric': 'Selecciona al menos una métrica',
    'Select original members': 'Seleccionar miembros originales',
    'Show all available G1 data before the numbered windows': 'Muestra todos los datos G1 disponibles antes de las ventanas numeradas',
    'Show every recorded value without aggregation': 'Muestra todos los valores registrados sin agregarlos',
    'Show metrics in separate bands or superimposed with an independent real range per metric': ('Mostrar las métricas en bandas separadas o superpuestas, con un rango real independiente para '
     'cada métrica.'),
    'The selected metrics contain no valid values': 'Las métricas seleccionadas no contienen valores válidos',
    'Selected file': 'Archivo seleccionado',
    'Show selected metrics through ordered samples to inspect trends, peaks and pauses': ('Muestra las métricas seleccionadas a través de muestras ordenadas para inspeccionar tendencias, '
     'picos y pausas'),

    # ── 08 · Avisos, validaciones y errores ──
    '0 = No UV topology change · 1 = UV topology change': '0 = Sin cambio de topología UV · 1 = Cambio de topología UV',
    '0 = No pause · 1 = Detected pause': '0 = Sin pausa · 1 = Pausa detectada',
    '0 = No peak · 1 = Detected peak': '0 = Sin pico · 1 = Pico detectado',
    'Last valid observed value': 'Último valor válido observado',
    'Missing': 'Faltan',
    'No change': 'Sin cambio',
    'No effect': 'Sin efecto',
    'No pause': 'Sin pausa',
    'No peak': 'Sin pico',
    'Number of valid observations': 'Número de observaciones válidas',
    'Valid associations': 'Asociaciones válidas',
    'no aggregation': 'sin agregación',
    'Relative distance divides the travelled view distance by the object local size. A value of 1 means a travelled distance equal to one object size; it is dimensionless and allows sessions with differently sized objects to be compared.': ('La distancia relativa divide la distancia recorrida por la vista entre el tamaño local del '
     'objeto. Un valor de 1 significa recorrer una distancia igual a un tamaño del objeto; no tiene '
     'unidades y permite comparar sesiones con objetos de distinto tamaño.'),
    'Average distance between user and object, expressed in metres using the scene unit scale. Relative distance divides that distance by the object local size: 1.0 equals one object size, so the value is dimensionless and comparable across differently sized objects.': ('Distancia media entre el usuario y el objeto, expresada en metros mediante la escala de unidades '
     'de la escena. La distancia relativa divide esa distancia entre el tamaño local del objeto: 1,0 '
     'equivale a un tamaño del objeto, por lo que no tiene unidades y permite comparar objetos de '
     'tamaños distintos.'),

    # ── 09 · Métricas de interacción y sesión ──
    'Active movement peaks': 'Picos de movimiento activo',
    'Average distance between the user and the object. A relative distance of 1.0 corresponds to the size of the object, allowing for comparisons between objects of different sizes.': ('Distancia promedio entre el usuario y el objeto. Una distancia relativa de 1,0 corresponde al '
     'tamaño del objeto, lo que permite realizar comparaciones entre objetos de diferentes tamaños.'),
    'Detects unusually high movement speed during the session and highlights periods in which the user moves significantly faster than usual.': ('Detecta una velocidad de movimiento inusualmente alta durante la sesión y resalta los periodos '
     'en los que el usuario se desplaza significativamente más rápido de lo habitual.'),
    'Summarizes the activity of Object mode, Percentage Editing mode, and UV working mode.': 'Resume la actividad del modo Objeto, el modo de edición por porcentaje y el modo de trabajo UV.',
    'Detected pauses in visible data: {count}': 'Pausas detectadas en los datos visibles: {count}',
    'Detected peaks in visible data: {count}': 'Picos detectados en los datos visibles: {count}',
    'Distance to object': 'Distancia al objeto',
    'Idle movement peaks': 'Picos de movimiento en pausa',
    'Mean peak speed': 'Velocidad media de pico',
    'Mode and UV work': 'Trabajo de modos y UV',
    'Movement peaks': 'Picos de movimiento',
    'Pause': 'Pausa',
    'Pauses': 'Pausas',
    'Pauses by phase': 'Pausas por fase',
    'Peak': 'Pico',
    'Relative distance': 'Distancia relativa',
    'Session duration': 'Duración de la sesión',
    'Session progress (%)': 'Progreso de la sesión (%)',
    'Shortcut events in visible data: {count}': 'Eventos de atajo en los datos visibles: {count}',
    'Shortcut reuse': 'Reutilización de atajos',
    'Total pauses': 'Pausas totales',
    'Total peaks': 'Picos totales',
    'Travel peaks': 'Picos de desplazamiento',
    'UV Mapping': 'Mapeado UV',
    'UV area': 'Área UV',
    'UV change': 'Cambio UV',
    'UV changes in visible data: {count}': 'Cambios UV en los datos visibles: {count}',
    'UV islands': 'Islas UV',
    'UV stretch': 'Estiramiento UV',
    'UV work': 'Trabajo UV',
    'View movement peaks': 'Picos de movimiento de vista',
    'View speed': 'Velocidad de vista',
    'pauses': 'pausas',
    'pauses/min': 'pausas/min',
    'peaks': 'picos',
    'peaks/min': 'picos/min',

    # ── 10 · Ayudas y descripciones ──
    'They are detected based on unusually long intervals without editing events and are also expressed in terms of quartiles.': ('Se detectan a partir de intervalos inusualmente largos sin eventos de edición y también se '
     'expresan en términos de cuartiles.'),

    # ── 11 · Etiquetas generales ──
    '%': '%',
    '%  Edit': '%  Edición',
    '%  Object': '%  Objeto',
    '0 = Other · 1 = Object Mode · 2 = Edit Mode': '0 = Otro · 1 = Modo Objeto · 2 = Modo Edición',
    '1. Visual Settings': '1. Ajustes visuales',
    '2. Global Data Metrics': '2. Métricas de datos globales',
    '2. Render / Control': '2. Renderizado / Control',
    '3. Layout and pagination': '3. Diseño y paginación',
    'Add association': 'Añadir asociación',
    'All data': 'Todos los datos',
    'All metrics superimposed; each metric keeps its own real Y range': 'Todas las métricas superpuestas; cada una conserva su propio rango Y real',
    'All raw values': 'Todos los valores brutos',
    'All recorded values': 'Todos los valores registrados',
    'Arithmetic mean of each metric series': 'Media aritmética de la serie de cada métrica',
    'Association': 'Asociación',
    'At world origin': 'En el origen global',
    'Average state': 'Estado medio',
    'm': 'm',
    'm/min': 'm/min',
    'Bands': 'Bandas',
    'Both limits': 'Ambos límites',
    'Percentage in Object Mode, Edit Mode, and mode-switch frequency.': 'Porcentaje en modo Objeto, modo Edición y frecuencia de cambio de modo.',
    'Data metrics': 'Métricas de datos',
    'Changes': 'Cambios',
    'Compact labels': 'Etiquetas compactas',
    'Comparative': 'Comparativo',
    'Parts': 'Partes',
    'Context Help': 'Ayuda contextual',
    'Count': 'Recuento',
    'Data': 'Datos',
    'Data Metric Stats': 'Estadísticas de métricas de los datos',
    'Data visualizer': 'Visualizador de datos',
    'Data ↔ Data': 'Datos ↔ Datos',
    'Descriptive': 'Descriptivo',
    'Displayed value': 'Valor mostrado',
    'Duration': 'Duración',
    'Edit Mode': 'Modo Edición',
    'Effective N': 'N efectivo',
    'Elements per node': 'Elementos por nodo',
    'Evaluate inferential relationships between observations': 'Evalúa relaciones inferenciales entre observaciones',
    'Events': 'Eventos',
    'Frequency': 'Frecuencia',
    'Independent Y ranges': 'Rangos Y independientes',
    'Inferential': 'Inferencial',
    'Interaction': 'Interacción',
    'Largest observed value': 'Mayor valor observado',
    'Last value': 'Último valor',
    'Local size': 'Tamaño local',
    'Log scale': 'Escala logarítmica',
    'Maximum': 'Máximo',
    'Maximum elements': 'Elementos máximos',
    'Maximum subdivisions': 'Subdivisiones máximas',
    'Mean': 'Media',
    'Mean edge angle': 'Ángulo medio de aristas',
    'Median': 'Mediana',
    'Median of each metric series': 'Mediana de la serie de cada métrica',
    'Metric detail': 'Detalle de métricas',
    'Metrics': 'Métricas',
    'Minimum': 'Mínimo',
    'Minimum observations: 3': 'Observaciones mínimas: 3',
    'Mode changes': 'Cambios de modo',
    'Net object change: {value}': 'Cambio neto de objetos: {value}',
    'Next data window': 'Ventana de datos siguiente',
    'Next metrics': 'Métricas siguientes',
    'Object': 'Objeto',
    'Object / Data': 'Objeto / Datos',
    'Object Mode': 'Modo Objeto',
    'Object changes': 'Cambios de objetos',
    'Observations': 'Datos',
    'One independent vertical band per metric': 'Una banda vertical independiente por métrica',
    'Open detailed contextual help': 'Abre una ayuda contextual detallada con objetivo, controles, resultado y requisitos.',
    'Operations': 'Operaciones',
    'Overall': 'Global',
    'Previous data window': 'Ventana de datos anterior',
    'Previous metrics': 'Métricas anteriores',
    'Range of samples': 'Rango de muestras',
    'Rate': 'Tasa',
    'Reference Object': 'Objeto de referencia',
    'Reference mean': 'Media de referencia',
    'Sample standard deviation': 'Desviación estándar muestral',
    'Scale X': 'Escala X',
    'Scale Y': 'Escala Y',
    'Scale Z': 'Escala Z',
    'Section': 'Sección',
    'Showing': 'Mostrando',
    'Similarity': 'Similitud',
    'Similarity vs. reference': 'Similitud con la referencia',
    'Smallest observed value': 'Menor valor observado',
    'Spatial': 'Espacial',
    'Standard deviation': 'Desviación estándar',
    'Std. dev.': 'Desv. estándar',
    'Stop when either the depth or element limit is reached': 'Detiene el cálculo al alcanzar el límite de profundidad o de elementos',
    'Strategy': 'Estrategia',
    'Sum': 'Suma',
    'Sum of all observed values': 'Suma de todos los valores observados',
    'Temporal': 'Temporal',
    'Texel density': 'Densidad de téxel',
    'Topology': 'Topología',
    'Total': 'Total',
    'Total delta': 'Delta total',
    'Total errors': 'Errores totales',
    'Transforms & Position': 'Transformaciones y posición',
    'Transforms applied': 'Transformaciones aplicadas',
    'Triangles': 'Triángulos',
    'Work mode': 'Modo de trabajo',
    'and': 'y',
    'between-user standard deviation': 'desviación estándar entre usuarios',
    'changes': 'cambios',
    'chg/min': 'cambios/min',
    'err/min': 'errores/min',
    'errors': 'errores',
    'events': 'eventos',
    'events/min': 'eventos/min',
    'Only completed unwrap/deployment operations are counted. Ordinary UV editing is ignored.': 'Solo se cuentan las operaciones de despliegue/unwrap completadas. La edición UV normal se ignora.',
    'events/min': 'eventos/min',
    'Only completed unwrap/deployment operations are counted. Ordinary UV editing is ignored.': 'Solo se cuentan las operaciones de despliegue/unwrap completadas. La edición UV normal se ignora.',
    'islands': 'islas',
    'issues': 'problemas',
    'metrics': 'métricas',
    'min': 'min',
    'mode code': 'código de modo',
    'local size/min': 'tamaño local/min',
    '× local size': '× tamaño local',
    'x local size': '× tamaño local',
    'objects': 'objetos',
    'of': 'de',
    'paired by name': 'emparejado por nombre',
    'paired by order': 'emparejado por orden',
    'parts': 'partes',
    'raw observations': 'observaciones brutas',
    'samples': 'muestras',
    'two decimals': 'dos decimales',
    'u.local': 'u. local',
    'user mean': 'media de usuarios',
    'users': 'usuarios',
    'values': 'valores',
    'values shown with two decimals': 'valores mostrados con dos decimales',
    'x obj. size': 'x tamaño',
    'z-score': 'puntuación z',
    'z-score [95% adjusted CI for data]': 'Puntuación z [IC del 95 % ajustado para datos]',
    'Skipped files': 'Archivos omitidos',
    'margin': 'margen',
    'min-max': 'mínimo-máximo',
    'Separates modifiers created and deleted. Net change is created minus deleted; quartiles show the signed balance in each quarter.': 'Separa los modificadores creados y eliminados. El cambio neto es creados menos eliminados; los cuartiles muestran el balance con signo de cada cuarto.',
    'Created': 'Creados',
    'Deleted': 'Eliminados',
    'Net change': 'Cambio neto',
    'modifiers': 'modificadores',
    'net modifiers': 'modificadores netos',
    'Additions/creations are positive and removals/deletions are negative. Quartiles show the algebraic balance inside each quarter.': 'Las adiciones/creaciones son positivas y las eliminaciones/borrados son negativas. Los cuartiles muestran el balance algebraico dentro de cada cuarto.',
    'Shows vertices added, removed, and their net result.': 'Muestra los vértices añadidos, eliminados y su resultado neto.',
    'Added': 'Añadidos',
    'Removed': 'Eliminados',
    'net vertices': 'vértices netos',
    'Positive values add issues and negative values remove/fix them.': 'Los valores positivos añaden incidencias y los negativos las eliminan o corrigen.',
    'net issues': 'incidencias netas',
    'Shows objects created, deleted, and their net balance.': 'Muestra los objetos creados, eliminados y su balance neto.',
    'net objects': 'objetos netos',
    'Percentage of time in Object Mode and Edit Mode, plus mode-switch frequency.': 'Porcentaje de tiempo en Modo Objeto y Modo Edición, además de la frecuencia de cambios de modo.',
    '% Object': '% Objeto',
    '% Edit': '% Edición',
    'Counts Ctrl+V, Shift+D and Alt+D separately; total and frequency remain available.': 'Cuenta Ctrl+V, Shift+D y Alt+D por separado; también mantiene el total y la frecuencia.',
    'Counts the three tracked modelling shortcuts separately. The total is not used as a substitute for the individual behaviours.': 'Cuenta por separado los tres atajos de modelado registrados. El total no sustituye el análisis de cada comportamiento individual.',
    'Completed UV actions separated into unwrap/deploy, transforms and other UV operations.': 'Acciones UV completadas separadas en despliegue/desenvoltura, transformaciones y otras operaciones UV.',
    'Counts completed UV actions. Deployment, transforms and other UV operations are separated so the metric is interpretable.': 'Cuenta las acciones UV completadas. El despliegue, las transformaciones y otras operaciones UV se separan para que la métrica sea interpretable.',
    'Deploy / unwrap': 'Desplegar / desenvolver',
    'UV transforms': 'Transformaciones UV',
    'Other UV actions': 'Otras acciones UV',
    'Occlusion / see-through': 'Oclusión / transparencia',
    'X-Ray/Wireframe use measured as state: activations, active minutes and percentage of session.': 'El uso de Rayos X/Wireframe se mide como un estado: activaciones, minutos activos y porcentaje de la sesión.',
    'Measures use of X-Ray or Wireframe as a state: activations, active time and percentage of session. It no longer counts every active row as a separate event.': 'Mide el uso de Rayos X o Wireframe como un estado: activaciones, tiempo activo y porcentaje de la sesión. Ya no cuenta cada fila activa como un evento independiente.',
    'Activations': 'Activaciones',
    'Active time': 'Tiempo activo',
    'Session active': 'Sesión activa',
    'Activation frequency': 'Frecuencia de activación',
    '% active': '% activo',
    'Signed modifier balance per row: positive created, negative deleted.': 'Balance de modificadores con signo por fila: positivo = creados, negativo = eliminados.',
    'Signed vertex balance per row: positive added, negative removed.': 'Balance de vértices con signo por fila: positivo = añadidos, negativo = eliminados.',
    'Signed mesh-issue balance per row: positive added, negative fixed/removed.': 'Balance de incidencias de malla con signo por fila: positivo = añadidas, negativo = corregidas/eliminadas.',
    'Signed object balance per row: positive created, negative deleted.': 'Balance de objetos con signo por fila: positivo = creados, negativo = eliminados.',
    'Tracked shortcut events per row: Ctrl+V, Shift+D and Alt+D.': 'Eventos de atajos registrados por fila: Ctrl+V, Shift+D y Alt+D.',
    'Shortcut events in visible data: {value}': 'Eventos de atajos en los datos visibles: {value}',
    '0 = no completed UV action; 1 = completed UV action.': '0 = ninguna acción UV completada; 1 = acción UV completada.',
    'No UV action': 'Sin acción UV',
    'UV action': 'Acción UV',
    'UV actions in visible data: {value}': 'Acciones UV en los datos visibles: {value}',
    'See-through state: 1 when X-Ray or Wireframe is active.': 'Estado de transparencia: 1 cuando Rayos X o Wireframe está activo.',
    'Off': 'Desactivado',
    'On': 'Activado',
    'Active samples: {value}%': 'Muestras activas: {value}%',
    'modifier Δ': 'Δ modificadores',
    'vertex Δ': 'Δ vértices',
    'issue Δ': 'Δ incidencias',
    'object Δ': 'Δ objetos',
    'state': 'estado',
    'net modifiers/min': 'modificadores netos/min',
    'net vertices/min': 'vértices netos/min',
    'net issues/min': 'incidencias netas/min',
    'net objects/min': 'objetos netos/min',
    'Completed explicit UV actions separated into unwrap/deploy, transforms and other UV operations. Mesh topology changes alone are not counted as UV work.': 'Acciones UV explícitas completadas separadas en despliegue/desenvoltura, transformaciones y otras operaciones UV. Los cambios de topología de la malla por sí solos no se cuentan como trabajo UV.',
}

# Contextual help uses the same four-line structure and comparable detail in both languages.
HELP_EN = {

    # ── 03 · Datos, CSV e importación ──
    'CSV_IMPORT_LONG_HELP': ('Purpose: choose the data files used by the analysis.\n'
     'Controls: select a folder or file, refresh the list, and enable the required sources.\n'
     'Result: the same selection is shared by metrics, tables, and graphs.\n'
     'Notes: unreadable or missing files are skipped, while valid previous selections are preserved.'),
    'CSV_GROUPS_LONG_HELP': ('Purpose: combine several data files into one virtual observation.\n'
     'Controls: create, remove, or reopen a named group from selected files.\n'
     'Result: tables and graphs process the group as one source without changing its files.\n'
     'Notes: at least two files are required and calculations restart at each file boundary.'),
    'GLOBAL_CSV_METRICS_LONG_HELP': ('Purpose: calculate descriptive statistics for the selected data sources.\n'
     'Controls: select files or groups and run the data-metric calculation.\n'
     'Result: totals, rates, Q1–Q4, averages, dispersion, and metric context are displayed.\n'
     'Notes: missing, non-numeric, NaN, and infinite values are ignored.'),
    'DATA_MESH_ASSOCIATIONS_LONG_HELP': ('Purpose: define which data file belongs to each analysed model.\n'
     'Controls: add an association and choose one data source and one model in each row.\n'
     'Result: mixed Data ↔ Model graphs use these explicit pairs instead of automatic matching.\n'
     'Notes: load the data and calculate the model metrics before creating associations.'),
    'GRAPH_G2_LONG_HELP': ('Compares the central value and spread of a metric across files, groups, or models. Use it to see '
     'differences and overlap between observations.'),

    # ── 04 · Modelo y métricas de malla ──
    'MESH_LINK_LONG_HELP': ('Purpose: choose the model to analyse and an optional reference model.\n'
     'Controls: assign the target object and add a reference when a comparison is needed.\n'
     'Result: these objects are used by model calculations and compatible visualisations.\n'
     'Notes: both objects must be models; the reference is required only for similarity.'),
    'MESH_METRICS_LONG_HELP': ('Purpose: calculate geometric and structural measurements for a model.\n'
     'Controls: choose the target, optional reference, similarity limits, and run the calculation.\n'
     'Result: UV, normals, transforms, topology, texel density, and similarity values are stored.\n'
     'Notes: recalculating replaces the saved values for the same object.'),
    'TABLE_CONTENT_LONG_HELP': ('Purpose: choose the information displayed by the 3D table visualisation.\n'
     'Controls: select the data or model source, enable metrics, and choose the displayed value.\n'
     'Result: the visualisation includes only enabled metrics with valid values and units.\n'
     'Notes: unavailable or non-numeric values are omitted rather than estimated.'),
    'GRAPH_SETTINGS_LONG_HELP': ('Purpose: configure the content and appearance of the selected graph.\n'
     'Controls: choose the graph, data or model metrics, and its specific display options.\n'
     'Result: the current settings define the next 3D graph that will be generated.\n'
     'Notes: every graph checks its own minimum metrics, observations, and valid associations.'),
    'NORMALS_LONG_HELP': ('Shows the percentage of faces with inverted normals. Lower values indicate more consistent '
     'orientation.'),
    'TOPOLOGY_LONG_HELP': ('Summarises faces, connected parts, duplicates, non-quads, and edge angles to assess mesh '
     'structure.'),
    'SIMILARITY_LONG_HELP': ('Compares the analysed model with the selected reference. Higher values indicate greater measured '
     'similarity.'),
    'GRAPH_G3_LONG_HELP': ('Compares several normalized metrics as a profile. Use it to identify similarities and '
     'differences in the overall shape of data, models, or their associations.'),
    'GRAPH_G4_LONG_HELP': ('Shows the direction and strength of linear relationships between selected metrics. Choose Data ↔ '
     'Model, Data ↔ Data, or Model ↔ Model.'),

    # ── 05 · Gráficos y visualización ──
    'RENDER_CONTROLS_LONG_HELP': ('Purpose: generate and manage the 3D graph inside Blender.\n'
     'Controls: set X, Y, and Z display scales, generate, clear, or restore hidden objects.\n'
     'Result: the graph is rebuilt with the current selection and visual settings.\n'
     'Notes: scale values change only the display size, not the underlying measurements.'),
    'GRAPH_G1_LONG_HELP': ('Shows how the selected metrics change along the Timeline of recorded samples. Use it to detect '
     'peaks, pauses, trends, and changes during the session.'),

    # ── 06 · Tablas y paginación ──
    'TABLE_CONTROL_LONG_HELP': ('Purpose: create and manage the generated 3D table visualisation.\n'
     'Controls: generate it, clear generated table objects, or restore objects hidden for viewing.\n'
     'Result: the current table is rebuilt in the active visualisation scene.\n'
     'Notes: clearing affects only add-on objects and cannot restore deleted user objects.'),
    'TABLE_LAYOUT_LONG_HELP': ('Purpose: control the size and pagination of the table visualisation.\n'
     'Controls: set rows and metrics per page, then navigate with arrows or page sliders.\n'
     'Result: only the visible page changes; selected sources and metrics remain unchanged.\n'
     'Notes: smaller pages improve readability when labels or values are long.'),

    # ── 09 · Métricas de interacción y sesión ──
    'UV_MAPPING_LONG_HELP': ('Summarises UV coverage, islands, stretch, and texel density. Use it to spot fragmented or '
     'distorted mapping.'),

    # ── 11 · Etiquetas generales ──
    'TRANSFORMS_LONG_HELP': 'Checks whether transforms are applied and whether the object is at the world origin.',
}

HELP_ES = {

    # ── 03 · Datos, CSV e importación ──
    'CSV_IMPORT_LONG_HELP': ('Objetivo: elegir los archivos de datos utilizados en el análisis.\n'
     'Controles: selecciona una carpeta o archivo, actualiza la lista y activa las fuentes '
     'necesarias.\n'
     'Resultado: la misma selección se comparte entre métricas, tablas y gráficos.\n'
     'Notas: se omiten archivos ausentes o ilegibles y se conservan las selecciones anteriores '
     'válidas.'),
    'CSV_GROUPS_LONG_HELP': ('Objetivo: combinar varios archivos de datos en una única observación virtual.\n'
     'Controles: crea, elimina o vuelve a abrir un grupo con los archivos seleccionados.\n'
     'Resultado: tablas y gráficos procesan el grupo como una fuente sin modificar sus archivos.\n'
     'Notas: se requieren dos archivos como mínimo y los cálculos reinician en cada límite.'),
    'GLOBAL_CSV_METRICS_LONG_HELP': ('Objetivo: calcular estadísticas descriptivas para las fuentes de datos seleccionadas.\n'
     'Controles: selecciona archivos o grupos y ejecuta el cálculo de métricas de datos.\n'
     'Resultado: se muestran totales, tasas, Q1–Q4, medias, dispersión y contexto de cada métrica.\n'
     'Notas: se ignoran valores ausentes, no numéricos, NaN e infinitos.'),
    'CSV_METRICS_LONG_HELP': ('Objetivo: consultar las estadísticas calculadas de cada categoría de datos.\n'
     'Controles: despliega una categoría y sus bloques de métricas para ver los resultados.\n'
     'Resultado: aparecen juntos valores, unidades, totales, frecuencias, Q1–Q4 y estadísticas.\n'
     'Notas: solo se muestran métricas disponibles en la grabación seleccionada.'),
    'DATA_MESH_ASSOCIATIONS_LONG_HELP': ('Objetivo: definir qué archivo de datos pertenece a cada modelo analizada.\n'
     'Controles: añade una asociación y elige una fuente de datos y una modelo en cada fila.\n'
     'Resultado: los gráficos mixtos Datos ↔ Modelo usan estas parejas en vez del emparejamiento '
     'automático.\n'
     'Notas: carga los datos y calcula las métricas de modelo antes de crear asociaciones.'),
    'GRAPH_G2_LONG_HELP': ('Compara el valor central y la dispersión de una métrica entre archivos, grupos o modelos. Úsalo '
     'para observar diferencias y solapamientos.'),

    # ── 04 · Modelo y métricas de malla ──
    'MESH_LINK_LONG_HELP': ('Objetivo: elegir la modelo que se analizará y una referencia opcional.\n'
     'Controles: asigna el objeto objetivo y añade una referencia cuando necesites comparar.\n'
     'Resultado: estos objetos se usan en los cálculos de modelo y visualizaciones compatibles.\n'
     'Notas: ambos deben ser modelos; la referencia solo es obligatoria para la similitud.'),
    'MESH_METRICS_LONG_HELP': ('Objetivo: calcular medidas geométricas y estructurales de una modelo.\n'
     'Controles: elige objetivo, referencia opcional, límites de similitud y ejecuta el cálculo.\n'
     'Resultado: se guardan UV, normales, transformaciones, topología, densidad de téxel y similitud.\n'
     'Notas: recalcular sustituye los valores almacenados para el mismo objeto.'),
    'TABLE_CONTENT_LONG_HELP': ('Objetivo: elegir la información mostrada en la visualización de tabla 3D.\n'
     'Controles: selecciona la fuente de datos o modelo, activa métricas y elige el valor mostrado.\n'
     'Resultado: la visualización incluye solo métricas activas con valores y unidades válidos.\n'
     'Notas: los valores no disponibles o no numéricos se omiten y no se estiman.'),
    'GRAPH_SETTINGS_LONG_HELP': ('Objetivo: configurar el contenido y el aspecto del gráfico seleccionado.\n'
     'Controles: elige el gráfico, las métricas de datos o modelo y sus opciones específicas.\n'
     'Resultado: los ajustes actuales definen el siguiente gráfico 3D que se generará.\n'
     'Notas: cada gráfico valida sus métricas, observaciones y asociaciones mínimas.'),
    'NORMALS_LONG_HELP': ('Muestra el porcentaje de caras con normales invertidas. Los valores bajos indican una '
     'orientación más coherente.'),
    'TOPOLOGY_LONG_HELP': ('Resume caras, partes conectadas, duplicados, no cuadrangulares y ángulos para evaluar la '
     'estructura de la malla.'),
    'SIMILARITY_LONG_HELP': ('Compara el modelo analizada con la referencia seleccionada. Los valores altos indican mayor '
     'similitud medida.'),
    'GRAPH_G3_LONG_HELP': ('Compara varias métricas normalizadas como un perfil. Úsalo para identificar similitudes y '
     'diferencias en la forma general de datos, modelos o sus asociaciones.'),
    'GRAPH_G4_LONG_HELP': ('Muestra la dirección y la intensidad de las relaciones lineales entre las métricas '
     'seleccionadas. Elige Datos ↔ Modelos, Datos ↔ Datos o Modelos ↔ Modelos.'),

    # ── 05 · Gráficos y visualización ──
    'RENDER_CONTROLS_LONG_HELP': ('Objetivo: generar y gestionar el gráfico 3D dentro de Blender.\n'
     'Controles: define escalas X, Y y Z, genera, borra o restaura objetos ocultos.\n'
     'Resultado: el gráfico se reconstruye con la selección y los ajustes visuales actuales.\n'
     'Notas: las escalas cambian solo el tamaño visual, no las mediciones originales.'),
    'GRAPH_G1_LONG_HELP': ('Muestra cómo cambian las métricas seleccionadas a lo largo de la línea de tiempo de las muestras registradas. Úsalo '
     'para detectar picos, pausas, tendencias y cambios durante la sesión.'),

    # ── 06 · Tablas y paginación ──
    'TABLE_CONTROL_LONG_HELP': ('Objetivo: crear y gestionar la visualización de tabla 3D generada.\n'
     'Controles: genera, borra los objetos de tabla o restaura objetos ocultos para visualizar.\n'
     'Resultado: la tabla actual se reconstruye en la escena de visualización activa.\n'
     'Notas: borrar afecta solo a objetos del complemento y no recupera objetos eliminados.'),
    'TABLE_LAYOUT_LONG_HELP': ('Objetivo: controlar el tamaño y la paginación de la visualización de tabla.\n'
     'Controles: define filas y métricas por página y navega con flechas o deslizadores.\n'
     'Resultado: cambia solo la página visible y se mantienen fuentes y métricas seleccionadas.\n'
     'Notas: utiliza páginas pequeñas cuando las etiquetas o los valores sean largos.'),

    # ── 09 · Métricas de interacción y sesión ──
    'UV_MAPPING_LONG_HELP': ('Resume cobertura UV, islas, estiramiento y densidad de téxel. Úsalo para detectar un mapeado '
     'fragmentado o deformado.'),

    # ── 11 · Etiquetas generales ──
    'TRANSFORMS_LONG_HELP': 'Comprueba si las transformaciones están aplicadas y si el objeto está en el origen global.',
}


# Additional externalized UI strings. These keys keep all visible wording in this file.
UI_TEXT.update({
    'EXT_1_DATA_IMPORT': '1. Data import',
    'EXT_1_MODEL_SELECTOR': '1. Model selector',
    'EXT_1_TABLE_CONTENT': '1. Table content',
    'EXT_1_VISUAL_SETTINGS': '1. Visual Settings',
    'EXT_2_CREATE_CONTROL': '2. Create / Control',
    'EXT_2_GLOBAL_DATA_METRICS': '2. Global Data Metrics',
    'EXT_2_MODEL_METRICS': '2. Model Metrics',
    'EXT_2_RENDER_CONTROL': '2. Render / Control',
    'EXT_3D_DATA_MODEL_PEARSON_CORRELATION_HEATMAP': '3D Data ↔ Model Pearson correlation heatmap',
    'EXT_3D_METRIC_TABLES': '3D metric tables',
    'EXT_3D_MODEL_MODEL_PEARSON_CORRELATION_HEATMAP': '3D Model ↔ Model Pearson correlation heatmap',
    'EXT_3_DATA_MODEL_ASSOCIATIONS': '3. Data ↔ Model associations',
    'EXT_3_LAYOUT_AND_PAGINATION': '3. Layout and pagination',
    'EXT_ACCESSIBLE_CATEGORICAL_PALETTE': 'Accessible categorical palette',
    'EXT_ACROSS_ANALYSED_MODEL_OBJECTS': 'across analysed model objects',
    'EXT_ADD_DATA_MODEL_PAIR': 'Add data–model pair',
    'EXT_ALL_METRICS_SUPERIMPOSED_EACH_METRIC_KEEPS_ITS_OWN_REAL_Y_RANGE': 'All metrics superimposed; each metric keeps its own real Y range',
    'EXT_ALL_RAW_VALUES': 'All raw values',
    'EXT_ARITHMETIC_MEAN_OF_EACH_METRIC_SERIES': 'Arithmetic mean of each metric series',
    'EXT_AT_WORLD_ORIGIN': 'At world origin',
    'EXT_AVERAGE_DISTANCE_BETWEEN_THE_USER_AND_THE_OBJECT_A_RELATIVE_DISTANCE_O': 'Average distance between the user and the object. A relative distance of 1.0 corresponds to the size of the object, allowing for comparisons between objects of different sizes.',
    'EXT_AVERAGE_DISTANCE_BETWEEN_USER_AND_OBJECT_EXPRESSED_IN_METRES_USING_THE': 'Average distance between user and object, expressed in metres using the scene unit scale. Relative distance divides that distance by the object local size: 1.0 equals one object size, so the value is dimensionless and comparable across differently sized objects.',
    'EXT_AVERAGE_USER_SPEED_CALCULATED_BASED_ON_DISPLACEMENT_AND_THE_TIME_BETWE': 'Average user speed calculated based on displacement and the time between rows. The local size is the bounding box used as a reference.',
    'EXT_BETWEEN_USER_STANDARD_DEVIATION': 'between-user standard deviation',
    'EXT_BOTH_LIMITS': 'Both limits',
    'EXT_BROAD_HIGH_CONTRAST_RAINBOW_PALETTE': 'Broad high-contrast rainbow palette',
    'EXT_CALCULATE_MODEL_METRICS_BEFORE_CREATING_THE_TABLE': 'Calculate model metrics before creating the table',
    'EXT_CALCULATE_OR_IMPORT_MODEL_METRICS_FIRST': 'Calculate or import model metrics first',
    'EXT_CHANGES': 'Changes',
    'EXT_COLOR_VISION_FRIENDLY_UNIFORM_PALETTE': 'Color-vision-friendly uniform palette',
    'EXT_COMPARATIVE': 'Comparative',
    'EXT_COMPARE_CENTRAL_VALUES_AND_SPREAD_ACROSS_FILES_GROUPS_OR_MODEL_OBSERVA': 'Compare central values and spread across files, groups or model observations',
    'EXT_COMPARE_NORMALIZED_MULTIVARIATE_PROFILES_FROM_DATA_METRICS_MODEL_METRI': 'Compare normalized multivariate profiles from data metrics, model metrics or associations',
    'EXT_COMPARE_THE_SELECTED_OBSERVATIONS': 'Compare the selected observations',
    'EXT_COUNT': 'Count',
    'EXT_COUNTS_SHORTCUT_REUSE_AND_MODIFIER_CHANGES_RECORDED_IN_THE_CSV_HELPING': 'Counts shortcut reuse and modifier changes recorded in the CSV, helping identify repeated actions and changes in the modelling workflow.',
    'EXT_COUNTS_THE_EXACT_CSV_FIELDS_CTRLV_SHIFTD_AND_ALTD_AND_THEIR_TOTAL_FREQ': 'Counts the exact CSV fields CtrlV, ShiftD, and AltD and their total frequency.',
    'EXT_CSV_FILE': 'CSV file',
    'EXT_CTRL_V_AND_SHIFT_D_ARE_SHOWN_TOGETHER_AS_DUPLICATE_ALT_D_IS_SHOWN_AS_I': 'Ctrl+V and Shift+D are shown together as Duplicate. Alt+D is shown as Instance.',
    'EXT_DARK_PURPLE_TO_YELLOW_PALETTE': 'Dark purple-to-yellow palette',
    'EXT_DATA_FILES_AND_STATISTICS': 'Data files and statistics',
    'EXT_DATA_LOGGER_MODEL_DATA_COULD_NOT_BE_READ': 'Data Logger model data could not be read',
    'EXT_DATA_LOGGER_MODEL_METRICS_FILE': 'Data Logger model metrics file',
    'EXT_DATA_LOGGER_MODEL_OBSERVATIONS': 'Data Logger model observations',
    'EXT_DATA_METRIC_STATS': 'Data Metric Stats',
    'EXT_DESCRIBE_THE_SELECTED_OBSERVATIONS': 'Describe the selected observations',
    'EXT_DESCRIPTIVE': 'Descriptive',
    'EXT_DESCRIPTIVE_FOREST_PLOT_Z_SCORE_NORMALIZED_METRICS': 'Descriptive forest plot · z-score normalized metrics',
    'EXT_DETECTS_UNUSUALLY_HIGH_MOVEMENT_SPEED_DURING_THE_SESSION_AND_HIGHLIGHT': 'Detects unusually high movement speed during the session and highlights periods in which the user moves significantly faster than usual.',
    'EXT_DISPLAY_METRICS_CALCULATED_FOR_ANALYSED_MODEL_OBJECTS': 'Display metrics calculated for analysed model objects',
    'EXT_DISPLAY_METRICS_CALCULATED_FROM_THE_SELECTED_DATA_FILES': 'Display metrics calculated from the selected data files',
    'EXT_DIVERGING_BLUE_TO_RED_PALETTE': 'Diverging blue-to-red palette',
    'EXT_DUPLICATE': 'Duplicate',
    'EXT_DUPLICATE_VERTICES': 'Duplicate vertices (%)',
    'EXT_DUPLICATE_VERTICES_COUNT': 'Duplicate vertices (count)',
    'EXT_DUPLICATION_EVENTS_PER_ROW_CTRL_V_SHIFT_D_DUPLICATE_ALT_D_INSTANCE': 'Duplication events per row: Ctrl+V/Shift+D = Duplicate; Alt+D = Instance.',
    'EXT_DUPLICATION_INSTANCING': 'Duplication / instancing',
    'EXT_EDIT': '%  Edit',
    'EXT_EFFECTIVE_N': 'Effective N',
    'EXT_ENGLISH': 'English',
    'EXT_ERRORS': 'errors',
    'EXT_ERRORS_GENERATED': 'Errors generated',
    'EXT_ERRORS_RESOLVED': 'Errors resolved',
    'EXT_ERR_MIN': 'err/min',
    'EXT_EVALUATE_INFERENTIAL_RELATIONSHIPS_BETWEEN_OBSERVATIONS': 'Evaluate inferential relationships between observations',
    'EXT_EVENTS': 'Events',
    'EXT_EVENTS_WITH_OTHER_UV_ACTION': 'Events with other UV action',
    'EXT_EVENTS_WITH_UNWRAP_DEPLOY': 'Events with unwrap / deploy',
    'EXT_EVENTS_WITH_UV_TRANSFORM': 'Events with UV transform',
    'EXT_EXTERNAL_BLEND_JSON_OR_CSV_FILE_CONTAINING_DATA_LOGGER_MODEL_METRICS': 'External .blend, .json or .csv file containing Data Logger model metrics',
    'EXT_FACES': 'faces',
    'EXT_FACES_PART': 'faces/part',
    'EXT_FACES_PER_CONNECTED_PART': 'Faces per connected part',
    'EXT_FACE_COUNT': 'Face count',
    'EXT_GENERATION_RATE': 'Generation rate',
    'EXT_GRAPH_CONFIGURATION': 'Graph configuration',
    'EXT_HIGH_CONTRAST_PERCEPTUALLY_UNIFORM_PALETTE': 'High-contrast perceptually uniform palette',
    'EXT_IMPORTED_MODEL_FILES': 'Imported model files',
    'EXT_IMPORT_DATA_LOGGER_MODEL_METRICS': 'Import Data Logger Model Metrics',
    'EXT_INFERENTIAL': 'Inferential',
    'EXT_INSPECT_PEARSON_CORRELATIONS_BETWEEN_SELECTED_DATA_AND_OR_MODEL_METRIC': 'Inspect Pearson correlations between selected data and/or model metrics',
    'EXT_INSTANCE': 'Instance',
    'EXT_INTERACTION': 'Interaction',
    'EXT_INVERTED_NORMALS': 'Inverted normals (%)',
    'EXT_ISLANDS': 'islands',
    'EXT_LARGEST_OBSERVED_VALUE': 'Largest observed value',
    'EXT_LAST_VALID_OBSERVED_VALUE': 'Last valid observed value',
    'EXT_LAST_VALUE': 'Last value',
    'EXT_LOCAL_SIZE': 'Local size',
    'EXT_LOCAL_SIZE_MIN': 'local size/min',
    'EXT_M': 'm',
    'EXT_MAXIMUM': 'Maximum',
    'EXT_MAXIMUM_ELEMENTS': 'Maximum elements',
    'EXT_MEAN_EDGE_ANGLE': 'Mean edge angle',
    'EXT_MEAN_PEAK_SPEED': 'Mean peak speed',
    'EXT_MEDIAN': 'Median',
    'EXT_MEDIAN_OF_EACH_METRIC_SERIES': 'Median of each metric series',
    'EXT_MESH': 'Mesh',
    'EXT_MESHES_COUNT': 'Meshes count',
    'EXT_MESH_ERROR_EVOLUTION_SEPARATED_BY_REGISTERED_ERROR_TYPE_NGONS_TRIANGLE': 'Mesh error evolution separated by registered error type: ngons, triangles, and normals.',
    'EXT_MESH_MEAN': 'mesh mean',
    'EXT_MESH_OBJECT_CHANGE_EVENTS_PLUS_ESTIMATED_MESH_OBJECT_COUNT_AT_THE_END_': 'Mesh/object change events plus estimated mesh/object count at the end of each quartile.',
    'EXT_METRIC_DETAIL': 'Metric detail',
    'EXT_MINIMUM': 'Minimum',
    'EXT_MODEL': 'Model',
    'EXT_MODELS': 'models',
    'EXT_MODEL_ANALYSIS': 'Model analysis',
    'EXT_MODEL_METRICS_TABLE': 'Model metrics table',
    'EXT_MODEL_METRICS_TABLE_GENERATED': 'Model metrics table generated',
    'EXT_MODEL_OBJECT': 'Model object',
    'EXT_MODE_AND_UV_WORK': 'Mode and UV work',
    'EXT_MODE_CODE': 'mode code',
    'EXT_MODIFIER_USE_OR_EQUIVALENT_ROW_LEVEL_CHANGES_DETECTED_PER_ROW': 'Modifier use or equivalent row-level changes detected per row.',
    'EXT_MOVEMENT_PEAKS': 'Movement peaks',
    'EXT_M_MIN': 'm/min',
    'EXT_NEW_ISSUES_AND_RESOLVED_ISSUES_ARE_SEPARATED_ERROR_TOTALS_COUNT_ONLY_I': 'New issues and resolved issues are separated. Error totals count only issues introduced, not their later resolution.',
    'EXT_NEXT_DATA_WINDOW': 'Next data window',
    'EXT_NEXT_METRICS': 'Next metrics',
    'EXT_NEXT_ROWS': 'Next rows',
    'EXT_NGONS': 'Ngons',
    'EXT_NGONS_GENERATED': 'Ngons generated',
    'EXT_NON_MANIFOLD_GENERATED': 'Non-manifold generated',
    'EXT_NON_QUAD_FACES': 'Non-quad faces (%)',
    'EXT_NORMALIZED_SPEED': 'Normalized speed',
    'EXT_NORMALS': 'Normals',
    'EXT_NORMALS_GENERATED': 'Normals generated',
    'EXT_NO_DATA_LOGGER_MODEL_METRICS_WERE_FOUND_IN_THE_SELECTED_FILE': 'No Data Logger model metrics were found in the selected file',
    'EXT_NO_DATA_LOGGER_MODEL_METRICS_WERE_FOUND_IN_THE_SELECTED_FILES': 'No Data Logger model metrics were found in the selected files',
    'EXT_NO_DATA_LOGGER_MODEL_METRICS_WERE_FOUND_IN_THIS_BLEND_FILE': 'No Data Logger model metrics were found in this .blend file',
    'EXT_NO_DATA_MODEL_ASSOCIATIONS_HAVE_BEEN_CREATED': 'No Data ↔ Model associations have been created.',
    'EXT_NO_EFFECT': 'No effect',
    'EXT_NO_MODEL_OBSERVATIONS': 'No model observations',
    'EXT_NUMBER_OF_VALID_OBSERVATIONS': 'Number of valid observations',
    'EXT_N_MESHES': 'N meshes',
    'EXT_OBJECT': '%  Object',
    'EXT_OBJECT_2883F1': 'Object',
    'EXT_OBJECT_DATA': 'Object / Data',
    'EXT_OCCLUSION_EVENTS_RECORDED_DIRECTLY_IN_THE_CSV_BY_DATA_LOGGER_SHOWING_W': 'Occlusion events recorded directly in the CSV by Data Logger, showing when visibility conditions such as X-Ray or wireframe mode were active during the session.',
    'EXT_OCCLUSION_EVENTS_SHOWING_WHEN_VISIBILITY_CONDITIONS_SUCH_AS_X_RAY_OR_W': 'Occlusion events showing when visibility conditions such as X-Ray or wireframe mode were active during the session.',
    'EXT_ONE_INDEPENDENT_VERTICAL_BAND_PER_METRIC': 'One independent vertical band per metric',
    'EXT_ONLY_COMPLETED_UNWRAP_DEPLOYMENT_OPERATIONS_ARE_COUNTED_ORDINARY_UV_ED': 'Only completed unwrap/deployment operations are counted. Ordinary UV editing is ignored.',
    'EXT_OPERATIONS': 'Operations',
    'EXT_OVERALL': 'Overall',
    'EXT_PARTS': 'Parts',
    'EXT_PARTS_909E6B': 'parts',
    'EXT_PAUSES': 'pauses',
    'EXT_PAUSES_MIN': 'pauses/min',
    'EXT_PEAKS': 'peaks',
    'EXT_PEAKS_MIN': 'peaks/min',
    'EXT_PEARSON_CORRELATION_HEATMAP': 'Pearson correlation heatmap',
    'EXT_PERCENTAGE_IN_OBJECT_MODE_EDIT_MODE_AND_MODE_SWITCH_FREQUENCY': 'Percentage in Object Mode, Edit Mode, and mode-switch frequency.',
    'EXT_PERCENTAGE_OF_THE_AVAILABLE_ROWS_SHOWN_IN_EACH_INTERACTION_GRAPH_WINDO': 'Percentage of the available rows shown in each Interaction Graph window',
    'EXT_PERCEPTUALLY_UNIFORM_PALETTE': 'Perceptually uniform palette',
    'EXT_PREVIOUS_DATA_WINDOW': 'Previous data window',
    'EXT_PREVIOUS_METRICS': 'Previous metrics',
    'EXT_PREVIOUS_ROWS': 'Previous rows',
    'EXT_RATE': 'Rate',
    'EXT_REFERENCE_MEAN': 'Reference mean',
    'EXT_RELATIVE_DISTANCE': 'Relative distance',
    'EXT_RELATIVE_DISTANCE_DIVIDES_THE_TRAVELLED_VIEW_DISTANCE_BY_THE_OBJECT_LO': 'Relative distance divides the travelled view distance by the object local size. A value of 1 means a travelled distance equal to one object size; it is dimensionless and allows sessions with differently sized objects to be compared.',
    'EXT_REMOVE_DATA_MODEL_PAIR': 'Remove data–model pair',
    'EXT_SAMPLE_STANDARD_DEVIATION': 'Sample standard deviation',
    'EXT_SELECTED_FILE': 'Selected file',
    'EXT_SELECT_AT_LEAST_ONE_MODEL_METRIC': 'Select at least one model metric',
    'EXT_SELECT_AT_LEAST_TWO_MODEL_METRICS_FOR_THE_MODEL_MODEL_GRAPH': 'Select at least two model metrics for the Model ↔ Model graph.',
    'EXT_SELECT_A_BLEND_JSON_OR_CSV_FILE_CONTAINING_DATA_LOGGER_MESH_METRICS': 'Select a .blend, .json or .csv file containing Data Logger mesh metrics',
    'EXT_SELECT_A_JSON_OR_CSV_DATA_LOGGER_MODEL_METRICS_FILE': 'Select a JSON or CSV Data Logger model metrics file',
    'EXT_SELECT_A_JSON_OR_CSV_FILE_CONTAINING_DATA_LOGGER_MODEL_METRICS': 'Select a .json or .csv file containing Data Logger model metrics',
    'EXT_SELECT_A_MODEL_AND_CALCULATE_METRICS': 'Select a model and calculate metrics.',
    'EXT_SELECT_A_MODEL_OBJECT': 'Select a MODEL object',
    'EXT_SELECT_A_VALID_DATA_LOGGER_MODEL_METRICS_FILE': 'Select a valid Data Logger model metrics file',
    'EXT_SELECT_DATA_LOGGER_MODEL_METRICS_FILE': 'Select Data Logger model Metrics File',
    'EXT_SELECT_DATA_LOGGER_MODEL_METRICS_FILES': 'Select Data Logger Model Metrics Files',
    'EXT_SELECT_ONE_OR_MORE_VALID_JSON_OR_CSV_DATA_LOGGER_MODEL_METRICS_FILES': 'Select one or more valid JSON or CSV Data Logger model metrics files',
    'EXT_SHOW_ALL_AVAILABLE_G1_DATA_BEFORE_THE_NUMBERED_WINDOWS': 'Show all available G1 data before the numbered windows',
    'EXT_SHOW_EVERY_RECORDED_VALUE_WITHOUT_AGGREGATION': 'Show every recorded value without aggregation',
    'EXT_SHOW_SELECTED_METRICS_THROUGH_ORDERED_SAMPLES_TO_INSPECT_TRENDS_PEAKS_': 'Show selected metrics through ordered samples to inspect trends, peaks and pauses',
    'EXT_SIMILARITY': 'Similarity',
    'EXT_SIMILARITY_VS_REFERENCE': 'Similarity vs. reference',
    'EXT_SMALLEST_OBSERVED_VALUE': 'Smallest observed value',
    'EXT_STANDARD_DEVIATION': 'Standard deviation',
    'EXT_STD_DEV': 'Std. dev.',
    'EXT_STOP_AFTER_THE_SELECTED_MAXIMUM_OCTREE_DEPTH': 'Stop after the selected maximum octree depth',
    'EXT_STOP_WHEN_EITHER_THE_DEPTH_OR_ELEMENT_LIMIT_IS_REACHED': 'Stop when either the depth or element limit is reached',
    'EXT_SUM': 'Sum',
    'EXT_SUMMARIZES_THE_ACTIVITY_OF_OBJECT_MODE_PERCENTAGE_EDITING_MODE_AND_UV_': 'Summarizes the activity of Object mode, Percentage Editing mode, and UV working mode.',
    'EXT_SUM_OF_ALL_OBSERVED_VALUES': 'Sum of all observed values',
    'EXT_TEXEL_DENSITY': 'Texel density',
    'EXT_TEXT': '%',
    'EXT_THEY_ARE_DETECTED_BASED_ON_UNUSUALLY_LONG_INTERVALS_WITHOUT_EDITING_EV': 'They are detected based on unusually long intervals without editing events and are also expressed in terms of quartiles.',
    'EXT_TOPOLOGY': 'Topology',
    'EXT_TOTAL_DELTA': 'Total delta',
    'EXT_TOTAL_DURATION_OF_THE_CSV_RECORDING_EXPRESSED_IN_MINUTES': 'Total duration of the CSV recording, expressed in minutes.',
    'EXT_TOTAL_ERRORS': 'Total errors',
    'EXT_TOTAL_PAUSES': 'Total pauses',
    'EXT_TOTAL_PEAKS': 'Total peaks',
    'EXT_TRANSFORMS_APPLIED': 'Transforms applied',
    'EXT_TRANSFORMS_POSITION': 'Transforms & Position',
    'EXT_TRIANGLES': 'Triangles',
    'EXT_TRIANGLES_GENERATED': 'Triangles generated',
    'EXT_UNIQUE_UV_EVENTS': 'Unique UV events',
    'EXT_USERS': 'users',
    'EXT_USER_MEAN': 'user mean',
    'EXT_UV_AREA': 'UV area',
    'EXT_UV_ISLANDS': 'UV islands',
    'EXT_UV_MAPPING': 'UV Mapping',
    'EXT_UV_STRETCH': 'UV stretch',
    'EXT_UV_SUBCATEGORIES_CAN_OVERLAP_ONE_UV_EVENT_MAY_BE_BOTH_UNWRAP_DEPLOY_AN': 'UV subcategories can overlap: one UV event may be both unwrap/deploy and transform. Total counts unique UV-event rows, so it is not the sum of the subcategories.',
    'EXT_UV_WORK_EVENTS_CALCULATED_AS_TOTAL_RATE_AND_QUARTILES': 'UV work events calculated as total, rate, and quartiles.',
    'EXT_U_LOCAL': 'u.local',
    'EXT_VERTEX_EVOLUTION_SHOWN_AS_TOTAL_DELTA_RATE_AND_QUARTILES': 'Vertex evolution shown as total delta, rate, and quartiles.',
    'EXT_VERTICES_MESH_ERRORS_AND_MESH_OBJECT_CHANGES_ARE_SEPARATED_SO_THAT_EAC': 'Vertices, mesh errors, and mesh/object changes are separated so that each type of activity can be analysed independently; every section includes its own quartiles.',
    'EXT_VERTS_MIN': 'verts/min',
    'EXT_VIVID_PURPLE_TO_YELLOW_PALETTE': 'Vivid purple-to-yellow palette',
    'EXT_X_OBJ_SIZE': 'x obj. size',
    'EXT_ZERO_BASED_FIRST_ROW_OF_THE_G1_WINDOW': 'Zero-based first row of the G1 window',
    'EXT_Z_SCORE_95_ADJUSTED_CI_FOR_DATA': 'z-score [95% adjusted CI for data]',
})


# Behaviour-metric and graph help text. Keeping these maps here avoids bilingual
# prose inside the panel/rendering modules.
ANALYSIS_METRIC_HELP_EN = {
    "A1": "Session duration in minutes.",
    "A2": "Detected pauses; in time series the value is duration, 0 = no pause.",
    "A3": "Pauses by phase; 0 = no pause in that sample.",
    "A4": "View speed; numeric movement-per-time value.",
    "A5": "View-to-object distance; numeric value.",
    "A6": "Event: 0 = no peak; 1 = view-movement peak.",
    "A7": "Event: 0 = no peak; 1 = idle-movement peak.",
    "A8": "Event: 0 = no peak; 1 = active-movement peak.",
    "A9": "Event: 0 = no peak; 1 = travel peak.",
    "A10": "Reuse events: Duplicate or Instance; summaries may show a rate.",
    "A11": "Modifier change: positive = created, negative = removed, 0 = no net change.",
    "A12": "Vertex change: positive = added, negative = removed.",
    "A13": "Mesh-issue change: positive = generated, negative = removed/resolved.",
    "A14": "Work Mode: 0 = Other, 1 = Object Mode, 2 = Edit Mode. Descriptive views show Object/Edit percentages whenever possible.",
    "A15": "UV deploy: 0 = no; 1 = completed unwrap/deployment operation.",
    "A16": "Object change: positive = created, negative = removed.",
    "A17": "Occlusion state: 0 = off; 1 = X-Ray/Wireframe active.",
    "A18": "Completed Undo action: 0 = none; 1 = Undo recorded.",
    "A19": "Orthographic viewport state: 0 = perspective/other; 1 = orthographic.",
}
ANALYSIS_METRIC_HELP_ES = {
    "A1": "Duración de sesión en minutos.",
    "A2": "Pausas detectadas; en series temporales el valor es duración, 0 = sin pausa.",
    "A3": "Pausas por fase; 0 = sin pausa en esa muestra.",
    "A4": "Velocidad de vista; valor numérico de movimiento por tiempo.",
    "A5": "Distancia entre vista y objeto; valor numérico.",
    "A6": "Evento: 0 = no pico; 1 = pico de movimiento de vista.",
    "A7": "Evento: 0 = no pico; 1 = pico de movimiento inactivo.",
    "A8": "Evento: 0 = no pico; 1 = pico de movimiento activo.",
    "A9": "Evento: 0 = no pico; 1 = pico de desplazamiento.",
    "A10": "Eventos de reutilización: Duplicar o Instanciar; en resúmenes puede mostrarse como tasa.",
    "A11": "Cambio de modificadores: positivo = creados, negativo = eliminados, 0 = neto sin cambio.",
    "A12": "Cambio de vértices: positivo = añadidos, negativo = eliminados.",
    "A13": "Cambio de problemas de malla: positivo = generados, negativo = eliminados/resueltos.",
    "A14": "Work Mode: 0 = Otro, 1 = Object Mode, 2 = Edit Mode. En vistas descriptivas se muestran porcentajes Object/Edit siempre que es posible.",
    "A15": "Despliegue UV: 0 = no; 1 = operación de unwrap/despliegue completada.",
    "A16": "Cambio de objetos: positivo = creados, negativo = eliminados.",
    "A17": "Estado de oclusión: 0 = desactivado; 1 = X-Ray/Wireframe activo.",
    "A18": "Acción de deshacer completada: 0 = ninguna; 1 = deshacer registrado.",
    "A19": "Estado de vista ortográfica: 0 = perspectiva/otro; 1 = ortográfica.",
}
GRAPH_METRIC_G1_EXTRA_EN = " G1 keeps the real series and adds a short summary of what was detected in the visible window."
GRAPH_METRIC_G1_EXTRA_ES = " En G1 se conserva la serie real y se añade un resumen corto de lo detectado en la ventana visible."
GRAPH_METRIC_G2_EXTRA_EN = {
    "A1": "The real value is the mean elapsed-time observation; Z locates it relative to the group.",
    "A2": "The real value summarizes pause duration; Z compares that level across sources.",
    "A3": "The real value summarizes phase-pause duration; Z compares that level across sources.",
    "A4": "The real mean speed and its Z are shown.", "A5": "The real mean distance and its Z are shown.",
    "A6": "The real value is peaks per minute; Z compares that frequency.", "A7": "The real value is peaks per minute; Z compares that frequency.",
    "A8": "The real value is peaks per minute; Z compares that frequency.", "A9": "The real value is peaks per minute; Z compares that frequency.",
    "A10": "The real value is reuse events per minute; Z compares that frequency.",
    "A11": "The real value is net modifier change per minute; the sign preserves direction.",
    "A12": "The real value is net vertex change per minute; the sign preserves direction.",
    "A13": "The real value is net mesh-issue balance per minute; positive generates and negative resolves.",
    "A14": "Object/Edit/Other percentages are shown beside Z; Z is computed from the 0/1/2 code.",
    "A15": "The real value is UV deployments per minute; Z compares that frequency.",
    "A16": "The real value is net object change per minute; the sign preserves direction.",
    "A17": "The real value is percent of time with occlusion active; Z compares that percentage.",
    "A18": "The real value is Undo events per minute; Z compares that rate.",
    "A19": "The real value is percent of time in orthographic view; Z compares that percentage.",
}
GRAPH_METRIC_G2_EXTRA_ES = {
    "A1": "El valor real es el tiempo medio observado en la serie; Z indica su posición respecto al grupo.",
    "A2": "El valor real resume duración de pausa; Z compara ese nivel entre fuentes.",
    "A3": "El valor real resume la pausa por fase; Z compara ese nivel entre fuentes.",
    "A4": "Se muestra la velocidad media real y su Z.", "A5": "Se muestra la distancia media real y su Z.",
    "A6": "El valor real se expresa como picos por minuto; Z compara esa frecuencia.", "A7": "El valor real se expresa como picos por minuto; Z compara esa frecuencia.",
    "A8": "El valor real se expresa como picos por minuto; Z compara esa frecuencia.", "A9": "El valor real se expresa como picos por minuto; Z compara esa frecuencia.",
    "A10": "El valor real es eventos de reutilización por minuto; Z compara esa frecuencia.",
    "A11": "El valor real es cambio neto de modificadores por minuto; el signo conserva dirección.",
    "A12": "El valor real es cambio neto de vértices por minuto; el signo conserva dirección.",
    "A13": "El valor real es balance neto de incidencias por minuto; positivo genera y negativo resuelve.",
    "A14": "Se muestran porcentajes Object/Edit/Other junto a Z; Z se calcula sobre el código 0/1/2.",
    "A15": "El valor real es despliegues UV por minuto; Z compara esa frecuencia.",
    "A16": "El valor real es cambio neto de objetos por minuto; el signo conserva dirección.",
    "A17": "El valor real es porcentaje de tiempo con oclusión activa; Z compara ese porcentaje.",
    "A18": "El valor real es eventos de deshacer por minuto; Z compara esa tasa.",
    "A19": "El valor real es porcentaje de tiempo en vista ortográfica; Z compara ese porcentaje.",
}
GRAPH_METRIC_G3_EXTRA_EN = {
    "A1":"Radar uses final duration (min).", "A2":"Radar uses pause count.", "A3":"Radar uses phase-pause count.",
    "A4":"Radar uses mean speed in local sizes/min.", "A5":"Radar uses mean distance in multiples of local size.",
    "A6":"Radar uses peaks/min.", "A7":"Radar uses peaks/min.", "A8":"Radar uses peaks/min.", "A9":"Radar uses peaks/min.",
    "A10":"Radar uses reuse events/min.", "A11":"Radar uses net modifier change/min.", "A12":"Radar uses net vertex change/min.",
    "A13":"Radar uses net mesh-issue balance/min.", "A14":"Radar normalizes the mean 0/1/2 value; the axis is labelled Other/Object/Edit and a higher value means greater Edit Mode predominance.",
    "A15":"Radar uses UV deployments/min.", "A16":"Radar uses net object change/min.", "A17":"Radar uses % time with occlusion active.", "A18":"Radar uses Undo events/min.", "A19":"Radar uses % time in orthographic view.",
}
GRAPH_METRIC_G3_EXTRA_ES = {
    "A1":"Radar usa duración final (min).", "A2":"Radar usa número de pausas.", "A3":"Radar usa número de pausas por fase.",
    "A4":"Radar usa velocidad media en tamaños locales/min.", "A5":"Radar usa distancia media en múltiplos del tamaño local.",
    "A6":"Radar usa picos/min.", "A7":"Radar usa picos/min.", "A8":"Radar usa picos/min.", "A9":"Radar usa picos/min.",
    "A10":"Radar usa reutilizaciones/min.", "A11":"Radar usa cambio neto de modificadores/min.", "A12":"Radar usa cambio neto de vértices/min.",
    "A13":"Radar usa balance neto de incidencias/min.", "A14":"Radar normaliza el valor medio 0/1/2; el eje se etiqueta como Other/Object/Edit y un valor más alto significa mayor predominio de Edit Mode.",
    "A15":"Radar usa despliegues UV/min.", "A16":"Radar usa cambio neto de objetos/min.", "A17":"Radar usa % de tiempo con oclusión activa.", "A18":"Radar usa eventos de deshacer/min.", "A19":"Radar usa % de tiempo en vista ortográfica.",
}
GRAPH_METRIC_HEATMAP_EXTRA_EN = " In the heatmap, r relates this metric's session summary to the other row/column metric; the sign of r indicates relationship direction, not the meaning of the state."
GRAPH_METRIC_HEATMAP_EXTRA_ES = " En el heatmap, r relaciona el resumen de sesión de esta métrica con la métrica de la otra fila/columna; el signo de r indica dirección, no el significado del estado."
GRAPH_READING_HELP_EN = {
    "G1": "The horizontal axis follows the session. Each metric keeps its real value and unit; states use discrete names/codes. The 0–100% overlay scale only places different ranges in the same space and does not replace the real value.",
    "G2": "Each metric is drawn in its own block with its own Z axis. Every row shows the real value first and Z second. Z=0 is the reference mean; Z>0 is above it and Z<0 below it. Bars are adjusted 95% CIs when available. Work Mode is shown as Object/Edit/Other percentages.",
    "G3": "Radar radius is comparative: 0 = observed minimum and 1 = observed maximum for each axis. A radial 0.8 means 80% of the observed range, not a real value of 0.8. Axes show the name and real unit; Work Mode is expressed as Other/Object/Edit. The legend directly identifies each file or model.",
    "G4": "Each cell is a Pearson correlation r from -1 to 1: +1 strong positive linear relation, 0 no clear linear relation, -1 strong negative linear relation. Correlation does not imply causation and 0/1/2 states retain their metric-specific meaning.",
}
GRAPH_READING_HELP_ES = {
    "G1": "El eje horizontal sigue la sesión. Cada métrica conserva su valor real y su unidad; los estados usan nombres/códigos discretos. La escala superpuesta 0–100% solo coloca métricas con rangos distintos en el mismo espacio y no sustituye el valor real.",
    "G2": "Cada métrica se dibuja en un bloque independiente con su propio eje Z. Cada fila muestra primero el valor real y después Z. Z=0 es la media de referencia; Z>0 está por encima y Z<0 por debajo. Las barras son el IC 95% ajustado cuando existe. Para Work Mode se muestran porcentajes Object/Edit/Other.",
    "G3": "El radio del radar es comparativo: 0 = mínimo observado y 1 = máximo observado para cada eje. Un 0.8 radial significa 80% del rango observado, no un valor real de 0.8. Los ejes muestran nombre y unidad real; Work Mode se expresa como Other/Object/Edit. La leyenda identifica directamente cada archivo o modelo.",
    "G4": "Cada celda es una correlación de Pearson r entre -1 y 1: +1 relación lineal positiva fuerte, 0 sin relación lineal clara, -1 relación lineal negativa fuerte. Correlación no implica causalidad y los estados 0/1/2 se interpretan según su métrica.",
}

# Requested UI wording and metric additions. These source strings live here so
# language changes never depend on hard-coded panel/operator text.
UI_TEXT.update({
    'TIMELINE': 'Timeline',
    'FOREST_PLOT': 'Forest plot',
    'RADAR_PLOT': 'Radar plot',
    'CORRELATION_HEATMAP': 'Correlation heatmap',
    'GRAPH_TYPE': 'Graph type',
    'DATA_GROUPS': 'Data groups',
    'SESSION_DURATION_HELP': 'Total duration of the data recording, displayed in minutes.',
    'UV_WORK_PANEL_HELP': 'Only completed unwrap/deploy operations are recorded; UV editing transforms are ignored.',
    'UNDO_ACTIONS': 'Undo actions',
    'UNDO_ACTIONS_HELP': 'Completed Undo actions, shown as total, frequency and events per session quartile.',
    'ORTHOGRAPHIC_VIEW': 'Orthographic view',
    'ORTHOGRAPHIC_VIEW_HELP': 'Orthographic viewport use measured as a state: activations, active minutes and percentage of session.',
    'INSIGHTS_DETAILED_HELP_TITLE': 'Ize Insights — Detailed Help',
    'INSIGHTS_DETAILED_HELP': 'Ize Insights analyses Ize Logger data and model metrics inside Blender. It calculates descriptive statistics and creates 3D tables and comparative graphs without changing the source data.',
    'MODEL_TARGET_HELP': 'Select the mesh whose model metrics will be calculated or displayed.',
    'MODEL_REFERENCE_HELP': 'Optional reference mesh used by comparison metrics such as similarity.',
    'TABLE_DATA_SOURCE_HELP': 'Choose whether the table uses recorded data metrics or calculated model metrics.',
    'DATA_VISUALIZER_HELP': 'Choose the visible Timeline window and how selected metrics are displayed.',
    'TIMELINE_WINDOW_HELP': 'Percentage of the available rows shown in each Timeline window.',
    'TIMELINE_DISPLAY_HELP': 'Show selected metrics in separate bands or superimposed with an independent real range per metric.',
    'SELECT_ORIGINAL_MEMBERS_HELP': 'Select the original data files contained in the active group.',
    'ORTHOGRAPHIC_ACTIVE': 'Orthographic active',
})

ES.update({
    'Timeline': 'Línea de tiempo',
    'Forest plot': 'Gráfico forest',
    'Radar plot': 'Gráfico radar',
    'Correlation heatmap': 'Mapa de calor de correlación',
    'Graph type': 'Tipo de gráfico',
    'Data groups': 'Grupos de datos',
    'Total duration of the data recording, displayed in minutes.': 'Duración total del registro de datos, mostrada en minutos.',
    'Only completed unwrap/deploy operations are recorded; UV editing transforms are ignored.': 'Solo se registran las operaciones completadas de unwrap/despliegue; se ignoran las transformaciones de edición UV.',
    'Undo actions': 'Acciones de deshacer',
    'Completed Undo actions, shown as total, frequency and events per session quartile.': 'Acciones de deshacer completadas, mostradas como total, frecuencia y eventos por cuartil de la sesión.',
    'Orthographic view': 'Vista ortográfica',
    'Orthographic viewport use measured as a state: activations, active minutes and percentage of session.': 'Uso de la vista ortográfica medido como estado: activaciones, minutos activos y porcentaje de la sesión.',
    'Ize Insights — Detailed Help': 'Ize Insights — Ayuda detallada',
    'Ize Insights analyses Ize Logger data and model metrics inside Blender. It calculates descriptive statistics and creates 3D tables and comparative graphs without changing the source data.': 'Ize Insights analiza dentro de Blender los datos de Ize Logger y las métricas de los modelos. Calcula estadísticas descriptivas y crea tablas 3D y gráficos comparativos sin modificar los datos de origen.',
    'Select the mesh whose model metrics will be calculated or displayed.': 'Selecciona la malla cuyas métricas de modelo se calcularán o mostrarán.',
    'Optional reference mesh used by comparison metrics such as similarity.': 'Malla de referencia opcional utilizada por métricas de comparación como la similitud.',
    'Choose whether the table uses recorded data metrics or calculated model metrics.': 'Elige si la tabla utiliza métricas de datos registrados o métricas de modelo calculadas.',
    'Choose the visible Timeline window and how selected metrics are displayed.': 'Elige la ventana visible de la línea de tiempo y cómo se muestran las métricas seleccionadas.',
    'Percentage of the available rows shown in each Timeline window.': 'Porcentaje de las filas disponibles mostrado en cada ventana de la línea de tiempo.',
    'Show selected metrics in separate bands or superimposed with an independent real range per metric.': 'Muestra las métricas seleccionadas en bandas separadas o superpuestas con un rango real independiente para cada métrica.',
    'Select the original data files contained in the active group.': 'Selecciona los archivos de datos originales contenidos en el grupo activo.',
    'Orthographic active': 'Ortográfica activa',
    'Move to the previous or next Timeline data window and redraw the graph': 'Ir a la ventana de datos anterior o siguiente de la línea de tiempo y redibujar el gráfico',
    'Change Timeline window': 'Cambiar ventana de la línea de tiempo',
    'Percentage of the available rows shown in each Timeline window': 'Porcentaje de las filas disponibles mostrado en cada ventana de la línea de tiempo',
    'Show all available Timeline data before the numbered window': 'Mostrar todos los datos disponibles de la línea de tiempo antes de la ventana numerada',
    'Zero-based first row of the Timeline window': 'Primera fila, con índice base cero, de la ventana de la línea de tiempo',
    'Timeline needs at least one selected Y metric; X is always time': 'La línea de tiempo necesita al menos una métrica Y seleccionada; X siempre es el tiempo',
    'Timeline could not generate data for this window': 'La línea de tiempo no pudo generar datos para esta ventana',
    'Show selected metrics through ordered samples to inspect trends, peaks and pauses': 'Muestra las métricas seleccionadas a través de muestras ordenadas para inspeccionar tendencias, picos y pausas',
    'Compare central values and spread across files, groups or mesh observations': 'Compara valores centrales y dispersión entre archivos, grupos u observaciones de modelos',
    'Compare normalized multivariate profiles from data metrics, mesh metrics or associations': 'Compara perfiles multivariantes normalizados de métricas de datos, métricas de modelo o asociaciones',
    'Inspect Pearson correlations between selected data and/or mesh metrics': 'Inspecciona correlaciones de Pearson entre las métricas de datos y/o de modelo seleccionadas',
    'Non-manifold vertices (count)': 'Vértices non-manifold (cantidad)',
    'Non-manifold vertices (% of vertices)': 'Vértices non-manifold (% de vértices)',
})

# Model-analysis help text kept outside the UI modules so wording can be revised centrally.
MODEL_METRIC_HELP_EN = {
    "UV_area": "Percentage of occupied UV space.",
    "UV_islands": "Number of UV islands.",
    "UV_stretch": "UV distortion expressed as a percentage; lower usually means less stretch.",
    "UV_textel_density": "Relative texel density.",
    "Normal_percentage": "Percentage of inverted normals; 0% means none.",
    "Transformations": "State: 0 = not applied; 1 = applied.",
    "Position": "State: 0 = away from world origin; 1 = at world origin.",
    "Non_quads_percentage": "Percentage of faces that are not quads.",
    "Vertex_duplicate": "Count of duplicate vertices.",
    "Vertex_duplicate_percentage": "Percentage of duplicate vertices.",
    "Non_manifold": "Count of non-manifold vertices.",
    "Non_manifold_percentage": "Non-manifold vertices as a percentage of total vertices.",
    "N_faces": "Total face count.",
    "N_meshes": "Number of disconnected mesh components.",
    "Face_by_mesh": "Average faces per mesh component.",
    "Angle": "Mean angle between connected faces.",
    "Similarity": "Similarity to the selected reference object.",
}
MODEL_METRIC_HELP_ES = {
    "UV_area": "Porcentaje del espacio UV ocupado.",
    "UV_islands": "Número de islas UV.",
    "UV_stretch": "Distorsión UV expresada como porcentaje; menor suele indicar menos estiramiento.",
    "UV_textel_density": "Densidad de téxel relativa.",
    "Normal_percentage": "Porcentaje de normales invertidas; 0% es ninguna.",
    "Transformations": "Estado: 0 = no aplicadas; 1 = aplicadas.",
    "Position": "Estado: 0 = fuera del origen; 1 = en el origen global.",
    "Non_quads_percentage": "Porcentaje de caras que no son quads.",
    "Vertex_duplicate": "Cantidad de vértices duplicados.",
    "Vertex_duplicate_percentage": "Porcentaje de vértices duplicados.",
    "Non_manifold": "Cantidad de vértices non-manifold.",
    "Non_manifold_percentage": "Vértices non-manifold como porcentaje del total de vértices.",
    "N_faces": "Cantidad total de caras.",
    "N_meshes": "Número de componentes de malla desconectados.",
    "Face_by_mesh": "Promedio de caras por componente de malla.",
    "Angle": "Ángulo medio entre caras conectadas.",
    "Similarity": "Similitud respecto al objeto de referencia seleccionado.",
}


# Model metric catalogue and categories aligned with the project metric sheet.
ES.update({
    'Mesh structure': 'Estructura de la malla',
    'Mesh topology': 'Topología de la malla',
    'UV Mapping': 'Mapeado UV',
    'Transform state': 'Estado de transformación',
    'Shape similarity': 'Similitud geométrica',
    'Polygon count': 'Cantidad de polígonos',
    'Mesh count': 'Cantidad de mallas',
    'Polygon per mesh': 'Polígonos por mallas',
    'Mean edge angle': 'Ángulo medio de las aristas',
    'Non-quad polygon count': 'Cantidad de polígonos no cuadrangulares',
    'Non-quad polygon percentage': 'Porcentaje de polígonos no cuadrangulares',
    'Duplicate vertices count': 'Cantidad de vértices duplicados',
    'Duplicate vertices percentage': 'Porcentaje de vértices duplicados',
    'Non-manifold vertex count': 'Cantidad de vértices no-manifold',
    'Non-manifold vertex percentage': 'Porcentaje de vértices no-manifold',
    'Inverted polygon normal count': 'Cantidad de polígonos con normales invertidas',
    'Inverted polygon normal percentage': 'Porcentaje de polígonos con normales invertidas',
    'UV coverage': 'Cobertura UV',
    'Island count': 'Cantidad de islas',
    'UV stretch percentage': 'Porcentaje de estiramiento UV',
    'Texel density deviation': 'Desviación de la densidad de texel',
    'Transforms applied': 'Transformaciones aplicadas',
    'World origin alignment': 'Alineación al origen global',
    'Similarity vs. Reference': 'Similitud con la referencia',
    'Yes': 'Sí',
    'No': 'No',
})

HELP_EN.update({
    'MESH_STRUCTURE_LONG_HELP': 'Summarises polygon count, mesh count, polygons per mesh, mean edge angle and non-quad polygons.',
    'MESH_TOPOLOGY_LONG_HELP': 'Summarises duplicate vertices, non-manifold vertices and polygons with inverted normals, as counts and percentages.',
    'TRANSFORM_STATE_LONG_HELP': 'Shows whether transforms are applied and whether the model is aligned to the world origin.',
    'SHAPE_SIMILARITY_LONG_HELP': 'Compares the analysed model with the selected reference model. Higher percentages indicate greater shape similarity.',
})
HELP_ES.update({
    'MESH_STRUCTURE_LONG_HELP': 'Resume la cantidad de polígonos y mallas, los polígonos por malla, el ángulo medio de las aristas y los polígonos no cuadrangulares.',
    'MESH_TOPOLOGY_LONG_HELP': 'Resume vértices duplicados, vértices no-manifold y polígonos con normales invertidas, como cantidades y porcentajes.',
    'TRANSFORM_STATE_LONG_HELP': 'Indica si las transformaciones están aplicadas y si el modelo está alineado con el origen global.',
    'SHAPE_SIMILARITY_LONG_HELP': 'Compara el modelo analizado con el modelo de referencia seleccionado. Los porcentajes más altos indican mayor similitud geométrica.',
})

MODEL_METRIC_HELP_EN.update({
    'N_faces': 'Total polygon count.',
    'N_meshes': 'Number of mesh components.',
    'Face_by_mesh': 'Average polygon count per mesh component.',
    'Angle': 'Mean angle between connected polygon edges.',
    'Non_quads': 'Number of polygons that are not quads.',
    'Non_quads_percentage': 'Percentage of polygons that are not quads.',
    'Vertex_duplicate': 'Count of duplicate vertices.',
    'Vertex_duplicate_percentage': 'Percentage of duplicate vertices.',
    'Non_manifold': 'Count of non-manifold vertices.',
    'Non_manifold_percentage': 'Percentage of non-manifold vertices.',
    'Normal_count': 'Count of polygons with inverted normals.',
    'Normal_percentage': 'Percentage of polygons with inverted normals.',
    'UV_area': 'UV coverage as a percentage.',
    'UV_islands': 'Number of UV islands.',
    'UV_stretch': 'UV stretch percentage.',
    'UV_textel_density': 'Texel density deviation percentage.',
    'Transformations': 'Whether object transforms are applied.',
    'Position': 'Whether the object is aligned to the world origin.',
    'Similarity': 'Shape similarity to the selected reference.',
})
MODEL_METRIC_HELP_ES.update({
    'N_faces': 'Cantidad total de polígonos.',
    'N_meshes': 'Cantidad de componentes de malla.',
    'Face_by_mesh': 'Cantidad media de polígonos por componente de malla.',
    'Angle': 'Ángulo medio de las aristas entre polígonos conectados.',
    'Non_quads': 'Cantidad de polígonos que no son cuadrangulares.',
    'Non_quads_percentage': 'Porcentaje de polígonos que no son cuadrangulares.',
    'Vertex_duplicate': 'Cantidad de vértices duplicados.',
    'Vertex_duplicate_percentage': 'Porcentaje de vértices duplicados.',
    'Non_manifold': 'Cantidad de vértices no-manifold.',
    'Non_manifold_percentage': 'Porcentaje de vértices no-manifold.',
    'Normal_count': 'Cantidad de polígonos con normales invertidas.',
    'Normal_percentage': 'Porcentaje de polígonos con normales invertidas.',
    'UV_area': 'Cobertura UV expresada como porcentaje.',
    'UV_islands': 'Cantidad de islas UV.',
    'UV_stretch': 'Porcentaje de estiramiento UV.',
    'UV_textel_density': 'Porcentaje de desviación de la densidad de texel.',
    'Transformations': 'Indica si las transformaciones del objeto están aplicadas.',
    'Position': 'Indica si el objeto está alineado con el origen global.',
    'Similarity': 'Similitud geométrica respecto al modelo de referencia seleccionado.',
})

def _replace_csv_terminology(text: str, language: str) -> str:
    """Use Data/Datos in visible copy while preserving internal CSV identifiers."""
    value = str(text)
    if language == LANG_ES:
        replacements = (
            ("CSV ↔ CSV", "Datos ↔ Datos"),
            ("CSV ↔ Malla", "Datos ↔ Malla"),
            ("CSV/malla", "datos/malla"),
            ("CSV / Usuario", "Datos / Usuario"),
            ("Archivos CSV", "Archivos de datos"),
            ("archivos CSV", "archivos de datos"),
            ("Archivo CSV", "Archivo de datos"),
            ("archivo CSV", "archivo de datos"),
            ("Grupos CSV", "Grupos de datos"),
            ("grupos CSV", "grupos de datos"),
            ("Grupo CSV", "Grupo de datos"),
            ("grupo CSV", "grupo de datos"),
            ("Métricas CSV", "Métricas de datos"),
            ("métricas CSV", "métricas de datos"),
            ("Métrica CSV", "Métrica de datos"),
            ("métrica CSV", "métrica de datos"),
            ("fuentes CSV", "fuentes de datos"),
            ("fuente CSV", "fuente de datos"),
            ("grabaciones CSV", "grabaciones de datos"),
            ("grabación CSV", "grabación de datos"),
            ("del CSV", "de los datos"),
            ("el CSV", "los datos"),
            (" CSV", " datos"),
            ("CSV ", "Datos "),
            ("CSV", "Datos"),
        )
    else:
        replacements = (
            ("CSV ↔ CSV", "Data ↔ Data"),
            ("CSV ↔ Model", "Data ↔ Model"),
            ("CSV/model", "data/model"),
            ("CSV files", "data files"),
            ("CSV file", "data file"),
            ("CSV groups", "data groups"),
            ("CSV group", "data group"),
            ("CSV metrics", "data metrics"),
            ("CSV metric", "data metric"),
            ("CSV sources", "data sources"),
            ("CSV source", "data source"),
            ("CSV recordings", "data recordings"),
            ("CSV recording", "data recording"),
            ("CSV", "Data"),
        )
    for source, target in replacements:
        value = value.replace(source, target)
    return value


def get_language(scene: Any = None) -> str:
    """Return the language explicitly selected by the user."""
    selected = getattr(scene, "anali_language", LANG_EN) if scene is not None else LANG_EN
    return selected if selected in {LANG_EN, LANG_ES} else LANG_EN

def tr(scene: Any, text: str) -> str:
    language = get_language(scene)
    if language == LANG_ES:
        translated = ES.get(text, HELP_ES.get(text, text))
    else:
        translated = HELP_EN.get(text, text)
    return _replace_csv_terminology(translated, language)

_ENUM_ITEMS_CACHE = {}


def translate_enum_items(scene: Any, items):
    """Return persistent translated enum items compatible with Blender RNA.

    Blender keeps references to strings returned by dynamic EnumProperty
    callbacks. Returning a newly allocated list on every redraw can invalidate
    those references, so translated tuples are cached for the lifetime of the
    add-on. Identifiers and optional icon/numeric fields remain unchanged.
    """
    language = get_language(scene)
    source_items = tuple(tuple(item) for item in items)
    cache_key = (language, source_items)
    cached = _ENUM_ITEMS_CACHE.get(cache_key)
    if cached is not None:
        return cached

    translated = []
    for item in source_items:
        if len(item) < 3:
            translated.append(item)
            continue
        identifier, label, description, *extra = item
        translated.append((identifier, tr(scene, label), tr(scene, description), *extra))
    result = tuple(translated)
    _ENUM_ITEMS_CACHE[cache_key] = result
    return result

def format_text(scene: Any, text: str, **values: Any) -> str:
    return tr(scene, text).format(**values)


def _ui_scale(context: Any) -> float:
    try:
        return max(float(context.preferences.system.ui_scale), 0.5)
    except Exception:
        return 1.0


def _available_region_pixels(context: Any, reserve_px: int = 58) -> int:
    """Return the usable horizontal space of the current Blender region.

    This is evaluated every time the panel is drawn, so changing the width of
    the N-panel immediately changes the wrapping on the next redraw.
    """
    width_px = 320
    try:
        width_px = int(context.region.width)
    except Exception:
        pass
    scaled_reserve = int(reserve_px * _ui_scale(context))
    return max(80, width_px - scaled_reserve)


def region_character_width(context: Any, *, reserve_px: int = 58, minimum: int = 12, maximum: int = 90) -> int:
    """Estimate a conservative character count from the live region width."""
    usable_px = _available_region_pixels(context, reserve_px=reserve_px)
    # A conservative average avoids clipping in nested boxes and with accented text.
    chars = int(usable_px / (8.2 * _ui_scale(context)))
    return max(minimum, min(maximum, chars))


def _pixel_wrap(context: Any, text: str, *, reserve_px: int = 58, indent_px: int = 0) -> list[str]:
    """Wrap text using Blender font measurements when available."""
    raw = str(text or "")
    if not raw:
        return [""]

    max_px = max(70, _available_region_pixels(context, reserve_px=reserve_px) - indent_px)
    try:
        import blf
        font_id = 0
        blf.size(font_id, max(9, round(11 * _ui_scale(context))))

        lines: list[str] = []
        for paragraph in raw.splitlines() or [raw]:
            words = paragraph.split()
            if not words:
                lines.append("")
                continue
            current = words[0]
            for word in words[1:]:
                candidate = f"{current} {word}"
                if blf.dimensions(font_id, candidate)[0] <= max_px:
                    current = candidate
                else:
                    lines.append(current)
                    current = word
            lines.append(current)
        return lines or [""]
    except Exception:
        width = region_character_width(context, reserve_px=reserve_px)
        return textwrap.wrap(
            raw, width=max(8, width),
            break_long_words=False, break_on_hyphens=False,
        ) or [""]


def wrap_lines(
    context: Any,
    text: str,
    *,
    indent: int = 0,
    width: int | None = None,
    reserve_px: int = 58,
) -> list[str]:
    if width is not None:
        available = max(8, width - indent)
        return textwrap.wrap(
            str(text or ""), width=available,
            break_long_words=False, break_on_hyphens=False,
        ) or [""]
    return _pixel_wrap(
        context, text, reserve_px=reserve_px,
        indent_px=max(0, indent) * int(8.2 * _ui_scale(context)),
    )


def label_value_lines(context: Any, label: str, value: str) -> list[str]:
    """Return responsive ``Label:  value`` lines without separate columns."""
    prefix = f"{label}:  "
    raw_value = str(value)
    try:
        import blf
        font_id = 0
        blf.size(font_id, max(9, round(11 * _ui_scale(context))))
        prefix_px = int(blf.dimensions(font_id, prefix)[0])
    except Exception:
        prefix_px = int(len(prefix) * 8.2 * _ui_scale(context))

    chunks = _pixel_wrap(
        context, raw_value, reserve_px=58, indent_px=prefix_px,
    )
    lines = [prefix + chunks[0]]
    # Blender labels do not preserve tab stops reliably. Spaces keep all
    # continuation lines visually aligned with the value in the same label.
    continuation = " " * len(prefix)
    lines.extend(continuation + chunk for chunk in chunks[1:])
    return lines


# Metric catalogue aligned with "Datos y categorias.xlsx" (authoritative order/wording).
UI_TEXT.update({
    'TEMPORAL_ACTIVITY': 'Temporal activity',
    'VIEW_NAVIGATION': 'View & navigation',
    'MODEL_EVOLUTION': 'Model evolution',
    'TOOLS_ACTIONS': 'Tools & actions',
    'TEMPORAL_ACTIVITY_HELP': 'Session duration and inactivity periods during the recorded workflow.',
    'VIEW_NAVIGATION_HELP': 'Viewport movement, framing and viewing-state metrics during the session.',
    'MODEL_EVOLUTION_HELP': 'Changes in vertices, topology issues and object count. Additions are positive and removals are negative.',
    'TOOLS_ACTIONS_HELP': 'Work modes and editing actions used during the recorded workflow.',
    'SESSION_DURATION': 'Session duration',
    'PAUSES': 'Pausses',
    'VIEW_SPEED': 'Navigation speed',
    'DISTANCE_TO_OBJECT': 'Distance to target',
    'VIEW_MOVEMENT_PEAKS': 'Motion peaks',
    'OCCLUSION': 'Non-occluded view',
    'ORTHOGRAPHIC_VIEW': 'Ortographic view',
    'VERTEX_CHANGES': 'Vertex count',
    'MESH_ISSUE_CHANGES': 'Topology issues',
    'OBJECT_CHANGES': 'Object count',
    'WORK_MODE': 'Work mode',
    'SHORTCUT_REUSE': 'Reuse actions',
    'MODIFIER_CHANGES': 'Modifier usage',
    'UV_WORK': 'UV editing',
    'UNDO_ACTIONS': 'Undo actions',
})

ES.update({
    'Temporal activity': 'Actividad temporal',
    'View & navigation': 'Vista y navegación',
    'Model evolution': 'Evolución del modelo',
    'Tools & actions': 'Herramientas y acciones',
    'Session duration and inactivity periods during the recorded workflow.': 'Duración de la sesión y periodos de inactividad durante el flujo de trabajo registrado.',
    'Viewport movement, framing and viewing-state metrics during the session.': 'Métricas de movimiento, encuadre y estados de visualización durante la sesión.',
    'Changes in vertices, topology issues and object count. Additions are positive and removals are negative.': 'Cambios en vértices, incidencias de topología y cantidad de objetos. Las adiciones son positivas y las eliminaciones negativas.',
    'Work modes and editing actions used during the recorded workflow.': 'Modos de trabajo y acciones de edición utilizados durante el flujo de trabajo registrado.',
    'Session duration': 'Duración de la sesión',
    'Pausses': 'Pausas',
    'Navigation speed': 'Velocidad de navegación',
    'Distance to target': 'Distancia al objetivo',
    'Motion peaks': 'Picos de movimiento',
    'Non-occluded view': 'Vista sin oclusión',
    'Ortographic view': 'Vista ortográfica',
    'Vertex count': 'Cantidad de vértices',
    'Topology issues': 'Incidencias en la topología',
    'Object count': 'Cantidad de objetos',
    'Work mode': 'Modo de trabajo',
    'Reuse actions': 'Acciones de reutilización',
    'Modifier usage': 'Uso de modificadores',
    'UV editing': 'Edición de UVs',
    'Undo actions': 'Acciones revertidas',
})

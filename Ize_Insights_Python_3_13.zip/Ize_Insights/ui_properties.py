# Herramientas para la monitorización y análisis de procesos de modelado 3D en Blender
# Copyright (C) 2026 María Molina Goyena
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# at your option any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.

from .texts import UI_TEXT
import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty



_MESH_OBSERVATION_ITEMS_CACHE = []

def _mesh_observation_items(self, context):
    """Return calculated and imported mesh observations as one selector.

    The identifier is the key stored in scene["metrics_data"]. A record may
    come from a live Blender mesh or from an imported Data Logger JSON/CSV;
    graphs consume both in exactly the same way.
    """
    scene = getattr(context, "scene", None) if context is not None else getattr(bpy.context, "scene", None)
    store = dict(scene.get("metrics_data", {})) if scene is not None else {}
    imported_names = set()
    if scene is not None:
        try:
            import json
            imported_names = set(json.loads(scene.get("data_logger_mesh_names", "[]") or "[]"))
        except Exception:
            imported_names = set()

    items = []
    for index, name in enumerate(str(key) for key in store.keys()):
        obj = bpy.data.objects.get(name)
        is_live_mesh = obj is not None and getattr(obj, "type", None) == 'MESH'
        if name in imported_names and not is_live_mesh:
            # Imported observations are displayed exactly as their source file.
            label = name
            description = UI_TEXT['IMPORTED_MODEL_OBSERVATION_FROM_THIS_DATA_LOGGER_JSON_OR_CSV_FILE']
        elif name in imported_names:
            label = name
            description = UI_TEXT['IMPORTED_DATA_LOGGER_OBSERVATION_MATCHING_A_SCENE_MODEL']
        else:
            label = f"{name} · Scene mesh"
            description = UI_TEXT['CALCULATED_MODEL_OBSERVATION_FROM_THE_CURRENT_BLENDER_SCENE']
        items.append((name, label, description, 'MESH_DATA', index))

    if not items:
        items = [('__NONE__', 'No model observations', 'Calculate or import model metrics first', 'INFO', 0)]

    _MESH_OBSERVATION_ITEMS_CACHE[:] = items
    return _MESH_OBSERVATION_ITEMS_CACHE


class MetricStatItem(bpy.types.PropertyGroup):
    csv_name: StringProperty()
    key: StringProperty()
    label: StringProperty()

    value: FloatProperty(default=0.0)
    mean: FloatProperty(default=0.0)
    weighted_mean: FloatProperty(default=0.0)
    std: FloatProperty(default=0.0)
    min: FloatProperty(default=0.0)
    max: FloatProperty(default=0.0)

    total: FloatProperty(default=0.0)
    count: FloatProperty(default=0.0)
    rate_per_min: FloatProperty(default=0.0)

    delta_total: FloatProperty(default=0.0)
    delta_per_sec: FloatProperty(default=0.0)

    q1: FloatProperty(default=0.0)
    q2: FloatProperty(default=0.0)
    q3: FloatProperty(default=0.0)
    q4: FloatProperty(default=0.0)

    time_object: FloatProperty(default=0.0)
    time_edit: FloatProperty(default=0.0)
    pct_object: FloatProperty(default=0.0)
    pct_edit: FloatProperty(default=0.0)
    switches: FloatProperty(default=0.0)
    pct_object_q1: FloatProperty(default=0.0)
    pct_object_q2: FloatProperty(default=0.0)
    pct_object_q3: FloatProperty(default=0.0)
    pct_object_q4: FloatProperty(default=0.0)
    pct_edit_q1: FloatProperty(default=0.0)
    pct_edit_q2: FloatProperty(default=0.0)
    pct_edit_q3: FloatProperty(default=0.0)
    pct_edit_q4: FloatProperty(default=0.0)
    mode_switch_q1: FloatProperty(default=0.0)
    mode_switch_q2: FloatProperty(default=0.0)
    mode_switch_q3: FloatProperty(default=0.0)
    mode_switch_q4: FloatProperty(default=0.0)

    active_count: FloatProperty(default=0.0)
    inactive_count: FloatProperty(default=0.0)
    mean_active_duration: FloatProperty(default=0.0)
    mean_inactive_duration: FloatProperty(default=0.0)
    abs_total: FloatProperty(default=0.0)
    created_total: FloatProperty(default=0.0)
    deleted_total: FloatProperty(default=0.0)
    ctrl_v_total: FloatProperty(default=0.0)
    shift_d_total: FloatProperty(default=0.0)
    alt_d_total: FloatProperty(default=0.0)
    duplicate_total: FloatProperty(default=0.0)
    instance_total: FloatProperty(default=0.0)
    uv_deploy_total: FloatProperty(default=0.0)
    uv_transform_total: FloatProperty(default=0.0)
    uv_associated_total: FloatProperty(default=0.0)
    time_active_min: FloatProperty(default=0.0)
    pct_active: FloatProperty(default=0.0)
    activations: FloatProperty(default=0.0)
    rate_per_hour: FloatProperty(default=0.0)
    object_local_size: FloatProperty(default=0.0)
    peak_speed_mean: FloatProperty(default=0.0)
    ngon_error_total: FloatProperty(default=0.0)
    tri_error_total: FloatProperty(default=0.0)
    normal_error_total: FloatProperty(default=0.0)
    nonmanifold_error_total: FloatProperty(default=0.0)
    issue_created_total: FloatProperty(default=0.0)
    issue_resolved_total: FloatProperty(default=0.0)
    mesh_count_q1: FloatProperty(default=0.0)
    mesh_count_q2: FloatProperty(default=0.0)
    mesh_count_q3: FloatProperty(default=0.0)
    mesh_count_q4: FloatProperty(default=0.0)
    
class CSVItem(bpy.types.PropertyGroup):
    name: StringProperty()
    selected: BoolProperty(default=True, update=lambda self, ctx: update_csv_analysis_store(ctx.scene) if getattr(ctx, "scene", None) else None)


class CSVGroupItem(bpy.types.PropertyGroup):
    """Persistent group of CSV paths treated as one virtual CSV source."""
    name: StringProperty(name=UI_TEXT['GROUP_NAME'], default="CSV Group")
    selected: BoolProperty(name=UI_TEXT['USE_GROUP'], default=True, update=lambda self, ctx: update_csv_analysis_store(ctx.scene) if getattr(ctx, "scene", None) else None)
    member_paths: StringProperty(name=UI_TEXT['MEMBERS'], default="[]")




class DataMeshPairItem(bpy.types.PropertyGroup):
    """Association between one data file and one mesh-metric observation.

    The mesh observation may come from a live Blender object or from an
    imported Data Logger JSON/CSV file. Both sources are stored in
    scene["metrics_data"] and are therefore equivalent for graphs.
    """
    data_path: StringProperty(name=UI_TEXT['DATA_FILE'], subtype='FILE_PATH')
    mesh_record: EnumProperty(
        name=UI_TEXT['MESH_DATA'],
        description=UI_TEXT['CHOOSE_A_CALCULATED_SCENE_MODEL_OR_AN_IMPORTED_DATA_LOGGER_MODEL_OBSER'],
        items=_mesh_observation_items,
    )
    # Kept only to migrate associations created by older add-on versions.
    mesh_object: PointerProperty(
        name=UI_TEXT['LEGACY_MESH'],
        type=bpy.types.Object,
        poll=lambda self, obj: obj is not None and obj.type == 'MESH',
        options={'HIDDEN'},
    )

class AnalysisItem(bpy.types.PropertyGroup):
    key: StringProperty()
    label: StringProperty()
    typology: StringProperty()
    enabled: BoolProperty(default=False)
    role: EnumProperty(items=[('Y', 'Metric', '')], default='Y')

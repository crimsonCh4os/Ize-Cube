# Ize Insights — Installation / Instalación

## Español

### Instalación recomendada con instalador externo (Windows)

1. En Blender, abre **Edit > Preferences > Add-ons**.
2. Pulsa **Install from Disk** y selecciona `Ize Insights.zip`.
3. Cierra Blender.
4. Extrae la carpeta `Installer_Windows` y ejecuta `install_dependencies_windows.bat`.
5. El instalador detectará Blender y la carpeta del complemento. Si hay varias instalaciones, te pedirá elegir una.
6. Vuelve a abrir Blender y activa **Ize Insights**.

El instalador usa el Python incluido con Blender y guarda NumPy y Matplotlib en
la carpeta privada `site-packages` del complemento. Blender y las dependencias
no se incluyen en el repositorio.

### Alternativa desde Blender

Si faltan bibliotecas, el panel **Ize Insights** también permite pulsar
**Instalar dependencias**. Reinicia Blender al terminar.

## English

### Recommended external installer (Windows)

1. In Blender, open **Edit > Preferences > Add-ons**.
2. Choose **Install from Disk** and select `Ize Insights.zip`.
3. Close Blender.
4. Extract `Installer_Windows` and run `install_dependencies_windows.bat`.
5. The installer detects Blender and the add-on folder. If it finds multiple installations, it asks you to choose one.
6. Reopen Blender and enable **Ize Insights**.

The installer uses Blender's bundled Python and stores NumPy and Matplotlib in
the add-on's private `site-packages` folder. Blender and third-party packages
are not included in the repository.

### Blender fallback

When libraries are missing, the **Ize Insights** panel can also run
**Install dependencies**. Restart Blender afterwards.

## Dependencias privadas / Private dependencies

La distribución no incluye bibliotecas ya extraídas dentro de `site-packages`.
La carpeta se entrega vacía y el botón **Instalar dependencias** instala los
archivos `.whl` incluidos en `wheels/` dentro de esa carpeta privada.

The distribution does not include pre-extracted libraries in `site-packages`.
The folder ships empty and the **Install dependencies** button installs the
bundled `.whl` files from `wheels/` into that private folder.


## Python 3.13 / Blender 5.1+

Esta variante está preparada para **Windows x64 + CPython 3.13**. En una instalación nueva, pulsa **Instalar dependencias**. El instalador descarga desde PyPI únicamente wheels binarios compatibles (`cp313`) y los instala en `Ize_Insights/site-packages`. No usa wheels `cp311`, no compila paquetes y usa `--no-cache-dir`. Se requiere conexión a Internet durante este paso.

This build targets **Windows x64 + CPython 3.13**. On a fresh installation, click **Install dependencies**. The installer downloads compatible binary wheels (`cp313`) from PyPI into `Ize_Insights/site-packages`; it does not use `cp311` wheels, does not build from source, and uses `--no-cache-dir`. An Internet connection is required for this step.

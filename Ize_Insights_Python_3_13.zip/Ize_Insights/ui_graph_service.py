# Herramientas para la monitorización y análisis de procesos de modelado 3D en Blender
# Copyright (C) 2026 María Molina Goyena
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# at your option any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.

import os
import math
import re
import bpy
import numpy as np
from mathutils import Vector

from .ui_helpers import *
from .ui_properties import *
from .analytics import (
    ANALYSIS,
    compute_metrics_for_csv,
    series_to_array,
    clamp_outliers,
    sanitize_name,
    summarize_csv_metrics_for_correlation,
    pearson_cross_correlation,
    _row_object_local_size,
    _csv_session_key,
    _row_time,
)
from .constants import DEFAULT_MAX_REASONABLE_SPEED
from .graphs import (
    clear_previous_graphs,
    csv_color_by_index,
    metric_color_for_csv,
    create_text_label,
    create_axis,
    create_interaction_graph_3d,
    draw_forest_plot_3d,
    draw_multi_csv_forest_plot_3d,
    draw_multi_metric_forest_plot_3d,
    draw_radar_graph_3d_filled,
    draw_csv_color_legend,
    draw_pearson_heatmap_3d,
)
from .utils import read_csv
from .texts import UI_TEXT, tr, get_language
from .metric_semantics import DATA_METRIC_PRESENTATION, metric_unit, metric_short_label, metric_visual


# In-memory cache for CSV parsing and metric calculation.  The cache is keyed
# by the file identity on disk and the speed threshold that affects analytics.
# It deliberately lives only for the current Blender process: changing a CSV
# invalidates it automatically through mtime/size and no stale files are stored.
_CSV_ANALYSIS_CACHE = {}

def _csv_analysis_cache_key(csv_path, max_reasonable_speed):
    path = os.path.abspath(csv_path)
    stat = os.stat(path)
    return (path, int(stat.st_mtime_ns), int(stat.st_size), float(max_reasonable_speed))

def _cached_csv_analysis(csv_path, max_reasonable_speed=DEFAULT_MAX_REASONABLE_SPEED):
    """Return parsed rows and metrics, reusing unchanged CSV calculations."""
    key = _csv_analysis_cache_key(csv_path, max_reasonable_speed)
    cached = _CSV_ANALYSIS_CACHE.get(key)
    if cached is not None:
        return cached
    path = key[0]
    # Remove superseded entries for the same source so repeated edits do not
    # grow the cache for the lifetime of Blender.
    for old_key in [k for k in _CSV_ANALYSIS_CACHE if k[0] == path and k != key]:
        _CSV_ANALYSIS_CACHE.pop(old_key, None)
    _header, data = read_csv(path)
    metrics = compute_metrics_for_csv(data, max_reasonable_speed=max_reasonable_speed)
    _CSV_ANALYSIS_CACHE[key] = (data, metrics)
    return data, metrics

def _downsample_xy_for_display(x_values, y_values, max_points=700):
    """Reduce only rendered points while preserving first/last and local extrema.

    Statistical calculations continue to use the complete arrays.  This helper
    only reduces Blender curve control points, which are expensive to create.
    """
    x = np.asarray(x_values, dtype=float)
    y = np.asarray(y_values, dtype=float)
    n = min(x.size, y.size)
    if n <= max_points or max_points < 8:
        return x[:n], y[:n]
    x = x[:n]; y = y[:n]
    # Keep two representatives (min/max Y) per bucket in chronological order.
    bucket_count = max(1, (int(max_points) - 2) // 2)
    edges = np.linspace(1, n - 1, bucket_count + 1, dtype=int)
    keep = [0]
    for a, b in zip(edges[:-1], edges[1:]):
        if b <= a:
            continue
        chunk = y[a:b]
        finite = np.isfinite(chunk)
        if not np.any(finite):
            continue
        valid_idx = np.flatnonzero(finite)
        vals = chunk[valid_idx]
        i_min = a + int(valid_idx[int(np.argmin(vals))])
        i_max = a + int(valid_idx[int(np.argmax(vals))])
        keep.extend(sorted({i_min, i_max}))
    keep.append(n - 1)
    keep = np.asarray(sorted(set(keep)), dtype=int)
    return x[keep], y[keep]

def _downsample_segments_for_display(segments, max_points_per_segment=700):
    return [_downsample_xy_for_display(x, y, max_points_per_segment) for x, y in (segments or [])]




def _short_source_name(name, max_len=18):
    """Compact a source label while preserving its real filename/group identity."""
    base = os.path.basename(str(name or "")).strip()
    base = re.sub(r"^[|]+", "", base)
    if not base:
        base = "—"
    if len(base) <= max_len:
        return base
    # Preserve both ends: the suffix often contains participant/session IDs or
    # the .csv extension and is therefore useful to distinguish observations.
    left = max(4, (max_len - 1) // 2)
    right = max(4, max_len - left - 1)
    return base[:left] + "…" + base[-right:]


def _graph_metrics_with_local_view_units(metrics, data):
    """Return a graph-only copy with view distance expressed in local sizes.

    A4 becomes local-size/min and A5 becomes multiples of the current local
    object size. Calculate Data and tables keep their existing raw/metric data.
    """
    converted = {key: list(values) if isinstance(values, (list, tuple, np.ndarray)) else values for key, values in metrics.items()}
    sizes = np.asarray([_row_object_local_size(row) for row in data], dtype=float)
    positive = sizes[np.isfinite(sizes) & (sizes > 1e-12)]
    fallback = float(np.median(positive)) if positive.size else 1.0
    for key in ("A4", "A5"):
        values = np.asarray(metrics.get(key, []), dtype=float)
        if values.size == 0:
            continue
        n = min(values.size, sizes.size)
        out = values.copy()
        if n:
            denom = np.asarray(sizes[:n], dtype=float)
            denom = np.where(np.isfinite(denom) & (denom > 1e-12), denom, fallback)
            out[:n] = out[:n] / denom
        converted[key] = out.tolist()

    # A6 is not a distance unit, but its event classification depends on view
    # speed. Recompute graph peaks from the local-size-normalized A4 series so
    # two geometrically similar scenes at different world scales remain
    # comparable. Keep independent CSV sessions independent inside groups.
    local_speed = np.asarray(converted.get("A4", []), dtype=float)
    if local_speed.size and data:
        flags = np.zeros(local_speed.size, dtype=float)
        groups = []
        current = []
        current_key = None
        previous_time = None
        for index, row in enumerate(data[:local_speed.size]):
            key = _csv_session_key(row, index)
            row_time = _row_time(row)
            if current and (key != current_key or (previous_time is not None and row_time < previous_time)):
                groups.append(current)
                current = []
            current.append(index)
            current_key = key
            previous_time = row_time
        if current:
            groups.append(current)
        for indices in groups:
            vals = local_speed[np.asarray(indices, dtype=int)]
            positive = vals[np.isfinite(vals) & (vals > 0.0)]
            if positive.size:
                threshold = float(np.mean(positive) + 2.0 * np.std(positive))
                if threshold > 0.0:
                    idx = np.asarray(indices, dtype=int)
                    flags[idx] = np.where(np.isfinite(vals) & (vals >= threshold), 1.0, 0.0)
        converted["A6"] = flags.tolist()
    return converted


def _work_mode_percentages_from_metrics(metrics):
    vals = series_to_array(metrics.get("A14", []))
    vals = vals[np.isfinite(vals)]
    if vals.size == 0:
        return None
    obj = float(np.sum(np.abs(vals - 1.0) <= 0.25))
    edit = float(np.sum(np.abs(vals - 2.0) <= 0.25))
    other = max(float(vals.size) - obj - edit, 0.0)
    total = max(float(vals.size), 1.0)
    return {"object": 100.0 * obj / total, "edit": 100.0 * edit / total, "other": 100.0 * other / total}


def _format_work_mode_summary(metrics, language="EN"):
    pct = _work_mode_percentages_from_metrics(metrics)
    if not pct:
        return ""
    language = str(language or "EN").upper()
    if language == "ES":
        return f"Objeto {pct['object']:.0f}% · Edición {pct['edit']:.0f}% · Otro {pct['other']:.0f}%"
    return f"Object {pct['object']:.0f}% · Edit {pct['edit']:.0f}% · Other {pct['other']:.0f}%"


def _forest_real_display(scn, metric_key, row, metrics=None):
    """Human-readable real value paired with Z in G2."""
    es = get_language(scn) == "ES"
    raw = row.get("raw_untransformed_mean", row.get("raw_mean", row.get("raw_value", None)))
    if raw is None or not np.isfinite(float(raw)):
        return "—"
    raw = float(raw)
    if metric_key == "A14" and metrics is not None:
        return _format_work_mode_summary(metrics, get_language(scn))
    if metric_key in {"A6", "A7", "A8", "A9"}:
        return f"{raw:.2f} {'picos/min' if es else 'peaks/min'}"
    if metric_key == "A10":
        return f"{raw:.2f} {'eventos/min' if es else 'events/min'}"
    if metric_key == "A11":
        return f"{raw:+.2f} {'modif./min' if es else 'modifiers/min'}"
    if metric_key == "A12":
        return f"{raw:+.2f} {'vértices/min' if es else 'vertices/min'}"
    if metric_key == "A13":
        return f"{raw:+.2f} {'incidencias/min' if es else 'issues/min'}"
    if metric_key == "A15":
        return f"{raw:.2f} {'UV/min' if es else 'UV/min'}"
    if metric_key == "A16":
        return f"{raw:+.2f} {'objetos/min' if es else 'objects/min'}"
    if metric_key == "A17":
        return f"{raw:.1f}% {'activo' if es else 'active'}"
    if metric_key == "A18":
        return f"{raw:.2f} {'eventos/min' if es else 'events/min'}"
    if metric_key == "A19":
        return f"{raw:.1f}% {'activo' if es else 'active'}"
    unit = _g1_metric_unit(scn, metric_key)
    return f"{_g1_format_value(raw, abs(raw))}{(' ' + unit) if unit else ''}"

def _signed_log10_1p(values):
    """Signed log10(1+x) transform used by graph rendering.

    Defined locally because wildcard imports intentionally do not bring private
    helpers from ui_helpers into this module.
    """
    arr = np.asarray(values, dtype=float)
    return np.sign(arr) * np.log10(1.0 + np.abs(arr))


def _signed_pow10_m1(values):
    """Inverse of the signed log10(1+|x|) display transform."""
    arr = np.asarray(values, dtype=float)
    return np.sign(arr) * (np.power(10.0, np.abs(arr)) - 1.0)


def _g1_metric_uses_log(metric_key, use_log_scale):
    """Log-transform continuous G1 metrics, never categorical/binary states."""
    return bool(use_log_scale and metric_key not in {"A14", "A15", "A17", "A18", "A19"})


def _metric_context_range(metric_key, arrays):
    """Return a readable, metric-specific range shared by all compared CSVs."""
    clean = []
    for values in arrays:
        arr = np.asarray(values, dtype=float)
        arr = arr[np.isfinite(arr)]
        if arr.size:
            clean.append(arr)
    if not clean:
        return (0.0, 1.0)

    values = np.concatenate(clean)

    if values.size >= 4:
        low, high = np.percentile(values, [2.0, 98.0])
    else:
        low, high = float(np.min(values)), float(np.max(values))

    # Binary/event-state metrics.
    if metric_key in {"A2", "A6", "A15", "A17", "A18", "A19"}:
        return (0.0, max(1.0, float(high)))

    # G1 Work mode intentionally visualizes only Object and Edit states.
    # "Other" is treated as an unplotted gap so it cannot be mistaken for a
    # third work-mode curve/category.
    if metric_key == "A14":
        return (1.0, 2.0)

    # Signed deltas should be visually balanced around zero.
    if metric_key in {"A11", "A12", "A13", "A16"} or low < 0.0:
        bound = max(abs(float(low)), abs(float(high)), 1e-9)

        # Leave a small visual margin for the dense signed-delta traces.
        if metric_key in {"A12", "A13", "A16"}:
            bound *= 1.08

        return (-bound, bound)

    # Speeds, distances and counts are non-negative and benefit from a zero base.
    low = 0.0
    high = max(float(high), float(np.max(values)), 1e-9)
    pad = high * 0.05
    return (low, high + pad)


def _normalize_context(values, value_range):
    arr = np.asarray(values, dtype=float)
    low, high = value_range
    denom = max(float(high) - float(low), 1e-12)
    return np.clip((arr - float(low)) / denom, 0.0, 1.0)


def _format_context_range(value_range):
    low, high = value_range
    return f"{low:.3g}–{high:.3g}"




def _g1_series_array(values):
    """Return a float array without removing NaNs so X/Y row alignment is preserved."""
    if values is None:
        return np.asarray([], dtype=float)
    return np.asarray(list(values), dtype=float)



def _g1_work_mode_values(metric_key, values):
    """Return G1 values preserving all Work Mode states: Other/Object/Edit."""
    return np.asarray(values, dtype=float).copy()

def _g1_progress_x(values_x):
    """Map visible samples to 0–100 % while preserving missing rows.

    Using sample progress prevents irregular timestamps or very different CSV
    durations from compressing most points against one edge of the graph.
    """
    x = np.asarray(values_x, dtype=float)
    result = np.full(x.shape, np.nan, dtype=float)
    finite = np.isfinite(x)
    if not np.any(finite):
        return result
    valid = x[finite]
    low = float(np.min(valid))
    high = float(np.max(valid))
    if abs(high - low) <= 1e-12:
        finite_indices = np.flatnonzero(finite)
        if finite_indices.size == 1:
            result[finite_indices[0]] = 50.0
        else:
            result[finite_indices] = np.linspace(0.0, 100.0, finite_indices.size)
        return result
    result[finite] = ((valid - low) / (high - low)) * 100.0
    return result


def _g1_global_sample_progress_x(values_x):
    """Map the full recording to 0–100 % by row position, not timestamp value.

    This is intentionally used only by the Global view. It guarantees that all
    rows occupy the complete horizontal width even when timestamps are highly
    irregular, duplicated, or contain a large jump near the end.
    """
    x = np.asarray(values_x, dtype=float)
    result = np.full(x.shape, np.nan, dtype=float)
    n = int(x.size)
    if n <= 0:
        return result
    finite = np.isfinite(x)
    if not np.any(finite):
        return result
    if n == 1:
        result[finite] = 50.0
        return result
    row_progress = np.linspace(0.0, 100.0, n)
    result[finite] = row_progress[finite]
    return result


def _g1_window(values_x, values_y, start, size, global_view=False):
    """Return the visible finite X/Y pairs for one contiguous G1 data window."""
    x = np.asarray(values_x, dtype=float)
    y = np.asarray(values_y, dtype=float)
    n = min(x.size, y.size)
    if n <= 0:
        return np.asarray([], dtype=float), np.asarray([], dtype=float)
    if global_view:
        x = x[:n]
        y = y[:n]
    else:
        start = max(0, int(start))
        size = max(1, int(size))
        if start >= n:
            return np.asarray([], dtype=float), np.asarray([], dtype=float)
        end = min(n, start + size)
        x = x[start:end]
        y = y[start:end]
    finite = np.isfinite(x) & np.isfinite(y)
    return x[finite], y[finite]


def _g1_window_segments(values_x, values_y, start, size, global_view=False):
    """Return all contiguous finite segments inside the active G1 window.

    This preserves row alignment and splits the polyline whenever a metric has
    gaps/NaNs, so later valid samples are still drawn as additional segments
    instead of being visually lost.
    """
    x = np.asarray(values_x, dtype=float)
    y = np.asarray(values_y, dtype=float)
    n = min(x.size, y.size)
    if n <= 0:
        return []
    if global_view:
        x = x[:n]
        y = y[:n]
    else:
        start = max(0, int(start))
        size = max(1, int(size))
        if start >= n:
            return []
        end = min(n, start + size)
        x = x[start:end]
        y = y[start:end]

    finite = np.isfinite(x) & np.isfinite(y)
    if not np.any(finite):
        return []

    segments = []
    seg_start = None
    for idx, ok in enumerate(finite):
        if ok and seg_start is None:
            seg_start = idx
        elif (not ok) and seg_start is not None:
            xs = x[seg_start:idx]
            ys = y[seg_start:idx]
            if xs.size:
                segments.append((xs, ys))
            seg_start = None
    if seg_start is not None:
        xs = x[seg_start:]
        ys = y[seg_start:]
        if xs.size:
            segments.append((xs, ys))
    return segments


def _g1_spread_segments_uniformly(segments, start=0.0, end=100.0):
    """Redistribute every visible valid sample across the complete G1 width.

    Each finite sample receives an evenly spaced local X coordinate. NaN gaps
    still split the curve into separate segments, but short/irregular source
    timelines can no longer leave the line occupying only half of the window.
    """
    clean = []
    lengths = []
    for seg_x, seg_y in segments or []:
        y = np.asarray(seg_y, dtype=float)
        finite = np.isfinite(y)
        y = y[finite]
        if y.size:
            clean.append(y)
            lengths.append(int(y.size))
    total = sum(lengths)
    if total <= 0:
        return []
    positions = np.asarray([(start + end) * 0.5], dtype=float) if total == 1 else np.linspace(float(start), float(end), total)
    result = []
    offset = 0
    for y, length in zip(clean, lengths):
        result.append((positions[offset:offset + length], y))
        offset += length
    return result


def _g1_active_x_range(window_x_arrays):
    """Return the visible X domain with a small padding for readability."""
    clean = []
    for values in window_x_arrays:
        arr = np.asarray(values, dtype=float)
        arr = arr[np.isfinite(arr)]
        if arr.size:
            clean.append(arr)
    if not clean:
        return (0.0, 1.0)
    values = np.concatenate(clean)
    low = float(np.min(values))
    high = float(np.max(values))
    if low == high:
        pad = max(abs(low) * 0.01, 1e-6)
        return (low - pad, high + pad)
    span = high - low
    pad = span * 0.04
    return (low - pad, high + pad)


def _g1_window_tick_data(x_range, real_x_values, count=5):
    """Return evenly spaced plot positions with labels from real visible X values."""
    real = np.asarray(real_x_values, dtype=float)
    real = real[np.isfinite(real)]
    if real.size == 0:
        ticks = _g1_ticks(x_range, count)
        return ticks, [_g1_format_value(value, x_range[1] - x_range[0]) for value in ticks]
    count = max(3, min(5, int(count)))
    indices = np.linspace(0, real.size - 1, min(count, real.size)).astype(int)
    indices = sorted(set(int(i) for i in indices))
    x0, x1 = map(float, x_range)
    if real.size == 1:
        positions = [(x0 + x1) * 0.5]
    else:
        positions = [x0 + (idx / float(real.size - 1)) * (x1 - x0) for idx in indices]
    labels = [_g1_format_value(real[idx], float(np.max(real) - np.min(real)) if real.size > 1 else abs(float(real[idx]))) for idx in indices]
    return positions, labels


def _g1_ticks(value_range, count=4):
    """Generate between three and five readable ticks for a metric band."""
    low, high = map(float, value_range)
    if not np.isfinite(low) or not np.isfinite(high):
        return []
    count = max(3, min(5, int(count)))
    if abs(high - low) <= 1e-12:
        return [low]
    return list(np.linspace(low, high, count))


def _g1_format_value(value, span=None):
    value = float(value)
    if not np.isfinite(value):
        return "–"
    magnitude = abs(value)
    span = abs(float(span)) if span is not None and np.isfinite(span) else magnitude
    if magnitude >= 1e5 or (0 < magnitude < 1e-4):
        return f"{value:.2e}"
    if span >= 100:
        return f"{value:.0f}"
    if span >= 10:
        return f"{value:.1f}".rstrip('0').rstrip('.')
    if span >= 1:
        return f"{value:.2f}".rstrip('0').rstrip('.')
    if span >= 0.01:
        return f"{value:.3f}".rstrip('0').rstrip('.')
    return f"{value:.4g}"



def _g1_metric_unit(scn, metric_key):
    language = getattr(scn, "anali_language", "EN")
    if metric_key == "A4":
        return "tamaño local/min" if str(language).upper() == "ES" else "local size/min"
    if metric_key == "A5":
        return "× tamaño local" if str(language).upper() == "ES" else "× local size"
    return metric_unit(metric_key, language, radar=False)

def _mesh_metric_unit(scn, metric_key):
    units = {
        "UV_area": "%",
        "UV_islands": "count",
        "UV_stretch": "%",
        "UV_textel_density": "%",
        "Normal_count": "polygons",
        "Normal_percentage": "%",
        "Transformations": "state",
        "Position": "state",
        "Non_quads": "polygons",
        "Non_quads_percentage": "%",
        "Vertex_duplicate": "vertices",
        "Vertex_duplicate_percentage": "%",
        "Non_manifold": "vertices",
        "Non_manifold_percentage": "%",
        "N_faces": "faces",
        "N_meshes": "parts",
        "Face_by_mesh": "faces/part",
        "Angle": "°",
        "Similarity": "%",
    }
    unit = units.get(metric_key, "")
    if getattr(scn, "anali_language", "EN") == "ES":
        unit = {
            "count": "recuento", "px/m": "px/m", "state": "estado",
            "vertices": "vértices", "faces": "caras", "parts": "partes",
            "faces/part": "caras/parte",
        }.get(unit, unit)
    return unit


def _g1_label_with_unit(scn, metric_key):
    label = tr(scn, ANALYSIS.get(metric_key, {}).get("label", metric_key))
    unit = _g1_metric_unit(scn, metric_key)
    return f"{label} ({unit})" if unit else label


def _radar_data_label(scn, metric_key, compact=False):
    language = getattr(scn, "anali_language", "EN")
    label = metric_short_label(metric_key, language)
    if metric_key == "A14":
        return f"{label} · " + ("0 = Otro · 1 = Objeto · 2 = Edición · ↑ = más Edición" if str(language).upper() == "ES" else "0 = Other · 1 = Object · 2 = Edit · ↑ = more Edit")
    if metric_key == "A4":
        unit = "tamaño local/min" if str(language).upper() == "ES" else "local size/min"
    elif metric_key == "A5":
        unit = "× tamaño local" if str(language).upper() == "ES" else "× local size"
    else:
        unit = metric_unit(metric_key, language, radar=True)
    return f"{label} · {unit}" if unit else label


def _observation_label(index):
    # Fallback only. Real graph series should use csv_source_display_name().
    return f"Data {int(index) + 1}"

def _g1_window_rows(total_rows, percentage):
    total = max(1, int(total_rows))
    pct = min(100.0, max(1.0, float(percentage)))
    return max(1, min(total, int(math.ceil(total * pct / 100.0))))


def _g1_semantic_info(scn, metric_key, arrays):
    """Return concise metric-specific semantics and visible-window summaries for all data metrics."""
    clean = []
    for values in arrays or []:
        arr = np.asarray(values, dtype=float)
        arr = arr[np.isfinite(arr)]
        if arr.size:
            clean.extend(float(v) for v in arr)

    es = get_language(scn) == "ES"
    info = {"description": "", "ticks": None, "summary": "", "mean_label": None}
    if not clean:
        return info

    vals = np.asarray(clean, dtype=float)
    total_n = max(int(vals.size), 1)
    mean = float(np.mean(vals))
    minimum = float(np.min(vals))
    maximum = float(np.max(vals))
    total = float(np.sum(vals))

    if metric_key == "A1":
        info["description"] = "Tiempo transcurrido desde el inicio de la sesión." if es else "Elapsed time from the start of the session."
        info["summary"] = (f"Duración visible: {maximum:.1f} min" if es else f"Visible duration: {maximum:.1f} min")
    elif metric_key in {"A2", "A3"}:
        positive = vals[vals > 0.0]
        count = int(positive.size)
        duration = float(np.sum(positive)) if count else 0.0
        avg = float(np.mean(positive)) if count else 0.0
        info["description"] = "Duración de pausa por muestra; 0 = sin pausa." if es else "Pause duration per sample; 0 = no pause."
        info["summary"] = (f"{count} pausas · {duration:.1f} min total · media {avg:.1f} min" if es else f"{count} pauses · {duration:.1f} min total · mean {avg:.1f} min")
    elif metric_key == "A4":
        info["description"] = "Velocidad de movimiento de la vista relativa al tamaño local del objeto, en tamaños locales por minuto." if es else "Viewport movement speed relative to the object local size, in local sizes per minute."
        info["summary"] = (f"Media {mean:.2f} tamaños locales/min · máx {maximum:.2f}" if es else f"Mean {mean:.2f} local sizes/min · max {maximum:.2f}")
    elif metric_key == "A5":
        info["description"] = "Distancia entre la vista y el objeto activo relativa a su tamaño local; 1 equivale a un tamaño local." if es else "Distance from the view to the active object relative to its local size; 1 equals one local size."
        info["summary"] = (f"Media {mean:.2f}× tamaño local · rango {minimum:.2f}–{maximum:.2f}" if es else f"Mean {mean:.2f}× local size · range {minimum:.2f}–{maximum:.2f}")
    elif metric_key in {"A6", "A7", "A8", "A9"}:
        count = int(np.sum(vals >= 0.5))
        info["description"] = tr(scn, UI_TEXT['0_NO_PEAK_1_DETECTED_PEAK'])
        info["ticks"] = [(0.0, tr(scn, UI_TEXT['NO_PEAK'])), (1.0, tr(scn, UI_TEXT['PEAK']))]
        info["summary"] = (f"Se han detectado {count} picos" if es else f"{count} peaks detected")
    elif metric_key == "A10":
        count = int(round(float(np.sum(np.maximum(vals, 0.0)))))
        info["description"] = "Eventos de reutilización: Duplicar (Ctrl+V/Shift+D) o Instanciar (Alt+D)." if es else "Reuse events: Duplicate (Ctrl+V/Shift+D) or Instance (Alt+D)."
        info["summary"] = (f"Se han detectado {count} reutilizaciones" if es else f"{count} reuse events detected")
    elif metric_key in {"A11", "A12", "A13", "A16"}:
        pos = float(np.sum(vals[vals > 0.0]))
        neg = float(-np.sum(vals[vals < 0.0]))
        net = float(np.sum(vals))
        names_es = {"A11":("modificadores creados","eliminados"),"A12":("vértices añadidos","eliminados"),"A13":("incidencias generadas","resueltas"),"A16":("objetos creados","eliminados")}
        names_en = {"A11":("modifiers created","removed"),"A12":("vertices added","removed"),"A13":("issues generated","resolved"),"A16":("objects created","removed")}
        a,b = (names_es if es else names_en)[metric_key]
        info["description"] = ("Cambio con signo: positivo añade/crea; negativo elimina/resuelve." if es else "Signed change: positive adds/creates; negative removes/resolves.")
        info["summary"] = ((f"+ {_g1_format_value(pos, 10)} · − {_g1_format_value(neg, 10)} · neto {_g1_format_value(net, 10)}") if es else (f"+ {_g1_format_value(pos, 10)} · − {_g1_format_value(neg, 10)} · net {_g1_format_value(net, 10)}"))
    elif metric_key == "A14":
        other_count = int(np.sum(np.abs(vals - 0.0) <= 0.25))
        object_count = int(np.sum(np.abs(vals - 1.0) <= 0.25))
        edit_count = int(np.sum(np.abs(vals - 2.0) <= 0.25))
        represented = max(other_count + object_count + edit_count, 1)
        other_pct = 100.0 * other_count / represented
        obj_pct = 100.0 * object_count / represented
        edit_pct = 100.0 * edit_count / represented
        info["description"] = (
            "0 = Otro · 1 = Modo Objeto · 2 = Modo Edición · Un valor más alto significa mayor predominio del Modo Edición."
            if es else
            "0 = Other · 1 = Object Mode · 2 = Edit Mode · A higher value means greater Edit Mode predominance."
        )
        info["ticks"] = [
            (0.0, "Otro" if es else "Other"),
            (1.0, tr(scn, UI_TEXT['OBJECT'])),
            (2.0, tr(scn, UI_TEXT['EDIT'])),
        ]
        info["summary"] = (
            f"Otro {other_pct:.0f}% · Objeto {obj_pct:.0f}% · Edición {edit_pct:.0f}% · ↑ = más Edición"
            if es else
            f"Other {other_pct:.0f}% · Object {obj_pct:.0f}% · Edit {edit_pct:.0f}% · ↑ = more Edit"
        )
        info["mean_label"] = tr(scn, UI_TEXT['AVERAGE_STATE'])
    elif metric_key == "A15":
        count = int(np.sum(vals >= 0.5))
        info["description"] = "0 = sin acción UV completada; 1 = acción UV completada." if es else "0 = no completed UV action; 1 = completed UV action."
        info["ticks"] = [(0.0, tr(scn, "No UV action")), (1.0, tr(scn, "UV action"))]
        info["summary"] = (f"Se han detectado {count} acciones UV" if es else f"{count} UV actions detected")
    elif metric_key == "A17":
        active = int(np.sum(vals >= 0.5))
        pct = 100.0 * active / total_n
        info["description"] = "Estado: 1 cuando X-Ray o Wireframe está activo; 0 cuando no." if es else "State: 1 when X-Ray or Wireframe is active; 0 otherwise."
        info["ticks"] = [(0.0, tr(scn, "Off")), (1.0, tr(scn, "On"))]
        info["summary"] = (f"Oclusión activa en {pct:.0f}% de las muestras" if es else f"Occlusion active in {pct:.0f}% of samples")
    elif metric_key == "A18":
        count = int(np.sum(vals >= 0.5))
        info["description"] = "0 = sin deshacer registrado; 1 = acción de deshacer completada." if es else "0 = no Undo recorded; 1 = completed Undo action."
        info["ticks"] = [(0.0, tr(scn, "Off")), (1.0, tr(scn, "On"))]
        info["summary"] = (f"Se han detectado {count} acciones de deshacer" if es else f"{count} Undo actions detected")
    elif metric_key == "A19":
        active = int(np.sum(vals >= 0.5))
        pct = 100.0 * active / total_n
        info["description"] = "Estado: 1 en vista ortográfica; 0 en perspectiva u otro estado." if es else "State: 1 in orthographic view; 0 in perspective or another state."
        info["ticks"] = [(0.0, tr(scn, "Off")), (1.0, tr(scn, "On"))]
        info["summary"] = (f"Vista ortográfica activa en {pct:.0f}% de las muestras" if es else f"Orthographic view active in {pct:.0f}% of samples")
    return info

def _g1_real_range(arrays):
    clean = []
    for values in arrays:
        arr = np.asarray(values, dtype=float)
        arr = arr[np.isfinite(arr)]
        if arr.size:
            clean.append(arr)
    if not clean:
        return (0.0, 1.0)
    values = np.concatenate(clean)
    low = float(np.min(values)); high = float(np.max(values))
    if low == high:
        pad = max(abs(low) * 0.05, 0.5)
        return (low - pad, high + pad)
    pad = (high - low) * 0.08
    return (low - pad, high + pad)


def _g1_display_range(metric_key, arrays, global_view=False):
    """Return the range actually used by G1.

    Window mode always uses the complete real range of the visible window.

    Global mode for A12/A13/A16 uses a robust symmetric envelope calculated
    only from non-zero absolute deltas. This prevents long stretches of zeros
    and isolated extreme edits from defining the whole vertical scale.
    """
    real_range = _g1_real_range(arrays)

    if not global_view or metric_key not in {"A12", "A13", "A16"}:
        return real_range

    clean = []
    for values in arrays:
        arr = np.asarray(values, dtype=float)
        arr = arr[np.isfinite(arr)]
        if arr.size:
            clean.append(arr)

    if not clean:
        return real_range

    values = np.concatenate(clean)
    abs_nonzero = np.abs(values[np.abs(values) > 1e-12])

    if abs_nonzero.size == 0:
        return real_range

    # Robust Global envelope.
    # With many events, use the 95th percentile of NON-ZERO magnitudes.
    # With medium samples, use the 90th percentile.
    # With very few events, preserve the true maximum.
    if abs_nonzero.size >= 20:
        bound = float(np.percentile(abs_nonzero, 95))
    elif abs_nonzero.size >= 8:
        bound = float(np.percentile(abs_nonzero, 90))
    else:
        bound = float(np.max(abs_nonzero))

    if not np.isfinite(bound) or bound <= 1e-12:
        return real_range

    bound *= 1.10
    return (-bound, bound)


def _g1_visual_values(metric_key, values, value_range, global_view=False):
    """Clip only the rendered Global trace; never modify source data."""
    arr = np.asarray(values, dtype=float)
    if global_view and metric_key in {"A12", "A13", "A16"}:
        low, high = value_range
        return np.clip(arr, float(low), float(high))
    return arr


def _g1_band_y(values, value_range, band_bottom, band_top):
    low, high = value_range
    denom = max(float(high) - float(low), 1e-12)
    arr = np.asarray(values, dtype=float)
    return band_bottom + ((arr - float(low)) / denom) * (band_top - band_bottom)


def _g1_bands_layout(metric_count, configured_height):
    """Stable G1 band sizes; never returns a negative/inverted band."""
    count = max(1, int(metric_count))
    min_band_height = 1.55
    min_gap = 0.30
    required = count * min_band_height + max(0, count - 1) * min_gap
    plot_height = max(float(configured_height), required)
    band_height = max(min_band_height, (plot_height - max(0, count - 1) * min_gap) / count)
    return plot_height, band_height, min_gap


def _g1_inner_band_bounds(bottom, top):
    height = max(0.001, float(top) - float(bottom))
    padding = min(0.14, height * 0.10)
    return float(bottom) + padding, float(top) - padding


def _g1_map_x_to_axis(values, x_range, axis_x):
    x0, x1 = map(float, x_range)
    denom = max(x1 - x0, 1e-12)
    arr = np.asarray(values, dtype=float)
    return ((arr - x0) / denom) * float(axis_x)


def _draw_g1_gap_markers(scn, segments, band, x_range, z_offset, name_prefix):
    """Draw a small visual break marker wherever a G1 line has internal gaps."""
    if not segments or len(segments) < 2:
        return
    gap_color = (0.55, 0.55, 0.55, 1.0)
    axis_x = float(scn.axis_scale_x)
    for idx in range(len(segments) - 1):
        left_x, left_y = segments[idx]
        right_x, right_y = segments[idx + 1]
        if left_x.size == 0 or right_x.size == 0:
            continue
        left_px = _g1_map_x_to_axis([left_x[-1]], x_range, axis_x)[0]
        right_px = _g1_map_x_to_axis([right_x[0]], x_range, axis_x)[0]
        mid_x = (float(left_px) + float(right_px)) * 0.5
        left_value = _signed_log10_1p([left_y[-1]]) if band.get('log_scale') else [left_y[-1]]
        right_value = _signed_log10_1p([right_y[0]]) if band.get('log_scale') else [right_y[0]]
        left_py = _g1_band_y(left_value, band['range'], band['bottom'], band['top'])[0]
        right_py = _g1_band_y(right_value, band['range'], band['bottom'], band['top'])[0]
        mid_y = (float(left_py) + float(right_py)) * 0.5
        dx = 0.025 * max(1.0, axis_x)
        dy = 0.035 * max(1.0, band['top'] - band['bottom'])
        create_axis(Vector((mid_x - dx, mid_y - dy, z_offset + 0.001)), Vector((mid_x + dx, mid_y + dy, z_offset + 0.001)), gap_color, f'{name_prefix}_GapA_{idx}', radius=0.0028, vertices=6)
        create_axis(Vector((mid_x - dx, mid_y + dy, z_offset + 0.001)), Vector((mid_x + dx, mid_y - dy, z_offset + 0.001)), gap_color, f'{name_prefix}_GapB_{idx}', radius=0.0028, vertices=6)


def _g1_reduce_viewport_noise(context):
    screen = getattr(context, 'screen', None)
    if screen is None:
        return
    for area in screen.areas:
        if area.type != 'VIEW_3D':
            continue
        overlay = getattr(area.spaces.active, 'overlay', None)
        if overlay is not None:
            overlay.show_floor = False
            overlay.show_axis_x = False
            overlay.show_axis_y = False
            overlay.show_axis_z = False
            overlay.show_cursor = False


def _g1_step_xy(x_values, y_values):
    x = np.asarray(x_values, dtype=float); y = np.asarray(y_values, dtype=float)
    n = min(x.size, y.size)
    if n <= 1:
        return x[:n], y[:n]
    sx=[x[0]]; sy=[y[0]]
    for i in range(1,n):
        sx.extend([x[i], x[i]])
        sy.extend([y[i-1], y[i]])
    return np.asarray(sx,float), np.asarray(sy,float)

def _draw_g1_semantic_series(scn, metric_key, seg_x, display_y, raw_y, band, z_offset, plot_axis_x, plot_axis_y, csv_name, metric_name, color):
    visual = metric_visual(metric_key)
    if visual == "categorical_step":
        sx, sy = _g1_step_xy(seg_x, display_y)
        return create_interaction_graph_3d(sx, sy, z_offset, plot_axis_x, plot_axis_y, csv_name=csv_name, metric_name=metric_name, color=color, x_range=(0.0,100.0), y_range=(0.0,plot_axis_y))
    if visual in {"event_impulse", "balance_zero_bar"}:
        low, high = band['range']
        if visual == "balance_zero_bar":
            baseline = _g1_band_y(np.asarray([0.0]), band['range'], band['bottom'], band['top'])[0]
        else:
            baseline = _g1_band_y(np.asarray([0.0]), band['range'], band['bottom'], band['top'])[0] if low <= 0.0 <= high else band['bottom']
        px = _g1_map_x_to_axis(seg_x, (0.0,100.0), plot_axis_x)
        drawn = None
        for j,(x,y,rv) in enumerate(zip(px, display_y, raw_y)):
            if visual == "event_impulse" and abs(float(rv)) < 0.5:
                continue
            drawn = create_axis(Vector((float(x), float(baseline), z_offset)), Vector((float(x), float(y), z_offset)), color, f"G1Semantic_{sanitize_name(csv_name)}_{sanitize_name(metric_name)}_{j}", radius=0.018 if visual == "event_impulse" else 0.024, vertices=6)
        return drawn
    return create_interaction_graph_3d(seg_x, display_y, z_offset, plot_axis_x, plot_axis_y, csv_name=csv_name, metric_name=metric_name, color=color, x_range=(0.0,100.0), y_range=(0.0,plot_axis_y))

def _draw_g1_axes_and_bands(scn, x_range, bands, show_mean=False, csv_spans=None, x_label='Session duration (h)', x_tick_data=None, axis_scale_x=None, axis_scale_y=None):
    """Draw a common real X axis and independent real-value Y scales per band."""
    white = (0.92, 0.92, 0.92, 1.0)
    muted = (0.30, 0.30, 0.30, 1.0)
    grid = (0.22, 0.22, 0.22, 1.0)
    mean_color = (0.55, 0.55, 0.55, 1.0)
    axis_x = float(axis_scale_x if axis_scale_x is not None else scn.axis_scale_x)
    axis_y = float(axis_scale_y if axis_scale_y is not None else scn.axis_scale_y)
    x0, x1 = x_range
    x_span = x1 - x0
    if x_tick_data:
        ticks_x, tick_labels_x = x_tick_data
    else:
        ticks_x = _g1_ticks(x_range, 5)
        tick_labels_x = [_g1_format_value(tick, x_span) for tick in ticks_x]
    create_axis(Vector((0, 0, 0.02)), Vector((axis_x, 0, 0.02)), white, 'G1_Axis_X', radius=0.010, vertices=8)
    for idx, tick in enumerate(ticks_x):
        px = 0.0 if x1 == x0 else ((tick - x0) / (x1 - x0)) * axis_x
        create_axis(Vector((px, -0.045, 0.02)), Vector((px, 0.045, 0.02)), white, f'G1_XTick_{idx}', radius=0.006, vertices=6)
        label_x = tick_labels_x[idx] if idx < len(tick_labels_x) else _g1_format_value(tick, x_span)
        create_text_label(label_x, (px, -0.30, 0.02), 0.20, f'G1_XTickLabel_{idx}', align_x='CENTER')
        create_axis(Vector((px, 0.0, -0.018)), Vector((px, axis_y, -0.018)), grid, f'G1_XGrid_{idx}', radius=0.0020, vertices=6)
    create_text_label(x_label, (axis_x * 0.5, -0.62, 0.02), 0.25, 'G1_Label_X', align_x='CENTER')

    if csv_spans and len(csv_spans) > 1:
        ordered = sorted(csv_spans, key=lambda item: item[0])
        for idx in range(len(ordered) - 1):
            left_end = ordered[idx][1]
            right_start = ordered[idx + 1][0]
            if right_start > left_end:
                divider_x = ((left_end + right_start) * 0.5 - x0) / max(x_span, 1e-12) * axis_x
                create_axis(Vector((divider_x, 0.0, -0.01)), Vector((divider_x, axis_y, -0.01)), grid, f'G1_CSVDivider_{idx}', radius=0.004, vertices=6)

    for idx, band in enumerate(bands):
        bottom, top = band['bottom'], band['top']
        outer_bottom = band.get('outer_bottom', bottom)
        outer_top = band.get('outer_top', top)
        low, high = band['range']
        span = high - low
        display_low, display_high = (tuple(_signed_pow10_m1([low, high])) if band.get('log_scale') else (low, high))
        display_span = display_high - display_low
        create_axis(Vector((0, outer_bottom, -0.01)), Vector((axis_x, outer_bottom, -0.01)), muted, f'G1_BandBase_{idx}', radius=0.004, vertices=6)
        center_y = (outer_bottom + outer_top) * 0.5
        info_x = axis_x + 0.55
        create_text_label(band['label'], (info_x, center_y + 0.20, 0.02), 0.23, f'G1_BandLabel_{idx}', color=white, align_x='LEFT')
        semantic = band.get('semantic') or {}
        range_text = f"{_g1_format_value(display_low, display_span)} – {_g1_format_value(display_high, display_span)}"
        create_text_label(range_text, (info_x, center_y - 0.02, 0.02), 0.16, f'G1_BandRange_{idx}', color=white, align_x='LEFT')
        # Keep the plot itself concise. Interpretive prose lives in the
        # contextual 'How to read this graph' dialog. Only short state summaries
        # remain visible when they add direct numeric information.
        if semantic.get('summary'):
            create_text_label(semantic['summary'], (info_x, center_y - 0.25, 0.02), 0.14, f'G1_BandSummary_{idx}', color=white, align_x='LEFT')
        if semantic.get('ticks'):
            tick_items = semantic.get('ticks')
        else:
            tick_positions = _g1_ticks((low, high), 4)
            tick_items = [
                (tick, _g1_format_value(float(_signed_pow10_m1([tick])[0]), display_span) if band.get('log_scale') else _g1_format_value(tick, span))
                for tick in tick_positions
            ]
        for tick_idx, tick_item in enumerate(tick_items):
            tick, tick_label = tick_item
            if tick < low - 1e-9 or tick > high + 1e-9:
                continue
            py = bottom + ((tick - low) / max(high - low, 1e-12)) * (top - bottom)
            create_axis(Vector((0, py, -0.015)), Vector((axis_x, py, -0.015)), grid, f'G1_YGrid_{idx}_{tick_idx}', radius=0.0025, vertices=6)
            create_axis(Vector((-0.045, py, 0.02)), Vector((0.045, py, 0.02)), white, f'G1_YTick_{idx}_{tick_idx}', radius=0.005, vertices=6)
            create_text_label(str(tick_label), (-0.10, py, 0.02), 0.17, f'G1_YTickLabel_{idx}_{tick_idx}', align_x='RIGHT')
        if band.get('constant'):
            create_text_label(f"Constant: {_g1_format_value(band.get('raw_mean', 0.0), span)}", (axis_x - 0.08, top - 0.16, 0.02), 0.17, f'G1_ConstantLabel_{idx}', align_x='RIGHT')
        if show_mean and band.get('mean') is not None:
            mean = float(band['mean'])
            py = bottom + ((mean - low) / max(high - low, 1e-12)) * (top - bottom)
            create_axis(Vector((0, py, 0.005)), Vector((axis_x, py, 0.005)), mean_color, f'G1_Mean_{idx}', radius=0.0035, vertices=6)
            create_text_label(f"{(band.get('semantic') or {}).get('mean_label') or tr(scn, UI_TEXT['MEAN'])}: {_g1_format_value(float(band.get('raw_mean', mean)), display_span)}", (axis_x - 0.06, py + 0.10, 0.02), 0.16, f'G1_MeanLabel_{idx}', align_x='RIGHT')


def _draw_g1_overlay_axes(scn, x_range, metrics, show_mean=False, csv_spans=None, x_label='Session duration (h)', x_tick_data=None, axis_scale_x=None, axis_scale_y=None):
    """Draw one shared plot area with an explicitly independent real range per metric."""
    white = (0.92, 0.92, 0.92, 1.0)
    muted = (0.34, 0.34, 0.34, 1.0)
    grid = (0.20, 0.20, 0.20, 1.0)
    mean_color = (0.55, 0.55, 0.55, 1.0)
    axis_x = float(axis_scale_x if axis_scale_x is not None else scn.axis_scale_x)
    axis_y = float(axis_scale_y if axis_scale_y is not None else scn.axis_scale_y)
    bottom = axis_y * 0.06
    top = axis_y * 0.96
    x0, x1 = x_range
    x_span = x1 - x0

    if x_tick_data:
        ticks_x, tick_labels_x = x_tick_data
    else:
        ticks_x = _g1_ticks(x_range, 5)
        tick_labels_x = [_g1_format_value(tick, x_span) for tick in ticks_x]
    create_axis(Vector((0, bottom, 0.02)), Vector((axis_x, bottom, 0.02)), white, 'G1_Axis_X', radius=0.010, vertices=8)
    for idx, tick in enumerate(ticks_x):
        px = 0.0 if x1 == x0 else ((tick - x0) / (x1 - x0)) * axis_x
        create_axis(Vector((px, bottom - 0.045, 0.02)), Vector((px, bottom + 0.045, 0.02)), white, f'G1_XTick_{idx}', radius=0.006, vertices=6)
        label_x = tick_labels_x[idx] if idx < len(tick_labels_x) else _g1_format_value(tick, x_span)
        create_text_label(label_x, (px, bottom - 0.30, 0.02), 0.20, f'G1_XTickLabel_{idx}', align_x='CENTER')
        create_axis(Vector((px, bottom, -0.018)), Vector((px, top, -0.018)), grid, f'G1_XGrid_{idx}', radius=0.0020, vertices=6)
    create_text_label(x_label, (axis_x * 0.5, bottom - 0.62, 0.02), 0.25, 'G1_Label_X', align_x='CENTER')

    # Shared normalized Y axis in overlay mode; each metric keeps its real range in the cards.
    create_axis(Vector((0, bottom, 0.02)), Vector((0, top, 0.02)), white, 'G1_Axis_Y_Overlay', radius=0.010, vertices=8)
    for idx, fraction in enumerate((0.0, 1/4, 2/4, 3/4, 1.0)):
        py = bottom + fraction * (top - bottom)
        create_axis(Vector((0, py, -0.015)), Vector((axis_x, py, -0.015)), grid, f'G1_OverlayGrid_{idx}', radius=0.0025, vertices=6)
        create_axis(Vector((-0.045, py, 0.02)), Vector((0.045, py, 0.02)), white, f'G1_OverlayYTick_{idx}', radius=0.005, vertices=6)
        create_text_label(f'{fraction * 100:.0f}%', (-0.10, py, 0.02), 0.17, f'G1_OverlayYLabel_{idx}', align_x='RIGHT')

    if csv_spans and len(csv_spans) > 1:
        ordered = sorted(csv_spans, key=lambda item: item[0])
        for idx in range(len(ordered) - 1):
            left_end, right_start = ordered[idx][1], ordered[idx + 1][0]
            if right_start > left_end:
                divider_x = ((left_end + right_start) * 0.5 - x0) / max(x_span, 1e-12) * axis_x
                create_axis(Vector((divider_x, bottom, -0.01)), Vector((divider_x, top, -0.01)), grid, f'G1_CSVDivider_{idx}', radius=0.004, vertices=6)

    card_start_x = axis_x + 0.45
    column_gap = 4.85
    max_text_len = max([len(str(m.get('label', ''))) + len(str((m.get('semantic') or {}).get('description', ''))) for m in metrics] or [20])
    card_height = 1.08 if max_text_len > 70 else 0.92
    max_rows_per_column = max(2, int(max(1.0, (top - bottom)) / card_height))
    column_count = max(1, int(math.ceil(len(metrics) / max_rows_per_column)))
    column_gap = max(4.85, min(7.2, 3.8 + max_text_len * 0.035))
    create_text_label(tr(scn, UI_TEXT['INDEPENDENT_Y_RANGES']), (card_start_x, top + 0.16, 0.02), 0.22, 'G1_OverlayScaleTitle', color=white, align_x='LEFT')

    for idx, metric in enumerate(metrics):
        column = idx // max_rows_per_column if column_count > 1 else 0
        row = idx % max_rows_per_column if column_count > 1 else idx
        card_x = card_start_x + column * column_gap
        y = top - 0.18 - row * card_height
        low, high = metric['range']
        span = high - low
        display_low, display_high = (tuple(_signed_pow10_m1([low, high])) if metric.get('log_scale') else (low, high))
        display_span = display_high - display_low
        label = metric['label']
        range_text = f"{_g1_format_value(display_low, display_span)} … {_g1_format_value(display_high, display_span)}"

        # A subtle separator makes every metric read as an independent card.
        create_axis(
            Vector((card_x - 0.08, y + 0.16, -0.015)),
            Vector((card_x + 4.25, y + 0.16, -0.015)),
            grid,
            f'G1_OverlayCardSeparator_{idx}',
            radius=0.0025,
            vertices=6,
        )
        create_text_label(label, (card_x, y, 0.02), 0.19, f'G1_OverlayMetric_{idx}', color=white, align_x='LEFT')
        create_text_label(range_text, (card_x, y - 0.20, 0.02), 0.15, f'G1_OverlayRange_{idx}', color=white, align_x='LEFT')

        semantic = metric.get('semantic') or {}
        next_line_y = y - 0.39
        if semantic.get('summary'):
            create_text_label(semantic['summary'], (card_x, next_line_y, 0.02), 0.125, f'G1_OverlaySummary_{idx}', color=white, align_x='LEFT')
            next_line_y -= 0.19

        if metric.get('constant'):
            create_text_label(
                f"Constant: {_g1_format_value(metric.get('raw_mean', 0.0), span)}",
                (card_x, next_line_y, 0.02),
                0.13,
                f'G1_OverlayConstant_{idx}',
                color=white,
                align_x='LEFT',
            )
        elif show_mean and metric.get('mean') is not None:
            mean = float(metric['mean'])
            py = bottom + ((mean - low) / max(high - low, 1e-12)) * (top - bottom)
            # Short reference segment, not a full-width line, to avoid confusing scales.
            create_axis(Vector((axis_x * 0.86, py, 0.005 + idx * 0.001)), Vector((axis_x, py, 0.005 + idx * 0.001)), mean_color, f'G1_OverlayMean_{idx}', radius=0.0035, vertices=6)
            create_text_label(
                f"Mean {_g1_format_value(float(metric.get('raw_mean', mean)), display_span)}",
                (card_x, next_line_y, 0.02),
                0.13,
                f'G1_OverlayMeanLabel_{idx}',
                color=white,
                align_x='LEFT',
            )

    create_text_label(tr(scn, UI_TEXT['OVERLAY_INDEPENDENT_Y_SCALE_PER_METRIC']), (axis_x * 0.5, top + 0.10, 0.02), 0.18, 'G1_OverlayNotice', color=muted, align_x='CENTER')
    return bottom, top

_MODEL_METRIC_ORDER = [
    "N_faces", "N_meshes", "Face_by_mesh", "Angle", "Non_quads", "Non_quads_percentage",
    "Vertex_duplicate", "Vertex_duplicate_percentage", "Non_manifold", "Non_manifold_percentage",
    "Normal_count", "Normal_percentage", "UV_area", "UV_islands", "UV_stretch", "UV_textel_density",
    "Transformations", "Position", "Similarity",
]

_MODEL_METRIC_LABELS = {
    "N_faces": "Polygon count",
    "N_meshes": "Mesh count",
    "Face_by_mesh": "Polygon per mesh",
    "Angle": "Mean edge angle",
    "Non_quads": "Non-quad polygon count",
    "Non_quads_percentage": "Non-quad polygon percentage",
    "Vertex_duplicate": "Duplicate vertices count",
    "Vertex_duplicate_percentage": "Duplicate vertices percentage",
    "Non_manifold": "Non-manifold vertex count",
    "Non_manifold_percentage": "Non-manifold vertex percentage",
    "Normal_count": "Inverted polygon normal count",
    "Normal_percentage": "Inverted polygon normal percentage",
    "UV_area": "UV coverage",
    "UV_islands": "Island count",
    "UV_stretch": "UV stretch percentage",
    "UV_textel_density": "Texel density deviation",
    "Transformations": "Transforms applied",
    "Position": "World origin alignment",
    "Similarity": "Similarity vs. Reference",
}


def _plain_mapping(value):
    """Convert Blender IDPropertyGroup/dicts to an ordinary dictionary."""
    if value is None:
        return {}
    try:
        return {str(key): value[key] for key in value.keys()}
    except Exception:
        try:
            return dict(value)
        except Exception:
            return {}


def _correlation_pair_key(value):
    """Normalize CSV/object names so ``chair_data.csv`` matches ``Chair``."""
    stem = os.path.splitext(os.path.basename(str(value or "")))[0].lower()
    suffixes = (
        "_data_anon", "-data-anon", "_anonymous", "-anonymous",
        "_data", "-data", "_log", "-log", "_metrics", "-metrics",
        "_session", "-session", "_final", "-final",
    )
    changed = True
    while changed:
        changed = False
        for suffix in suffixes:
            if stem.endswith(suffix):
                stem = stem[:-len(suffix)]
                changed = True
                break
    return re.sub(r"[^a-z0-9]+", "", stem)


def _pair_csv_and_model_rows(csv_records, model_records, scn=None):
    """Pair observations using explicit UI associations, then safe fallbacks."""
    pairs = []

    if scn is not None:
        explicit_pairs = []
        csv_by_path = {os.path.abspath(str(record.get("path", ""))): record for record in csv_records if record.get("path")}
        csv_by_name = {os.path.basename(str(record.get("name", ""))): record for record in csv_records}
        model_by_name = {str(record.get("name", "")): record for record in model_records}
        used_csv_ids = set()
        used_model_ids = set()
        for association in getattr(scn, "anali_data_mesh_pairs", []):
            data_path = os.path.abspath(str(getattr(association, "data_path", "") or ""))
            mesh_name = str(getattr(association, "mesh_record", "") or "")
            if not mesh_name or mesh_name == "__NONE__":
                # Migrate associations created by older versions that stored a
                # direct Blender object pointer instead of a metric-record key.
                mesh_object = getattr(association, "mesh_object", None)
                mesh_name = getattr(mesh_object, "name", "") if mesh_object is not None else ""
            csv_record = csv_by_path.get(data_path) or csv_by_name.get(os.path.basename(data_path))
            model_record = model_by_name.get(mesh_name)
            if csv_record is None or model_record is None:
                continue
            # Explicit associations are authoritative. Do not silently discard
            # a configured row merely because the same data or mesh observation
            # is referenced by another association.
            explicit_pairs.append((csv_record, model_record, "explicit"))
            used_csv_ids.add(id(csv_record)); used_model_ids.add(id(model_record))
        if explicit_pairs:
            return explicit_pairs
    used_models = set()

    model_by_key = {}
    for model_index, model in enumerate(model_records):
        model_by_key.setdefault(model["pair_key"], []).append(model_index)

    unmatched_csv = []
    for csv_index, csv_record in enumerate(csv_records):
        candidates = [
            idx for idx in model_by_key.get(csv_record["pair_key"], [])
            if idx not in used_models
        ]
        if len(candidates) == 1 and csv_record["pair_key"]:
            model_index = candidates[0]
            used_models.add(model_index)
            pairs.append((csv_record, model_records[model_index], "name"))
        else:
            unmatched_csv.append(csv_record)

    unmatched_models = [
        model for idx, model in enumerate(model_records) if idx not in used_models
    ]

    if unmatched_csv and len(unmatched_csv) == len(unmatched_models):
        # Deterministic fallback. CSV order follows the Data panel; model order
        # is alphabetical so repeated executions remain reproducible.
        unmatched_models = sorted(unmatched_models, key=lambda item: item["name"].lower())
        for csv_record, model_record in zip(unmatched_csv, unmatched_models):
            pairs.append((csv_record, model_record, "order"))

    pairs.sort(key=lambda item: csv_records.index(item[0]))
    return pairs




def _selected_mesh_metric_keys(scn):
    """Return mesh metric keys enabled for G2/G3 (not G4 correlation)."""
    flags = tuple(getattr(scn, "anali_graph_mesh_metrics", (False,) * len(_MODEL_METRIC_ORDER)))
    return [
        key for index, key in enumerate(_MODEL_METRIC_ORDER)
        if index < len(flags) and flags[index]
    ]


def _mesh_metric_records(scn):
    """Return calculated mesh observations stored by the Meshes panel."""
    records = []
    for object_name, metric_values in _plain_mapping(scn.get("metrics_data", {})).items():
        values = _plain_mapping(metric_values)
        if not values:
            continue
        records.append({
            "name": str(object_name),
            "pair_key": _correlation_pair_key(object_name),
            "values": values,
        })
    return sorted(records, key=lambda item: item["name"].lower())


def _finite_mesh_value(record, key):
    """Read one scalar mesh metric, rejecting booleans, NaN and infinities."""
    value = record.get("values", {}).get(key)
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    return value if np.isfinite(value) else None


def _pearson_heatmap_data(context):
    """Build G4 data for CSV↔mesh, CSV↔CSV, or mesh↔mesh Pearson heatmaps."""
    scn = context.scene
    mode = getattr(scn, "anali_heatmap_correlation_mode", "CSV_MESH")
    selected_csvs = selected_csv_graph_sources(scn)

    csv_records = []
    if mode in {"CSV_MESH", "CSV_CSV"}:
        if len(selected_csvs) < 3:
            raise ValueError(tr(scn, UI_TEXT['SELECT_AT_LEAST_THREE_DATA_FILES_IN_THE_DATA_TAB_PEARSON_IS_UNDEFINED_']))
        for csv_path in selected_csvs:
            data, metrics = _cached_csv_analysis(
                csv_path,
                getattr(scn, "max_reasonable_speed", DEFAULT_MAX_REASONABLE_SPEED),
            )
            metrics = _graph_metrics_with_local_view_units(metrics, data)
            csv_records.append({
                "name": csv_source_display_name(scn, csv_path),
                "path": os.path.abspath(csv_path),
                "pair_key": _correlation_pair_key(csv_path),
                "values": summarize_csv_metrics_for_correlation(metrics),
            })

    metrics_store = _plain_mapping(scn.get("metrics_data", {}))
    model_records = []
    if mode in {"CSV_MESH", "MESH_MESH"}:
        for object_name, metric_values in metrics_store.items():
            values = _plain_mapping(metric_values)
            if not values:
                continue
            model_records.append({
                "name": str(object_name),
                "pair_key": _correlation_pair_key(object_name),
                "values": values,
            })
        if len(model_records) < 3:
            raise ValueError(tr(scn, UI_TEXT['CALCULATE_MODEL_METRICS_FOR_AT_LEAST_THREE_MESH_OBJECTS_IN_THE_MESHES_']))

    csv_flags = tuple(getattr(scn, "anali_corr_csv_metrics", (True,) * len(ANALYSIS)))
    csv_keys = [
        key for index, key in enumerate(ANALYSIS.keys())
        if index < len(csv_flags) and csv_flags[index]
    ]

    mesh_flags = tuple(getattr(scn, "anali_corr_mesh_metrics", (True,) * len(_MODEL_METRIC_ORDER)))
    selected_model_keys = {
        key for index, key in enumerate(_MODEL_METRIC_ORDER)
        if index < len(mesh_flags) and mesh_flags[index]
    }
    model_keys = [
        key for key in _MODEL_METRIC_ORDER
        if key in selected_model_keys and any(key in record["values"] for record in model_records)
    ]
    # Unknown/custom mesh metrics are not added automatically because the user
    # cannot explicitly select them in the correlation panel.

    if mode == "CSV_MESH":
        if not csv_keys or not model_keys:
            raise ValueError(tr(scn, UI_TEXT['SELECT_AT_LEAST_ONE_DATA_METRIC_AND_ONE_MESH_METRIC_FOR_THE_DATA_MESH_']))
        pairs = _pair_csv_and_model_rows(csv_records, model_records, scn)
        if len(pairs) < 3:
            raise ValueError(tr(scn, UI_TEXT['COULD_NOT_CREATE_AT_LEAST_THREE_DATA_MESH_PAIRS_USE_MATCHING_NAMES_OR_']))
        left_rows = [csv_record["values"] for csv_record, _, _ in pairs]
        right_rows = [model_record["values"] for _, model_record, _ in pairs]
        row_keys, column_keys = csv_keys, model_keys
        matrix, row_keys, column_keys, valid_counts = pearson_cross_correlation(
            left_rows, right_rows, csv_keys=row_keys, model_keys=column_keys, minimum_pairs=3,
        )
        methods = {method for _, _, method in pairs}
        if methods == {"explicit"}:
            pairing_description = tr(scn, UI_TEXT['PAIRED_USING_THE_CONFIGURED_DATA_MESH_ASSOCIATIONS'])
        elif methods == {"name"}:
            pairing_description = tr(scn, UI_TEXT['PAIRED_BY_NAME'])
        elif methods == {"order"}:
            pairing_description = tr(scn, UI_TEXT['PAIRED_BY_ORDER'])
        else:
            pairing_description = tr(scn, UI_TEXT['PAIRED_USING_CONFIGURED_ASSOCIATIONS_AND_AUTOMATIC_MATCHING'])
        pair_count = len(pairs)
        pair_names = [f"{a['name']} ↔ {b['name']}" for a, b, _ in pairs]
        row_labels = [tr(scn, ANALYSIS[key]["label"]) for key in row_keys]
        column_labels = [tr(scn, _MODEL_METRIC_LABELS.get(key, key.replace("_", " "))) for key in column_keys]
        x_axis_label = tr(scn, UI_TEXT['MESH_METRICS'])
        y_axis_label = tr(scn, UI_TEXT['DATA_METRICS'])
        title = tr(scn, UI_TEXT['3D_DATA_MESH_PEARSON_CORRELATION_HEATMAP'])
    elif mode == "CSV_CSV":
        if len(csv_keys) < 2:
            raise ValueError(tr(scn, UI_TEXT['SELECT_AT_LEAST_TWO_DATA_METRICS_FOR_THE_DATA_DATA_GRAPH']))
        rows = [record["values"] for record in csv_records]
        matrix, row_keys, column_keys, valid_counts = pearson_cross_correlation(
            rows, rows, csv_keys=csv_keys, model_keys=csv_keys, minimum_pairs=3,
        )
        pair_count = len(rows)
        pairing_description = tr(scn, UI_TEXT['ACROSS_SELECTED_DATA_FILES'])
        pair_names = [record["name"] for record in csv_records]
        row_labels = [tr(scn, ANALYSIS[key]["label"]) for key in row_keys]
        column_labels = [tr(scn, ANALYSIS[key]["label"]) for key in column_keys]
        x_axis_label = tr(scn, UI_TEXT['DATA_METRICS'])
        y_axis_label = tr(scn, UI_TEXT['DATA_METRICS'])
        title = tr(scn, UI_TEXT['3D_DATA_DATA_PEARSON_CORRELATION_HEATMAP'])
    else:
        if len(model_keys) < 2:
            raise ValueError(tr(scn, UI_TEXT['SELECT_AT_LEAST_TWO_MESH_METRICS_FOR_THE_MESH_MESH_GRAPH']))
        rows = [record["values"] for record in model_records]
        matrix, row_keys, column_keys, valid_counts = pearson_cross_correlation(
            rows, rows, csv_keys=model_keys, model_keys=model_keys, minimum_pairs=3,
        )
        pair_count = len(rows)
        pairing_description = tr(scn, UI_TEXT['ACROSS_ANALYSED_MESH_OBJECTS'])
        pair_names = [record["name"] for record in model_records]
        row_labels = [tr(scn, _MODEL_METRIC_LABELS.get(key, key.replace("_", " "))) for key in row_keys]
        column_labels = [tr(scn, _MODEL_METRIC_LABELS.get(key, key.replace("_", " "))) for key in column_keys]
        x_axis_label = tr(scn, UI_TEXT['MESH_METRICS'])
        y_axis_label = tr(scn, UI_TEXT['MESH_METRICS'])
        title = tr(scn, UI_TEXT['3D_MESH_MESH_PEARSON_CORRELATION_HEATMAP'])

    valid_row_mask = ~np.all(np.isnan(matrix), axis=1)
    valid_column_mask = ~np.all(np.isnan(matrix), axis=0)
    matrix = matrix[valid_row_mask][:, valid_column_mask]
    valid_counts = valid_counts[valid_row_mask][:, valid_column_mask]
    row_labels = [label for label, keep in zip(row_labels, valid_row_mask) if keep]
    column_labels = [label for label, keep in zip(column_labels, valid_column_mask) if keep]

    if matrix.size == 0 or not np.any(np.isfinite(matrix)):
        raise ValueError(tr(scn, UI_TEXT['NO_PEARSON_COEFFICIENTS_COULD_BE_CALCULATED_THE_METRICS_MAY_BE_CONSTAN']))

    return {
        "matrix": matrix,
        "valid_counts": valid_counts,
        "row_labels": row_labels,
        "column_labels": column_labels,
        "pair_count": pair_count,
        "pairing_description": pairing_description,
        "pairs": pair_names,
        "mode": mode,
        "title": title,
        "x_axis_label": x_axis_label,
        "y_axis_label": y_axis_label,
    }

def _visualize_pearson_heatmap(context, report):
    """Create G4 as editable Blender meshes and text, never as an image plane."""
    scn = context.scene
    try:
        heatmap_data = _pearson_heatmap_data(context)
    except Exception as exc:
        report({"ERROR"}, str(exc))
        return {"CANCELLED"}

    target_scene = get_or_create_graph_scene("Pearson_Correlation")
    switch_to_scene(target_scene)
    clear_previous_graphs(target_scene)
    hide_non_graph_objects(target_scene)
    hide_viewport_guides(context)
    configure_graph_viewport_for_readability(context)

    is_spanish = str(getattr(scn, "anali_language", "EN")).upper() == "ES"
    minimum_note = ""

    if heatmap_data["pair_count"] == 3:
        minimum_note = (
            "n=3 es el mínimo exploratorio; usa más pares para conclusiones fiables"
            if is_spanish
            else "n=3 is the exploratory minimum; use more pairs for reliable conclusions"
        )

    try:
        rendered = draw_pearson_heatmap_3d(
            heatmap_data["matrix"],
            heatmap_data["row_labels"],
            heatmap_data["column_labels"],
            pair_count=heatmap_data["pair_count"],
            pairing_description=heatmap_data["pairing_description"],
            axis_scale_x=float(scn.axis_scale_x),
            axis_scale_y=float(scn.axis_scale_y),
            axis_scale_z=float(scn.axis_scale_z),
            title=heatmap_data["title"],
            x_axis_label=heatmap_data["x_axis_label"],
            y_axis_label=heatmap_data["y_axis_label"],
            height_note=(
                "Color = signo · Altura = |r|"
                if is_spanish
                else "Colour = sign · Height = |r|"
            ),
            minimum_note=minimum_note,
        )

        if not rendered:
            raise RuntimeError("The 3D Pearson heatmap could not be created.")
        frame_graph_camera(target_scene, scn)
    except Exception as exc:
        report({"ERROR"}, f"Could not generate 3D Pearson heatmap: {exc}")
        return {"CANCELLED"}

    if heatmap_data["pair_count"] == 3:
        report({"INFO"}, tr(scn, UI_TEXT['G4_GENERATED_WITH_THE_MINIMUM_OF_THREE_PAIRS_TREAT_THE_COEFFICIENTS_AS']))
    else:
        report({"INFO"}, f"3D Pearson heatmap generated with {heatmap_data['pair_count']} paired observations.")
    return {"FINISHED"}

def visualize_graph(context, report):
    """Build the selected graph from the current Blender scene state.

    This controller function keeps the Blender operator thin: the operator only
    delegates here, while graph orchestration lives outside the UI class.
    """
    scn = context.scene

    graph_type = scn.selected_graph
    if graph_type == "G4":
        return _visualize_pearson_heatmap(context, report)

    ok, msg = validate_selection(context)
    if not ok:
        report({'ERROR'}, msg)
        return {'CANCELLED'}

    selected_csvs = selected_csv_graph_sources(scn)
    selected_items = [item for item in scn.analysis_items if item.enabled]
    mesh_metric_keys = _selected_mesh_metric_keys(scn) if graph_type in {"G2", "G3"} else []

    if not selected_csvs and not (graph_type in {"G2", "G3"} and mesh_metric_keys):
        report({'ERROR'}, tr(scn, UI_TEXT['NO_DATA_FILE_SELECTED']))
        return {'CANCELLED'}

    use_log_scale = bool(getattr(scn, "anali_use_log_scale", False))
    use_compact_labels = bool(getattr(scn, "anali_use_compact_labels", False))
    palette_name = getattr(scn, "anali_color_palette", None)

    # INTERACTION COMPARATIVE

    if graph_type == "G1" and len(selected_csvs) > 1:
        key_x = "A1"
        y_metrics = [item.key for item in selected_items if item.key != key_x]
        if not y_metrics:
            report({'ERROR'}, tr(scn, UI_TEXT['INTERACTION_NEEDS_AT_LEAST_ONE_SELECTED_Y_METRIC_X_IS_ALWAYS_TIME']))
            return {'CANCELLED'}

        window_percentage = float(getattr(scn, "anali_g1_window_size", 20.0))
        window_size = 1
        window_start = max(0, int(getattr(scn, "anali_g1_window_start", 0)))
        global_view = bool(getattr(scn, "anali_g1_global_view", True))
        show_mean = bool(getattr(scn, "anali_g1_show_mean", False))
        display_mode = getattr(scn, "anali_g1_display_mode", "BANDS")
        plot_axis_x = 7.0 if display_mode == 'OVERLAY' else float(scn.axis_scale_x)
        if display_mode == 'OVERLAY':
            plot_axis_y = float(scn.axis_scale_y)
            band_height = band_gap = None
        else:
            plot_axis_y, band_height, band_gap = _g1_bands_layout(len(y_metrics), scn.axis_scale_y)
        target_scene = get_or_create_graph_scene("Interaction_Comparative")
        switch_to_scene(target_scene); clear_previous_graphs(target_scene); hide_non_graph_objects(target_scene)

        prepared, window_x_arrays, window_real_x_arrays = [], [], []
        metric_values = {key: [] for key in y_metrics}
        # Recompute the available-row count on every render. Keeping a stale
        # value from a previous CSV selection made the window buttons appear
        # unresponsive or jump beyond the available data.
        scn.anali_g1_last_total_rows = 1
        for csv_idx, csv_path in enumerate(selected_csvs):
            csv_name = csv_source_display_name(scn, csv_path)
            try:
                data, metrics = _cached_csv_analysis(csv_path, getattr(context.scene, "max_reasonable_speed", DEFAULT_MAX_REASONABLE_SPEED))
                metrics = _graph_metrics_with_local_view_units(metrics, data)
                x_base = _g1_series_array(metrics.get(key_x, []))
                window_size = _g1_window_rows(x_base.size, window_percentage)
                scn.anali_g1_last_total_rows = max(int(getattr(scn, "anali_g1_last_total_rows", 1)), int(x_base.size or 1))
                if global_view:
                    display_x_base = _g1_global_sample_progress_x(x_base)
                    real_x_window = np.asarray(x_base, dtype=float)
                else:
                    # Window curves use row positions for spacing, while tick labels
                    # preserve the real session-duration values from visible rows.
                    # Use coordinates local to the active window. Keeping the
                    # absolute row indices made later windows occupy only the
                    # right side of the graph after X normalization.
                    display_x_base = np.arange(x_base.size, dtype=float) - float(window_start)
                    real_x_window = np.asarray(x_base[window_start:window_start + window_size], dtype=float)
                x_window = np.asarray(display_x_base if global_view else display_x_base[window_start:window_start + window_size], dtype=float)
                x_window = x_window[np.isfinite(x_window)]
                real_x_window = real_x_window[np.isfinite(real_x_window)]
                if x_window.size:
                    window_x_arrays.append(x_window)
                if real_x_window.size:
                    window_real_x_arrays.append(real_x_window)
            except Exception as exc:
                print(f"[interaction comparative] {csv_path}: {exc}"); continue
            for metric_idx, key_y in enumerate(y_metrics):
                segments = _g1_window_segments(display_x_base, _g1_work_mode_values(key_y, _g1_series_array(metrics.get(key_y, []))), window_start, window_size, global_view)
                segments = _g1_spread_segments_uniformly(segments)
                if not segments:
                    continue
                y_concat = np.concatenate([seg[1] for seg in segments])
                draw_segments = _downsample_segments_for_display(segments)
                metric_values[key_y].append(y_concat)
                prepared.append({
                    "csv_name": csv_name,
                    "csv_index": csv_idx,
                    "metric_key": key_y,
                    "metric_index": metric_idx,
                    "segments": draw_segments,
                    "full_segments": segments,
                    "x_all": np.concatenate([seg[0] for seg in segments]),
                    "y_all": y_concat,
                })

        total_rows = max(1, int(getattr(scn, "anali_g1_last_total_rows", 1)))
        effective_window = _g1_window_rows(total_rows, window_percentage)
        max_start = max(0, total_rows - effective_window)
        if not global_view and window_start > max_start:
            # Clamp stale page positions and redraw from the final valid window.
            window_start = max_start
            scn.anali_g1_window_start = max_start
            return visualize_graph(context, report)

        if not prepared:
            report({'ERROR'}, tr(scn, UI_TEXT['INTERACTION_COMPARISON_COULD_NOT_GENERATE_DATA_FOR_THIS_WINDOW']))
            return {'CANCELLED'}
        plotted_x_arrays = [item["x_all"] for item in prepared if np.asarray(item["x_all"]).size]
        x_range = (0.0, 100.0)
        if global_view:
            x_tick_data = None
        else:
            x_tick_data = _g1_window_tick_data(x_range, window_real_x_arrays[0] if window_real_x_arrays else [])
        ranges = {
            key: _g1_display_range(
                key,
                [_signed_log10_1p(arr) for arr in arrays] if _g1_metric_uses_log(key, use_log_scale) else arrays,
                global_view,
            )
            for key, arrays in metric_values.items()
        }
        bands=[]
        if display_mode == 'OVERLAY':
            overlay_bottom = plot_axis_y * 0.06
            overlay_top = plot_axis_y * 0.96
            for metric_idx, key in enumerate(y_metrics):
                vals=np.concatenate(metric_values[key]) if metric_values[key] else np.asarray([])
                bands.append({"label": _g1_label_with_unit(scn, key), "bottom": overlay_bottom, "top": overlay_top, "range": ranges[key], "mean": float(np.mean(_signed_log10_1p(vals))) if vals.size and _g1_metric_uses_log(key, use_log_scale) else (float(np.mean(vals)) if vals.size else None), "raw_mean": float(np.mean(vals)) if vals.size else None, "log_scale": _g1_metric_uses_log(key, use_log_scale), "constant": bool(vals.size and float(np.max(vals) - np.min(vals)) <= 1e-12), "semantic": _g1_semantic_info(scn, key, [item.get('y_all', item.get('y', [])) for item in prepared if item['metric_key'] == key])})
        else:
            for metric_idx, key in enumerate(y_metrics):
                visual_index = len(y_metrics) - 1 - metric_idx
                outer_bottom = visual_index * (band_height + band_gap)
                outer_top = outer_bottom + band_height
                bottom, top = _g1_inner_band_bounds(outer_bottom, outer_top)
                vals=np.concatenate(metric_values[key]) if metric_values[key] else np.asarray([])
                bands.append({"label": _g1_label_with_unit(scn, key), "bottom": bottom, "top": top, "outer_bottom": outer_bottom, "outer_top": outer_top, "range": ranges[key], "mean": float(np.mean(_signed_log10_1p(vals))) if vals.size and _g1_metric_uses_log(key, use_log_scale) else (float(np.mean(vals)) if vals.size else None), "raw_mean": float(np.mean(vals)) if vals.size else None, "log_scale": _g1_metric_uses_log(key, use_log_scale), "constant": bool(vals.size and float(np.max(vals) - np.min(vals)) <= 1e-12), "semantic": _g1_semantic_info(scn, key, [item.get('y_all', item.get('y', [])) for item in prepared if item['metric_key'] == key])})
        for item in prepared:
            band=bands[item['metric_index']]
            z_offset = item['csv_index'] * 0.08 + (item['metric_index'] * 0.006 if display_mode == 'OVERLAY' else 0.0)
            for seg_idx, (seg_x, seg_y) in enumerate(item['segments']):
                visual_y = _g1_visual_values(item['metric_key'], seg_y, (_signed_pow10_m1(band['range']) if band.get('log_scale') else band['range']), global_view)
                if band.get('log_scale'):
                    visual_y = _signed_log10_1p(visual_y)
                display_y = _g1_band_y(visual_y, band['range'], band['bottom'], band['top'])
                line_color = (
                    csv_color_by_index(item['metric_index'], palette_name)
                    if display_mode == 'OVERLAY'
                    else csv_color_by_index(item['csv_index'], palette_name)
                )
                create_interaction_graph_3d(seg_x, display_y, z_offset, plot_axis_x, plot_axis_y,
                    csv_name=item['csv_name'], metric_name=f"{key_x}_{item['metric_key']}_{seg_idx}", color=line_color,
                    x_range=x_range, y_range=(0.0, plot_axis_y))
            _draw_g1_gap_markers(scn, item.get('full_segments', item['segments']), band, x_range, z_offset, f"G1Gap_{item['csv_index']}_{item['metric_index']}")
        csv_spans = []
        for csv_idx in sorted({item['csv_index'] for item in prepared}):
            xs = np.concatenate([item['x_all'] for item in prepared if item['csv_index'] == csv_idx])
            if xs.size:
                csv_spans.append((float(np.min(xs)), float(np.max(xs))))
        x_axis_label = tr(scn, UI_TEXT['SESSION_PROGRESS']) if global_view else tr(scn, UI_TEXT['SESSION_DURATION_H'])
        if display_mode == 'OVERLAY':
            _draw_g1_overlay_axes(scn, x_range, bands, show_mean=show_mean, csv_spans=csv_spans, x_label=x_axis_label, x_tick_data=x_tick_data, axis_scale_x=plot_axis_x, axis_scale_y=plot_axis_y)
        else:
            _draw_g1_axes_and_bands(scn, x_range, bands, show_mean=show_mean, csv_spans=csv_spans, x_label=x_axis_label, x_tick_data=x_tick_data, axis_scale_x=plot_axis_x, axis_scale_y=plot_axis_y)
        shown = max((len(arr) for arr in (window_x_arrays or plotted_x_arrays)), default=0)
        create_text_label(tr(scn, UI_TEXT['TIMELINE']), (plot_axis_x * 0.5, plot_axis_y + 0.68, 0.12), 0.40, "GraphTitle_G1", align_x="CENTER")
        subtitle = f"{tr(scn, UI_TEXT['ALL_DATA'])} · {shown} {tr(scn, UI_TEXT['SAMPLES'])}" if global_view else f"Rows {window_start + 1}–{window_start + shown} · {shown} {tr(scn, UI_TEXT['SAMPLES'])}"
        create_text_label(subtitle, (plot_axis_x * 0.5, plot_axis_y + 0.38, 0.12), 0.22, "GraphSubtitle_G1", align_x="CENTER")
        _g1_reduce_viewport_noise(context)
        legend_items = (
            [{"name": _g1_label_with_unit(scn, key), "color": csv_color_by_index(i, palette_name)} for i, key in enumerate(y_metrics)]
            if display_mode == 'OVERLAY'
            else [{"name": _short_source_name(csv_source_display_name(scn, path), max_len=30), "color": csv_color_by_index(i, palette_name)} for i, path in enumerate(selected_csvs)]
        )
        draw_csv_color_legend(csv_items=legend_items, axis_scale_x=plot_axis_x, axis_scale_y=plot_axis_y, z_pos=0.15, title=tr(scn, UI_TEXT['METRICS_2']) if display_mode == 'OVERLAY' else tr(scn, UI_TEXT['DATA']))
        frame_graph_camera(target_scene, scn)
        return {'FINISHED'}

    # FOREST COMPARATIVE

    if graph_type == "G2":
        csv_metric_keys = [item.key for item in selected_items]
        mesh_records = _mesh_metric_records(scn)

        if not csv_metric_keys and not mesh_metric_keys:
            report({'ERROR'}, tr(scn, UI_TEXT['FOREST_PLOT_NEEDS_AT_LEAST_ONE_SELECTED_METRIC']))
            return {'CANCELLED'}

        target_scene = get_or_create_graph_scene("Forest_ZScore")
        switch_to_scene(target_scene)
        clear_previous_graphs(target_scene)
        hide_non_graph_objects(target_scene)

        computed_metrics = []
        for csv_path in selected_csvs:
            csv_name = csv_source_display_name(scn, csv_path)
            try:
                data, metrics = _cached_csv_analysis(
                    csv_path,
                    getattr(context.scene, "max_reasonable_speed", DEFAULT_MAX_REASONABLE_SPEED),
                )
                metrics = _graph_metrics_with_local_view_units(metrics, data)
                computed_metrics.append((csv_name, metrics))
            except Exception as exc:
                print(f"[forest plot z-score] {csv_path}: {exc}")

        groups = []
        if csv_metric_keys and len(computed_metrics) >= 2:
            for metric_key in csv_metric_keys:
                metric_label = ANALYSIS.get(metric_key, {}).get("label", metric_key)
                reference = forest_zscore_reference(metric_key, [metrics for _csv_name, metrics in computed_metrics], use_log_scale=use_log_scale)
                if reference is None:
                    continue
                rows = []
                for csv_idx, (csv_name, metrics) in enumerate(computed_metrics):
                    try:
                        row = forest_zscore_row_stats(
                            metric_key, metrics, csv_name,
                            reference_mean=reference["mean"],
                            reference_std=reference["std"],
                            use_log_scale=use_log_scale,
                        )
                    except Exception as exc:
                        print(f"[forest plot z-score row] {csv_name} / {metric_key}: {exc}")
                        row = None
                    if row is not None:
                        row["color_index"] = csv_idx
                        row["display_name"] = _short_source_name(csv_name, max_len=24)
                        row["source_full_name"] = _short_source_name(csv_name, max_len=42)
                        row["raw_display"] = _forest_real_display(scn, metric_key, row, metrics)
                        if metric_key == "A14":
                            row["work_mode_summary"] = _format_work_mode_summary(metrics, get_language(scn))
                        rows.append(row)
                if len(rows) >= 2:
                    groups.append({
                        "label": tr(scn, metric_label),
                        "metric_key": metric_key,
                        "unit": _g1_metric_unit(scn, metric_key),
                        "rows": rows,
                        "reference_mean": reference["mean"],
                        "reference_std": reference["std"],
                        "reference_n": reference["n_total"],
                    })

        # Mesh metrics are scalar observations. They do not have a sampling
        # standard error or confidence interval, so they must be rendered as
        # point estimates rather than being filtered by the CSV-only CI rules.
        for metric_key in mesh_metric_keys:
            observations = []
            for record in mesh_records:
                value = _finite_mesh_value(record, metric_key)
                if value is not None:
                    observations.append((record["name"], value))
            if not observations:
                continue

            values = np.asarray([value for _name, value in observations], dtype=float)
            z_values = _signed_log10_1p(values) if use_log_scale else values
            reference_mean = float(np.mean(z_values))
            reference_std = float(np.std(z_values, ddof=1)) if z_values.size > 1 else 0.0
            has_variance = np.isfinite(reference_std) and reference_std > 1e-12

            rows = []
            color_offset = len(computed_metrics)
            for object_idx, (object_name, value) in enumerate(observations):
                transformed_value = float(_signed_log10_1p([value])[0]) if use_log_scale else float(value)
                z_score = (transformed_value - reference_mean) / reference_std if has_variance else 0.0
                rows.append({
                    "name": object_name,
                    "label": f"{object_name} · {_g1_format_value(value, abs(value))}",
                    "csv_name": f"{object_name} · {_g1_format_value(value, abs(value))}",
                    "mean": float(z_score),
                    "low": float(z_score),
                    "high": float(z_score),
                    "ci_low": float(z_score),
                    "ci_high": float(z_score),
                    "se": 0.0,
                    "n": 1,
                    "n_eff": 1.0,
                    "scalar_observation": True,
                    "raw_value": float(value),
                    "color_index": color_offset + object_idx,
                    "display_name": _short_source_name(object_name, max_len=24),
                    "source_full_name": _short_source_name(object_name, max_len=42),
                })
            groups.append({
                "label": tr(scn, _MODEL_METRIC_LABELS.get(metric_key, metric_key.replace("_", " "))),
                "metric_key": metric_key,
                "unit": _mesh_metric_unit(scn, metric_key),
                "rows": rows,
                "reference_mean": reference_mean,
                "reference_std": reference_std if has_variance else 0.0,
                "reference_n": len(observations),
                "scalar_group": True,
            })

        if not groups:
            report({'ERROR'}, tr(scn, UI_TEXT['FOREST_PLOT_NEEDS_AT_LEAST_ONE_VALID_DATA_OR_MESH_METRIC']))
            return {'CANCELLED'}

        total_rows = sum(len(group["rows"]) + 1 for group in groups)
        draw_multi_metric_forest_plot_3d(
            groups,
            axis_scale_x=scn.axis_scale_x,
            axis_scale_y=max(scn.axis_scale_y, total_rows * 0.48),
            z_pos=0.0,
            scale_label=(f"{tr(scn, UI_TEXT['Z_SCORE'])} · log" if use_log_scale else tr(scn, UI_TEXT['Z_SCORE'])),
            palette_name=palette_name,
        )
        _g1_reduce_viewport_noise(context)
        frame_graph_camera(target_scene, scn)
        report({'INFO'}, f"{tr(scn, UI_TEXT['FOREST_PLOT_GENERATED'])} · {len(groups)} {tr(scn, UI_TEXT['METRICS'])}")
        return {'FINISHED'}

    # RADAR COMPARATIVE

    if graph_type == "G3":
        selected_csv_metric_keys = [item.key for item in selected_items]
        mesh_records = _mesh_metric_records(scn)
        total_selected_radar_metrics = len(selected_csv_metric_keys) + len(mesh_metric_keys)
        if total_selected_radar_metrics < 3:
            report({'ERROR'}, tr(scn, UI_TEXT['RADAR_PLOT_NEEDS_AT_LEAST_THREE_SELECTED_DATA_OR_MODEL_METRICS']))
            return {'CANCELLED'}

        csv_records = []
        for idx, csv_path in enumerate(selected_csvs):
            try:
                data, metrics = _cached_csv_analysis(
                    csv_path,
                    getattr(context.scene, "max_reasonable_speed", DEFAULT_MAX_REASONABLE_SPEED),
                )
                metrics = _graph_metrics_with_local_view_units(metrics, data)
                csv_records.append({
                    "idx": idx,
                    "name": csv_source_display_name(scn, csv_path),
                    "path": os.path.abspath(csv_path),
                    "pair_key": _correlation_pair_key(csv_path),
                    "metrics": metrics,
                })
            except Exception as exc:
                print(f"[radar comparative] {csv_path}: {exc}")

        def _build_one_radar(csv_metric_keys, local_mesh_keys, scene_suffix="All", title_suffix=""):
            axis_keys = [("csv", key) for key in csv_metric_keys] + [("mesh", key) for key in local_mesh_keys]
            if not axis_keys:
                return False
            compact_radar = len(axis_keys) >= 8
            labels = [
                _radar_data_label(scn, key, compact=compact_radar) if family == "csv"
                else f"{tr(scn, _MODEL_METRIC_LABELS.get(key, key.replace('_', ' ')))} · {_mesh_metric_unit(scn, key)}".rstrip(" ·")
                for family, key in axis_keys
            ]
            raw_series = []

            if csv_metric_keys and local_mesh_keys:
                pairable_csv = [dict(record, values={}) for record in csv_records]
                pairs = _pair_csv_and_model_rows(pairable_csv, mesh_records, scn)
                for series_idx, (csv_record, mesh_record, _method) in enumerate(pairs):
                    values = []
                    valid = True
                    for key in csv_metric_keys:
                        value, _unit = radar_summary_value(key, csv_record["metrics"])
                        if value is None or not np.isfinite(value):
                            valid = False; break
                        values.append(float(value))
                    if valid:
                        for key in local_mesh_keys:
                            value = _finite_mesh_value(mesh_record, key)
                            if value is None:
                                valid = False; break
                            values.append(value)
                    if valid and values:
                        raw_series.append({
                            "idx": series_idx,
                            "name": f"{_short_source_name(csv_record['name'], 24)} ↔ {_short_source_name(mesh_record['name'], 24)}",
                            "source_full_name": f"{_short_source_name(csv_record['name'], 42)} ↔ {_short_source_name(mesh_record['name'], 42)}",
                            "values": np.asarray(values, dtype=float),
                            "metrics": csv_record.get("metrics"),
                        })
            elif csv_metric_keys:
                for record in csv_records:
                    values = []
                    for key in csv_metric_keys:
                        value, _unit = radar_summary_value(key, record["metrics"])
                        if value is None or not np.isfinite(value):
                            values = []; break
                        values.append(float(value))
                    if values:
                        raw_series.append({"idx": record["idx"], "name": _short_source_name(record["name"], 30), "source_full_name": _short_source_name(record["name"], 60), "values": np.asarray(values, dtype=float), "metrics": record.get("metrics")})
            else:
                for idx, record in enumerate(mesh_records):
                    values = [_finite_mesh_value(record, key) for key in local_mesh_keys]
                    if values and all(value is not None for value in values):
                        raw_series.append({"idx": idx, "name": _short_source_name(record["name"], 30), "source_full_name": _short_source_name(record["name"], 60), "values": np.asarray(values, dtype=float), "metrics": None})

            if len(raw_series) < 2:
                return False

            target_scene = get_or_create_graph_scene(f"Radar_{scene_suffix}")
            switch_to_scene(target_scene)
            clear_previous_graphs(target_scene)
            hide_non_graph_objects(target_scene)

            matrix = np.vstack([item["values"] for item in raw_series])
            display_matrix = matrix.copy()
            transformed_matrix = _signed_log10_1p(matrix) if use_log_scale else matrix.copy()
            margin = min(max(float(getattr(scn, "anali_radar_margin", 0.10)), 0.0), 0.20)
            usable_radius = max(1.0 - 2.0 * margin, 0.0)
            normalized = np.zeros_like(transformed_matrix, dtype=float)
            real_ranges = []
            for col_idx in range(transformed_matrix.shape[1]):
                column = np.asarray(transformed_matrix[:, col_idx], dtype=float)
                real_column = np.asarray(display_matrix[:, col_idx], dtype=float)
                finite_column = column[np.isfinite(column)]
                finite_real = real_column[np.isfinite(real_column)]
                minimum = float(np.min(finite_column)) if finite_column.size else 0.0
                maximum = float(np.max(finite_column)) if finite_column.size else 1.0
                real_min = float(np.min(finite_real)) if finite_real.size else 0.0
                real_max = float(np.max(finite_real)) if finite_real.size else 1.0
                real_ranges.append((real_min, real_max))
                span = maximum - minimum
                column_normalized = np.full(column.shape, 0.5, dtype=float) if abs(span) <= 1e-12 else np.clip((column - minimum) / span, 0.0, 1.0)
                normalized[:, col_idx] = margin + column_normalized * usable_radius
            normalized = np.clip(normalized, margin, 1.0 - margin)

            display_labels = []
            for idx, label in enumerate(labels):
                family, key = axis_keys[idx]
                lo, hi = real_ranges[idx]
                if family == "csv" and key == "A14":
                    display_labels.append(label)
                else:
                    display_labels.append(f"{label}\n{_g1_format_value(lo, abs(hi-lo))}–{_g1_format_value(hi, abs(hi-lo))}")

            axis_count = max(1, len(axis_keys))
            radar_scale_x = max(float(scn.axis_scale_x), 6.5 + max(0, axis_count - 8) * 0.38)
            radar_scale_y = max(float(scn.axis_scale_y), 6.5 + max(0, axis_count - 8) * 0.38)

            radar_series = []
            for row_idx, item in enumerate(raw_series):
                color = csv_color_by_index(item["idx"], palette_name)
                draw_radar_graph_3d_filled(
                    normalized[row_idx].tolist(), axis_scale_x=radar_scale_x, axis_scale_y=radar_scale_y,
                    z_pos=row_idx * 0.03, labels=display_labels if row_idx == 0 else [], color=color,
                    csv_name=f"radar_{row_idx}_{sanitize_name(item['name'])}_{sanitize_name(scene_suffix)}", values_are_normalized=True,
                    radar_margin=margin, draw_margin_guides=(row_idx == 0), margin_labels=None,
                )
                radar_series.append({"name": item.get("source_full_name") or item["name"], "color": color})

            draw_csv_color_legend(
                csv_items=radar_series, axis_scale_x=radar_scale_x, axis_scale_y=radar_scale_y,
                z_pos=0.15, title=tr(scn, UI_TEXT['OBSERVATIONS']),
            )
            title = tr(scn, UI_TEXT['COMPARATIVE_RADAR'])
            if title_suffix:
                title += f" · {title_suffix}"
            create_text_label(title, (radar_scale_x * 0.5, radar_scale_y + 1.35, 0.12), 0.40, f"GraphTitle_G3_{sanitize_name(scene_suffix)}", align_x="CENTER")
            frame_graph_camera(target_scene, scn)
            return True

        # The radar always represents the metrics explicitly selected by the user.
        # There are no thematic/grouping categories.
        generated = int(_build_one_radar(selected_csv_metric_keys, mesh_metric_keys, scene_suffix="Comparative"))

        if generated <= 0:
            report({'ERROR'}, tr(scn, UI_TEXT['RADAR_PLOT_NEEDS_AT_LEAST_TWO_VALID_DATA_MESH_OR_PAIRED_OBSERVATIONS']))
            return {'CANCELLED'}
        report({'INFO'}, f"{tr(scn, UI_TEXT['COMPARATIVE_RADAR_GENERATED'])} · {generated}")
        return {'FINISHED'}

    # REST OF GRAPHS

    for csv_idx, csv_path in enumerate(selected_csvs):

        csv_name = csv_source_display_name(scn, csv_path)

        target_scene = get_or_create_graph_scene(csv_name)

        switch_to_scene(target_scene)
        clear_previous_graphs(target_scene)
        hide_non_graph_objects(target_scene)

        data, metrics = _cached_csv_analysis(csv_path, getattr(context.scene, "max_reasonable_speed", DEFAULT_MAX_REASONABLE_SPEED))
        metrics = _graph_metrics_with_local_view_units(metrics, data)

        color = csv_color_by_index(csv_idx, palette_name)

        # INTERACTION PARA UN SOLO CSV
        if graph_type == "G1":
            key_x = "A1"
            y_metrics = [item.key for item in selected_items if item.key != key_x]
            if not y_metrics:
                report({'ERROR'}, tr(scn, UI_TEXT['INTERACTION_NEEDS_AT_LEAST_ONE_SELECTED_Y_METRIC_X_IS_ALWAYS_TIME']))
                return {'CANCELLED'}
            window_percentage=float(getattr(scn, "anali_g1_window_size", 20.0)); window_size=1
            window_start=max(0, int(getattr(scn, "anali_g1_window_start", 0)))
            scn.anali_g1_last_total_rows = 1
            global_view=bool(getattr(scn, "anali_g1_global_view", True))
            show_mean=bool(getattr(scn, "anali_g1_show_mean", False))
            display_mode=getattr(scn, "anali_g1_display_mode", "BANDS")
            plot_axis_x=7.0 if display_mode == 'OVERLAY' else float(scn.axis_scale_x)
            if display_mode == 'OVERLAY':
                plot_axis_y=float(scn.axis_scale_y); band_height=band_gap=None
            else:
                plot_axis_y,band_height,band_gap=_g1_bands_layout(len(y_metrics),scn.axis_scale_y)
            x_base=_g1_series_array(metrics.get(key_x, [])); prepared=[]; metric_values={}
            window_size=_g1_window_rows(x_base.size, window_percentage)
            scn.anali_g1_last_total_rows=max(1, int(x_base.size or 1))
            if global_view:
                display_x_base=_g1_global_sample_progress_x(x_base)
                real_x_window=np.asarray(x_base,dtype=float)
            else:
                # Plot visible rows at equal horizontal distances and keep their
                # real time values only as X-axis labels.
                display_x_base=np.arange(x_base.size,dtype=float)-float(window_start)
                real_x_window=np.asarray(x_base[window_start:window_start+window_size],dtype=float)
            x_window=np.asarray(display_x_base if global_view else display_x_base[window_start:window_start+window_size],dtype=float)
            x_window=x_window[np.isfinite(x_window)]
            real_x_window=real_x_window[np.isfinite(real_x_window)]
            for metric_idx,key_y in enumerate(y_metrics):
                segments=_g1_window_segments(display_x_base, _g1_work_mode_values(key_y, _g1_series_array(metrics.get(key_y, []))), window_start, window_size, global_view)
                segments=_g1_spread_segments_uniformly(segments)
                if not segments: continue
                y_concat=np.concatenate([seg[1] for seg in segments])
                draw_segments=_downsample_segments_for_display(segments)
                metric_values[key_y]=[y_concat]
                prepared.append({"metric_key":key_y,"metric_index":metric_idx,"segments":draw_segments,"full_segments":segments,"x_all":np.concatenate([seg[0] for seg in segments]),"y_all":y_concat})
            if not prepared:
                report({'ERROR'}, tr(scn, UI_TEXT['INTERACTION_COMPARISON_COULD_NOT_GENERATE_DATA_FOR_THIS_WINDOW'])); return {'CANCELLED'}
            plotted_x_arrays=[item["x_all"] for item in prepared if np.asarray(item["x_all"]).size]
            x_range=(0.0,100.0)
            if global_view:
                x_tick_data=None
            else:
                x_tick_data=_g1_window_tick_data(x_range, real_x_window)
            ranges={key:_g1_display_range(key,[_signed_log10_1p(arr) for arr in arrays] if _g1_metric_uses_log(key,use_log_scale) else arrays,global_view) for key,arrays in metric_values.items()}
            bands=[]
            if display_mode == 'OVERLAY':
                overlay_bottom=plot_axis_y*0.06; overlay_top=plot_axis_y*0.96
                for idx,key in enumerate(y_metrics):
                    vals=metric_values.get(key,[np.asarray([])])[0]
                    bands.append({"label":_g1_label_with_unit(scn, key),"bottom":overlay_bottom,"top":overlay_top,"range":ranges.get(key,(0,1)),"mean":float(np.mean(_signed_log10_1p(vals))) if vals.size and _g1_metric_uses_log(key,use_log_scale) else (float(np.mean(vals)) if vals.size else None),"raw_mean":float(np.mean(vals)) if vals.size else None,"log_scale":_g1_metric_uses_log(key,use_log_scale),"constant":bool(vals.size and float(np.max(vals)-np.min(vals)) <= 1e-12),"semantic":_g1_semantic_info(scn,key,[item.get('y_all', item.get('y', [])) for item in prepared if item['metric_key']==key])})
            else:
                for idx,key in enumerate(y_metrics):
                    visual_index=len(y_metrics)-1-idx
                    outer_bottom=visual_index*(band_height+band_gap); outer_top=outer_bottom+band_height
                    bottom,top=_g1_inner_band_bounds(outer_bottom,outer_top)
                    vals=metric_values.get(key,[np.asarray([])])[0]
                    bands.append({"label":_g1_label_with_unit(scn, key),"bottom":bottom,"top":top,"outer_bottom":outer_bottom,"outer_top":outer_top,"range":ranges.get(key,(0,1)),"mean":float(np.mean(_signed_log10_1p(vals))) if vals.size and _g1_metric_uses_log(key,use_log_scale) else (float(np.mean(vals)) if vals.size else None),"raw_mean":float(np.mean(vals)) if vals.size else None,"log_scale":_g1_metric_uses_log(key,use_log_scale),"constant":bool(vals.size and float(np.max(vals)-np.min(vals)) <= 1e-12),"semantic":_g1_semantic_info(scn,key,[item.get('y_all', item.get('y', [])) for item in prepared if item['metric_key']==key])})
            for item in prepared:
                band=bands[item['metric_index']]
                z_offset=item['metric_index']*0.012 if display_mode == 'OVERLAY' else item['metric_index']*0.02
                for seg_idx,(seg_x,seg_y) in enumerate(item['segments']):
                    visual_y=_g1_visual_values(item['metric_key'],seg_y,tuple(_signed_pow10_m1(band['range'])) if band.get('log_scale') else band['range'],global_view)
                    if band.get('log_scale'):
                        visual_y=_signed_log10_1p(visual_y)
                    display_y=_g1_band_y(visual_y,band['range'],band['bottom'],band['top'])
                    line_color=csv_color_by_index(item['metric_index'], palette_name) if display_mode == 'OVERLAY' else color
                    create_interaction_graph_3d(seg_x,display_y,z_offset,plot_axis_x,plot_axis_y,csv_name=csv_name,metric_name=f"{key_x}_{item['metric_key']}_{seg_idx}",color=line_color,x_range=x_range,y_range=(0.0,plot_axis_y))
                _draw_g1_gap_markers(scn, item.get('full_segments', item['segments']), band, x_range, z_offset, f"G1Gap_single_{item['metric_index']}")
            x_axis_label=tr(scn, UI_TEXT['SESSION_PROGRESS']) if global_view else tr(scn, UI_TEXT['SESSION_DURATION_H'])
            if display_mode == 'OVERLAY':
                _draw_g1_overlay_axes(scn,x_range,bands,show_mean=show_mean,csv_spans=None,x_label=x_axis_label,x_tick_data=x_tick_data,axis_scale_x=plot_axis_x,axis_scale_y=plot_axis_y)
            else:
                _draw_g1_axes_and_bands(scn,x_range,bands,show_mean=show_mean,csv_spans=None,x_label=x_axis_label,x_tick_data=x_tick_data,axis_scale_x=plot_axis_x,axis_scale_y=plot_axis_y)
            shown=max(([len(x_window)] if x_window.size else []) + [len(item['x_all']) for item in prepared])
            create_text_label(tr(scn, UI_TEXT['TIMELINE']),(plot_axis_x*0.5,plot_axis_y+0.68,0.12),0.40,"GraphTitle_G1",align_x="CENTER")
            subtitle=f"{tr(scn, UI_TEXT['ALL_DATA'])} · {shown} {tr(scn, UI_TEXT['SAMPLES'])}" if global_view else f"Rows {window_start+1}–{window_start+shown} · {shown} {tr(scn, UI_TEXT['SAMPLES'])}"
            create_text_label(subtitle,(plot_axis_x*0.5,plot_axis_y+0.38,0.12),0.22,"GraphSubtitle_G1",align_x="CENTER")
            _g1_reduce_viewport_noise(context)
            legend_items=([{"name":_g1_label_with_unit(scn,key),"color":csv_color_by_index(i,palette_name)} for i,key in enumerate(y_metrics)] if display_mode == 'OVERLAY' else [{"name":csv_name,"color":color}])
            draw_csv_color_legend(csv_items=legend_items,axis_scale_x=plot_axis_x,axis_scale_y=plot_axis_y,z_pos=0.15,title=tr(scn, UI_TEXT['METRICS_2']) if display_mode == 'OVERLAY' else tr(scn, UI_TEXT['DATA']))
            frame_graph_camera(target_scene,scn)
            continue

        # STANDARD GRAPHS

        offset = 0.0

        for metric_key in [item.key for item in selected_items]:

            values = series_to_array(
                metrics.get(metric_key, [])
            )

            if values.size == 0:
                continue

            graph_data = None

            # SINGLE FOREST

            if graph_type == "G2":

                plot_values = _signed_log10_1p(values) if use_log_scale else values
                draw_forest_plot_3d(
                    plot_values.tolist(),
                    csv_name=csv_name,
                    metric_name=metric_key,
                    axis_scale_x=scn.axis_scale_x,
                    axis_scale_y=scn.axis_scale_y,
                    z_pos=offset
                )

                v_min = float(np.min(plot_values)) if plot_values.size else 0.0
                v_max = float(np.max(plot_values)) if plot_values.size else 1.0
                # En forest el eje debe incluir 0 para no exagerar diferencias visuales.
                v_min = min(0.0, v_min)
                v_max = max(0.0, v_max)
                graph_data = {
                    "x_range": (v_min, v_max),
                    "y_range": (0.0, 1.0),
                    "x_ticks": [v_min] if v_min == v_max else list(np.linspace(v_min, v_max, 5)),
                    "y_ticks": [],
                }

            draw_axes_for_graph(
                scn,
                [
                    ANALYSIS[metric_key]["label"],
                    "Value",
                    "Z"
                ],
                graph_data
            )

            offset += max(1.5, scn.axis_scale_z)

        frame_graph_camera(target_scene, scn)

    report({'INFO'}, tr(scn, UI_TEXT['GRAPHS_GENERATED']))

    return {'FINISHED'}

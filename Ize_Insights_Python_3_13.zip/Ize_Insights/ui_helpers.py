# Herramientas para la monitorización y análisis de procesos de modelado 3D en Blender
# Copyright (C) 2026 María Molina Goyena
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# at your option any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.

from .texts import UI_TEXT
import os
import re
import csv
import json
import tempfile
import hashlib
import bpy
import numpy as np
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from mathutils import Vector

from .utils import (
    detect_csvs,
    read_csv,
    count_uv_islands,
    calculate_topology_similarity,
    calculate_similarity,
    calculate_uv_texel_density,
    calculate_normal_percentage,
    calculate_angle_median,
    object_has_applied_transforms,
    object_is_at_origin,
    calculate_model_metrics,
)
from .constants import DEFAULT_BREAK_SPEED, DEFAULT_MAX_REASONABLE_SPEED
from .analytics import ANALYSIS, compute_metrics_for_csv, series_to_array, clamp_outliers, sanitize_name, _row_time, _row_object_local_size, _csv_float, _csv_has_value, _signed_change, _csv_session_key
from .graphs import (
    clear_previous_graphs,
    clear_axes_objects,
    get_color_for_csv,
    csv_color_by_index,
    metric_color_for_csv,
    draw_axes1,
    create_plane_with_image_memory,
    draw_correlation_graph_fast,
    create_scatter_points_fast,
    create_time_graph,
    draw_forest_plot_3d,
    draw_multi_csv_forest_plot_3d,
    draw_surface_graph,
    draw_multi_csv_surface_graph,
    create_interaction_graph_3d,
    draw_radar_graph_3d_filled,
    draw_csv_color_legend,
)
from .ui_graph_rendering import (
    _figure_to_blender_image,
    create_matplotlib_graph,
    create_comparative_interaction_matplotlib,
)
GRAPH_TYPES = {
    "G1": {"label": UI_TEXT['TIMELINE'], "roles": {"Y": 1}, "allow_mix": True, "compatible_typologies": ["Temporal activity", "View & navigation", "Model evolution", "Tools & actions"]},
    "G2": {"label": UI_TEXT['FOREST_PLOT'], "roles": {"Y": 1}, "allow_mix": False, "compatible_typologies": ["Temporal activity", "View & navigation", "Model evolution", "Tools & actions"], "requires_multi_csv": True},
    "G3": {"label": UI_TEXT['RADAR_PLOT'], "roles": {"Y": 3}, "allow_mix": False, "compatible_typologies": ["Temporal activity", "View & navigation", "Model evolution", "Tools & actions"], "requires_multi_csv": True},
    "G4": {"label": UI_TEXT['CORRELATION_HEATMAP'], "roles": {}, "allow_mix": False, "compatible_typologies": ["Temporal activity", "View & navigation", "Model evolution", "Tools & actions"], "requires_multi_csv": True},
}

# Helpers

def _clean_vals(values):
    if values is None:
        return []
    out = []
    for v in values:
        try:
            out.append(float(v))
        except (ValueError, TypeError) as exc:
            print(f"[_clean_vals] Valor descartado: {exc}")
    return out


def _safe_mean(values):
    vals = _clean_vals(values)
    return float(np.mean(vals)) if vals else 0.0


def _safe_std(values):
    vals = _clean_vals(values)
    return float(np.std(vals)) if vals else 0.0


def _safe_min(values):
    vals = _clean_vals(values)
    return float(np.min(vals)) if vals else 0.0


def _safe_max(values):
    vals = _clean_vals(values)
    return float(np.max(vals)) if vals else 0.0


def _safe_sum(values):
    vals = _clean_vals(values)
    return float(np.sum(vals)) if vals else 0.0


def _safe_last(values):
    vals = _clean_vals(values)
    return float(vals[-1]) if vals else 0.0


def _safe_weighted_mean(values):
    vals = _clean_vals(values)
    if not vals:
        return 0.0
    weights = np.arange(1, len(vals) + 1, dtype=float)
    return float(np.average(vals, weights=weights))


def _rate_per_min(values, total_time):
    total = _safe_sum(values)
    if total_time <= 0:
        return 0.0
    return float(total / (total_time / 60.0))


def _delta_total(values):
    vals = _clean_vals(values)
    if len(vals) < 2:
        return 0.0
    return float(vals[-1] - vals[0])


def _delta_per_sec(values, total_time):
    if total_time <= 0:
        return 0.0
    return float(_delta_total(values) / total_time)


def _quartile_means(values):
    vals = _clean_vals(values)
    if not vals:
        return (0.0, 0.0, 0.0, 0.0)

    n = len(vals)
    q = max(1, int(np.ceil(n / 4.0)))
    chunks = [
        vals[0:q],
        vals[q:2*q],
        vals[2*q:3*q],
        vals[3*q:]
    ]

    while len(chunks) < 4:
        chunks.append([])

    return tuple(float(np.mean(c)) if c else 0.0 for c in chunks[:4])


def _quartile_sums(values):
    vals = _clean_vals(values)
    if not vals:
        return (0.0, 0.0, 0.0, 0.0)

    n = len(vals)
    q = max(1, int(np.ceil(n / 4.0)))
    chunks = [
        vals[0:q],
        vals[q:2*q],
        vals[2*q:3*q],
        vals[3*q:]
    ]

    while len(chunks) < 4:
        chunks.append([])

    return tuple(float(np.sum(c)) if c else 0.0 for c in chunks[:4])


def _quartile_last_values(values):
    vals = _clean_vals(values)
    if not vals:
        return (0.0, 0.0, 0.0, 0.0)
    n = len(vals)
    q = max(1, int(np.ceil(n / 4.0)))
    chunks = [vals[0:q], vals[q:2*q], vals[2*q:3*q], vals[3*q:]]
    while len(chunks) < 4:
        chunks.append([])
    last = vals[0]
    out = []
    for chunk in chunks[:4]:
        if chunk:
            last = chunk[-1]
        out.append(float(last))
    return tuple(out)


def _row_mesh_count(row, running_count):
    keys = (
        "MeshCount", "Meshes", "NMeshes", "ObjectCount", "Objects",
        "ModelCount", "Models", "Mallas", "NumMeshes", "NumObjects"
    )
    for key in keys:
        value = _csv_float(row, key, default=None)
        if value is not None:
            return max(float(value), 0.0)
    return running_count


def _mesh_count_series(data, object_deltas):
    counts = []
    running = 0.0
    for i, row in enumerate(data or []):
        explicit = _row_mesh_count(row, None)
        if explicit is not None:
            running = explicit
        else:
            delta = object_deltas[i] if i < len(object_deltas) else 0.0
            running = max(running + float(delta), 0.0)
        counts.append(running)
    return counts
        
# CLASE: OBJECT_OT_CalculateMetrics

def summarise_series(values):
    arr = series_to_array(values)
    if arr.size == 0:
        return {"count": 0, "min": 0.0, "max": 0.0, "mean": 0.0, "last": 0.0}
    return {
        "count": int(arr.size),
        "min": round(float(np.min(arr)), 4),
        "max": round(float(np.max(arr)), 4),
        "mean": round(float(np.mean(arr)), 4),
        "last": round(float(arr[-1]), 4),
    }

def validate_selection(context):
    scn = context.scene
    graph = GRAPH_TYPES[scn.selected_graph]
    if scn.selected_graph == "G4":
        # G4 correlates the complete CSV-stat and model-metric families.
        # Individual metric selection is intentionally not required.
        return True, "OK"

    selected = [item for item in scn.analysis_items if item.enabled]

    # G2 and G3 can now be built from mesh metrics only, CSV metrics only,
    # or a combination of both. Do not require CSV metric toggles when the
    # shared mesh-metric selector already provides the variables to render.
    if scn.selected_graph in {"G2", "G3"}:
        mesh_flags = tuple(getattr(scn, "anali_graph_mesh_metrics", (False,) * 19))
        has_mesh_metrics = any(bool(flag) for flag in mesh_flags)
        if not selected and not has_mesh_metrics:
            return False, "No variables selected"
        return True, "OK"

    if not selected:
        return False, "No variables selected"
    for role, count in graph["roles"].items():
        role_items = [item for item in selected if item.role == role]
        if len(role_items) < count:
            return False, f"{graph['label']} requires at least {count} selected metric(s)"
    return True, "OK"


def refresh_analysis_list(self, context):
    scn = getattr(context, "scene", None)
    if scn is None:
        return
    previous = {item.key: {"enabled": item.enabled, "role": item.role} for item in scn.analysis_items}
    scn.analysis_items.clear()
    graph = GRAPH_TYPES[scn.selected_graph]
    for aid, info in ANALYSIS.items():
        if info["typology"] in graph["compatible_typologies"]:
            item = scn.analysis_items.add()
            item.key = aid
            item.label = info["label"]
            item.typology = info["typology"]
            item.enabled = previous.get(aid, {}).get("enabled", False)
            item.role = 'Y'



def _group_member_paths(group):
    try:
        values = json.loads(getattr(group, "member_paths", "[]") or "[]")
    except Exception:
        values = []
    return [os.path.abspath(str(path)) for path in values if path and os.path.isfile(path)]


def _materialize_csv_group(group):
    """Create/update a normalized temporary CSV representing all group members.

    Rows are concatenated in member order and analysed as one pooled source.
    Every member receives a unique session identifier, so time, distance and
    speed calculations restart at each original CSV boundary. Downstream means,
    medians, totals and graphs use all observations from every member file.
    """
    members = _group_member_paths(group)
    if not members:
        return None
    signature = "|".join(f"{path}:{os.path.getmtime(path):.6f}:{os.path.getsize(path)}" for path in members)
    digest = hashlib.sha1((getattr(group, "name", "CSV Group") + signature).encode("utf-8", "replace")).hexdigest()[:16]
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", getattr(group, "name", "CSV_Group")).strip("_") or "CSV_Group"
    target_dir = os.path.join(tempfile.gettempdir(), "Analysis3D_csv_groups")
    os.makedirs(target_dir, exist_ok=True)
    group_dir = os.path.join(target_dir, digest)
    os.makedirs(group_dir, exist_ok=True)
    target = os.path.join(group_dir, f"{safe_name}.csv")
    if os.path.isfile(target):
        return target
    from .csv_schema import CSV_HEADER_V2, normalize_row
    with open(target, "w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_HEADER_V2)
        writer.writeheader()
        for member in members:
            _, rows = read_csv(member)
            for row in rows:
                normalized = normalize_row(row)
                # Prefix identifiers with the source file so member boundaries
                # remain independent even when several CSVs reuse the same IDs.
                source_name = os.path.splitext(os.path.basename(member))[0]
                original_session = normalized.get("SessionID") or source_name
                original_user = normalized.get("UserID") or source_name
                normalized["SessionID"] = f"{source_name}::{original_session}"
                normalized["UserID"] = f"{source_name}::{original_user}"
                writer.writerow(normalized)
    return target


def selected_csv_sources(scene):
    """Return selected individual CSV paths plus selected virtual group paths."""
    sources = [item.name for item in scene.csv_items if item.selected and os.path.isfile(item.name)]
    for group in getattr(scene, "csv_groups", []):
        if not getattr(group, "selected", False):
            continue
        path = _materialize_csv_group(group)
        if path:
            sources.append(path)
    return sources


def csv_source_display_name(scene, path):
    """Return the user-facing identity of a CSV graph source.

    Real CSV files keep their exact basename (including extension). Virtual
    group materializations expose the group name instead of the temporary CSV
    filename/path used internally.
    """
    path = os.path.abspath(str(path or ""))
    norm = os.path.normcase(path)

    for group in getattr(scene, "csv_groups", []):
        if not getattr(group, "selected", False):
            continue
        group_path = _materialize_csv_group(group)
        if group_path and os.path.normcase(os.path.abspath(group_path)) == norm:
            return str(getattr(group, "name", "") or os.path.basename(path) or "Data group")

    for item in getattr(scene, "csv_items", []):
        item_path = getattr(item, "name", "")
        if item_path and os.path.normcase(os.path.abspath(item_path)) == norm:
            return os.path.basename(item_path)

    return os.path.basename(path) or str(path)


def selected_csv_graph_sources(scene):
    """Return graph sources while preserving selected CSV groups as groups.

    Individually selected CSV files remain independent graph series. A selected
    group is materialized as one pooled CSV source, so Interaction, Forest,
    Radar and correlation treat the group as one analytical series instead of
    expanding its members into unrelated individual series.
    """
    sources = []
    seen_individual = set()

    for item in scene.csv_items:
        path = getattr(item, "name", "")
        if not getattr(item, "selected", False) or not os.path.isfile(path):
            continue
        normalized = os.path.normcase(os.path.abspath(path))
        if normalized in seen_individual:
            continue
        seen_individual.add(normalized)
        sources.append(path)

    for group in getattr(scene, "csv_groups", []):
        if not getattr(group, "selected", False):
            continue
        path = _materialize_csv_group(group)
        if path:
            sources.append(path)

    return sources


def selected_csv_file_count(scene):
    """Number of individually selected CSV files, excluding virtual groups."""
    return sum(1 for item in scene.csv_items if item.selected and os.path.isfile(item.name))


def selected_csv_group_count(scene):
    """Number of selected virtual CSV groups with at least one valid member."""
    return sum(
        1 for group in getattr(scene, "csv_groups", [])
        if group.selected and _group_member_paths(group)
    )


def selected_csv_source_count(scene):
    """Total selected analysis sources: individual CSV files plus groups."""
    return selected_csv_file_count(scene) + selected_csv_group_count(scene)

def update_csv_analysis_store(scene):
    csv_store = {}
    for csv_path in selected_csv_sources(scene):
        try:
            _, data = read_csv(csv_path)
            metrics = compute_metrics_for_csv(data, max_reasonable_speed=getattr(scene, "max_reasonable_speed", DEFAULT_MAX_REASONABLE_SPEED))
            key = os.path.basename(csv_path)
            csv_store[key] = metrics
        except Exception as exc:
            print(f"[update_csv_analysis_store] {csv_path}: {exc}")
    scene["csv_metrics_data"] = csv_store
    if "csv_summary_data" in scene:
        del scene["csv_summary_data"]


def get_or_create_graph_scene(csv_name):
    """Use the current scene so graph generation does not reset the add-on state.

    Generated graph objects are removed with clear_previous_graphs(), which only
    targets add-on object prefixes and leaves user meshes in the scene.
    """
    return bpy.context.scene


def switch_to_scene(scene):
    return None


def hide_non_graph_objects(scene):
    """Hide user objects while a graph is being inspected.

    This avoids the startup cube / imported meshes from sitting behind the graph.
    Objects are hidden, not deleted, so the modelling scene is preserved.
    """
    prefixes = (
        "GraphPlane_", "GraphLineMesh_", "Scatter_", "Corr_", "Surface_", "Time_",
        "Forest", "Radar", "Axis_", "Tick_", "Label_", "TickLabel_", "Num_",
        "InteractionBar_", "InteractionLine_", "InteractionPts_", "InteractionLabel_", "TimePts_",
        "G1_", "G1Gap_", "GraphTitle_G1", "GraphSubtitle_G1",
        "DataTable", "TableGrid_", "TableText_", "TableTitle_", "TableSubtitle_",
        "PearsonHeatmap_", "PearsonCell_", "PearsonText_", "PearsonLegend_"
    )
    for obj in scene.objects:
        if obj.name.startswith(prefixes):
            obj.hide_set(False)
            obj.hide_viewport = False
            continue
        if obj.type in {'LIGHT', 'CAMERA'}:
            continue
        obj.hide_set(True)
        obj.hide_viewport = True


def configure_graph_viewport_for_readability(context=None):
    """Use flat material colours and a dark background in all active 3D views.

    Solid studio lighting can make white labels look grey and can alter the
    diverging heatmap colours. Flat material shading preserves contrast while
    keeping the graph as editable Blender geometry.
    """
    ctx = context or bpy.context
    window_manager = getattr(ctx, "window_manager", None)
    windows = list(getattr(window_manager, "windows", []) or [])
    screens = [getattr(window, "screen", None) for window in windows]
    if not screens:
        screen = getattr(ctx, "screen", None)
        screens = [screen] if screen is not None else []

    seen = set()
    for screen in screens:
        if screen is None or id(screen) in seen:
            continue
        seen.add(id(screen))
        for area in screen.areas:
            if area.type != 'VIEW_3D':
                continue
            space = area.spaces.active
            shading = getattr(space, 'shading', None)
            if shading is None:
                continue
            try:
                shading.type = 'SOLID'
                shading.light = 'FLAT'
                shading.color_type = 'MATERIAL'
                if hasattr(shading, 'show_shadows'):
                    shading.show_shadows = False
                if hasattr(shading, 'show_cavity'):
                    shading.show_cavity = False
                if hasattr(shading, 'background_type'):
                    shading.background_type = 'VIEWPORT'
                if hasattr(shading, 'background_color'):
                    shading.background_color = (0.025, 0.030, 0.045)
            except Exception:
                pass


def hide_viewport_guides(context=None):
    """Hide Blender floor grid, world axes and 3D cursor in every 3D View."""
    ctx = context or bpy.context
    window_manager = getattr(ctx, "window_manager", None)
    windows = list(getattr(window_manager, "windows", []) or [])
    if not windows:
        screen = getattr(ctx, "screen", None)
        screens = [screen] if screen is not None else []
    else:
        screens = [getattr(window, "screen", None) for window in windows]

    seen = set()
    for screen in screens:
        if screen is None or id(screen) in seen:
            continue
        seen.add(id(screen))
        for area in screen.areas:
            if area.type != 'VIEW_3D':
                continue
            space = area.spaces.active
            overlay = getattr(space, 'overlay', None)
            if overlay is None:
                continue
            overlay.show_overlays = True
            overlay.show_floor = False
            overlay.show_axis_x = False
            overlay.show_axis_y = False
            overlay.show_axis_z = False
            overlay.show_cursor = False
            if hasattr(overlay, 'show_ortho_grid'):
                overlay.show_ortho_grid = False


def restore_hidden_scene_objects(scene, context=None):
    """Show hidden objects and restore Blender viewport guides.

    Graph visualization can hide the floor grid, world axes and 3D cursor to
    reduce visual noise. Restoring the scene must return those viewport aids as
    well, in every open 3D View rather than only in the currently active area.
    """
    for obj in scene.objects:
        obj.hide_set(False)
        obj.hide_viewport = False

    ctx = context or bpy.context
    window_manager = getattr(ctx, "window_manager", None)
    windows = list(getattr(window_manager, "windows", []) or [])

    # Fallback for unusual contexts without a WindowManager window list.
    if not windows:
        screen = getattr(ctx, "screen", None)
        screens = [screen] if screen is not None else []
    else:
        screens = [getattr(window, "screen", None) for window in windows]

    seen = set()
    for screen in screens:
        if screen is None or id(screen) in seen:
            continue
        seen.add(id(screen))
        for area in screen.areas:
            if area.type != 'VIEW_3D':
                continue
            space = area.spaces.active
            overlay = getattr(space, 'overlay', None)
            if overlay is None:
                continue
            overlay.show_overlays = True
            overlay.show_floor = True
            overlay.show_axis_x = True
            overlay.show_axis_y = True
            overlay.show_axis_z = True
            overlay.show_cursor = True
            # These improve parity with Blender's default viewport presentation.
            if hasattr(overlay, 'show_ortho_grid'):
                overlay.show_ortho_grid = True
            if hasattr(overlay, 'show_text'):
                overlay.show_text = True


def frame_graph_camera(scene, scn):
    """Centra el viewport en vista superior ortográfica sin crear cámaras."""
    bpy.context.view_layer.update()
    prefixes = (
        "GraphPlane_", "GraphLineMesh_", "Scatter_", "Corr_", "Surface_", "Time_",
        "Forest", "Radar", "Axis_", "Tick_", "Label_", "TickLabel_", "Num_",
        "InteractionBar_", "InteractionLine_", "InteractionPts_", "InteractionLabel_", "TimePts_",
        "DataTable", "TableGrid_", "TableText_", "TableTitle_", "TableSubtitle_",
        "PearsonHeatmap_", "PearsonCell_", "PearsonText_", "PearsonLegend_"
    )

    coords = []
    for obj in scene.objects:
        if not obj.name.startswith(prefixes):
            continue
        try:
            for corner in obj.bound_box:
                coords.append(obj.matrix_world @ Vector(corner))
        except Exception:
            coords.append(obj.location.copy())

    if coords:
        min_x = min(v.x for v in coords); max_x = max(v.x for v in coords)
        min_y = min(v.y for v in coords); max_y = max(v.y for v in coords)
        min_z = min(v.z for v in coords); max_z = max(v.z for v in coords)
    else:
        min_x, min_y, min_z = 0.0, 0.0, 0.0
        max_x, max_y, max_z = float(scn.axis_scale_x), float(scn.axis_scale_y), float(scn.axis_scale_z)

    center = Vector(((min_x + max_x) / 2.0, (min_y + max_y) / 2.0, (min_z + max_z) / 2.0))
    width = max(max_x - min_x, 1.0)
    height = max(max_y - min_y, 1.0)
    depth = max(max_z - min_z, 1.0)
    ortho_scale = max(width, height) * 1.12
    camera_height = max_z + max(width, height, depth, float(scn.axis_scale_z), 1.0) * 2.0 + 5.0


    # Ajusta también la vista activa de los Viewports 3D para que al visualizar se vea desde arriba.
    screen = getattr(bpy.context, "screen", None)
    if screen:
        for area in screen.areas:
            if area.type != 'VIEW_3D':
                continue
            for space in area.spaces:
                if space.type == 'VIEW_3D' and space.region_3d:
                    space.region_3d.view_perspective = 'ORTHO'
                    space.region_3d.view_location = center
                    space.region_3d.view_rotation = (1.0, 0.0, 0.0, 0.0)
                    space.region_3d.view_distance = max(width, height, depth) * 1.30 + 0.65


def draw_axes_for_graph(scn, labels, graph_data=None, z_range=None):
    clear_axes_objects(bpy.context.scene)
    graph_data = graph_data or {
        "x_range": (0.0, 1.0),
        "y_range": (0.0, 1.0),
        "x_ticks": [0.0, 0.25, 0.5, 0.75, 1.0],
        "y_ticks": [0.0, 0.25, 0.5, 0.75, 1.0],
    }
    labels = list(labels[:3]) if labels else ["X", "Y", "Z"]
    while len(labels) < 3:
        labels.append(["X", "Y", "Z"][len(labels)])
    draw_axes1(
        length_x=scn.axis_scale_x,
        length_y=scn.axis_scale_y,
        length_z=scn.axis_scale_z,
        labels=labels,
        x_range=graph_data.get("x_range", (0, 1)),
        y_range=graph_data.get("y_range", (0, 1)),
        z_range=z_range or (0, scn.axis_scale_z),
        x_ticks=graph_data.get("x_ticks"),
        y_ticks=graph_data.get("y_ticks"),
        z_ticks=[0, scn.axis_scale_z] if labels[2] else [],
        tick_size=0.12,
        text_size=0.30,
    )



def scene_length_scale_m(scene) -> float:
    """Return metres represented by one Blender Unit for display conversion."""
    try:
        scale = float(scene.unit_settings.scale_length)
    except Exception:
        scale = 1.0
    return scale if scale > 0.0 else 1.0


def distance_bu_to_m(scene, value):
    """Convert a distance stored in Blender Units to metres."""
    try:
        return float(value) * scene_length_scale_m(scene)
    except Exception:
        return 0.0


def scene_local_length_unit(scene):
    """Return (metres_per_display_unit, label) for the scene's local length unit."""
    try:
        settings = scene.unit_settings
        system = str(settings.system)
        length_unit = str(settings.length_unit)
    except Exception:
        return 1.0, "BU"

    metric = {
        "KILOMETERS": (1000.0, "km"),
        "METERS": (1.0, "m"),
        "CENTIMETERS": (0.01, "cm"),
        "MILLIMETERS": (0.001, "mm"),
        "MICROMETERS": (0.000001, "µm"),
    }
    imperial = {
        "MILES": (1609.344, "mi"),
        "FEET": (0.3048, "ft"),
        "INCHES": (0.0254, "in"),
        "THOU": (0.0000254, "thou"),
    }
    if length_unit in metric:
        return metric[length_unit]
    if length_unit in imperial:
        return imperial[length_unit]
    if system == "METRIC":
        return 1.0, "m"
    if system == "IMPERIAL":
        return 0.3048, "ft"
    return 1.0, "BU"


def distance_bu_to_local(scene, value):
    """Convert Blender Units to the scene's selected local display unit."""
    try:
        metres_per_unit, _label = scene_local_length_unit(scene)
        if _label == "BU":
            return float(value)
        return float(value) * scene_length_scale_m(scene) / metres_per_unit
    except Exception:
        return 0.0


def speed_bu_h_to_local_h(scene, value):
    """Convert Blender Units/hour to the scene local length unit/hour.

    The stored speed is first converted to metres/hour and then divided by
    the number of metres represented by one selected local unit.
    """
    try:
        metres_per_local_unit, label = scene_local_length_unit(scene)
        if label == "BU":
            return float(value)
        metres_per_hour = float(value) * scene_length_scale_m(scene)
        return metres_per_hour / metres_per_local_unit
    except Exception:
        return 0.0




def speed_bu_min_to_local_min(scene, value):
    """Convert Blender Units/minute to the scene local length unit/minute."""
    try:
        metres_per_local_unit, label = scene_local_length_unit(scene)
        if label == "BU":
            return float(value)
        metres_per_minute = float(value) * scene_length_scale_m(scene)
        return metres_per_minute / metres_per_local_unit
    except Exception:
        return 0.0


def local_speed_min_unit_label(scene):
    """Return the scene-local speed label, for example cm/min or ft/min."""
    return f"{scene_local_length_unit(scene)[1]}/min"

def area_bu2_to_local2(scene, value):
    """Convert world-space Blender Units squared to local display units squared."""
    factor = distance_bu_to_local(scene, 1.0)
    return float(value) * factor * factor


def local_area_unit_label(scene):
    """Return the scene-local area label, for example cm² or ft²."""
    return f"{scene_local_length_unit(scene)[1]}²"


def local_speed_unit_label(scene):
    """Return the scene-local speed label, for example cm/h or ft/h."""
    return f"{scene_local_length_unit(scene)[1]}/h"


def speed_bu_h_to_m_h(scene, value):
    """Backward-compatible conversion to metres/hour."""
    return distance_bu_to_m(scene, value)


def speed_bu_min_to_m_min(scene, value):
    """Convert Blender Units/minute to metres/minute."""
    return distance_bu_to_m(scene, value)

def _split_analysis_sessions(data):
    """Split normalized rows into independent logger sessions.

    Groups materialize several CSV files in one temporary CSV.  SessionID is
    prefixed with the source filename, so it is the primary boundary.  A time
    reset is also treated as a boundary for legacy files.
    """
    sessions = []
    current = []
    current_key = None
    previous_time = None
    for index, row in enumerate(data or []):
        key = _csv_session_key(row, index)
        row_time = _row_time(row)
        if current and (key != current_key or (previous_time is not None and row_time < previous_time)):
            sessions.append(current)
            current = []
        current.append(row)
        current_key = key
        previous_time = row_time
    if current:
        sessions.append(current)
    return sessions


def _session_metric_mean(session_metrics, key):
    """Equal-weight mean of a metric across sessions, never row-weighted."""
    means = []
    for metrics in session_metrics:
        vals = _clean_vals(metrics.get(key, []))
        if vals:
            means.append(_safe_mean(vals))
    return _safe_mean(means)


def _session_metric_mean_std(session_metrics, key):
    """Std. deviation of session means (participant/session level)."""
    means = []
    for metrics in session_metrics:
        vals = _clean_vals(metrics.get(key, []))
        if vals:
            means.append(_safe_mean(vals))
    return _safe_std(means)

def update_scene_metric_stats(context):
    scn = context.scene
    scn.metric_stats.clear()

    selected_csvs = selected_csv_sources(scn)

    for csv_path in selected_csvs:
        try:
            _, data = read_csv(csv_path)
            metrics = compute_metrics_for_csv(data, max_reasonable_speed=getattr(context.scene, "max_reasonable_speed", DEFAULT_MAX_REASONABLE_SPEED))
        except Exception as exc:
            print(f"[update_scene_metric_stats] {csv_path}: {exc}")
            continue

        csv_name = os.path.basename(csv_path)

        # A selected CSV group must represent the average session/participant,
        # not one huge concatenated recording. Keep the pooled data for the
        # existing low-level calculations, but retain independent session
        # summaries so group-level outputs can be aggregated with equal weight.
        analysis_sessions = _split_analysis_sessions(data)
        session_count = max(len(analysis_sessions), 1)
        session_metrics = [
            compute_metrics_for_csv(
                rows,
                max_reasonable_speed=getattr(context.scene, "max_reasonable_speed", DEFAULT_MAX_REASONABLE_SPEED),
            )
            for rows in analysis_sessions
        ]
        session_durations_min = [
            _safe_last(_clean_vals(sm.get("A1", [])))
            for sm in session_metrics
            if _clean_vals(sm.get("A1", []))
        ]
        group_duration_mean_min = _safe_mean(session_durations_min) if session_durations_min else 0.0

        times_abs = [_row_time(row) for row in data] if data else []
        raw_duration = max(times_abs[-1] - times_abs[0], 0.0) if len(times_abs) > 1 else 0.0
        a1_vals = _clean_vals(metrics.get("A1", []))
        total_time_min = _safe_last(a1_vals) if a1_vals else 0.0
        total_time_hour = total_time_min / 60.0
        total_time_sec = total_time_min * 60.0
        object_local_sizes = [_row_object_local_size(row) for row in data] if data else []
        object_local_size_mean = _safe_mean([v for v in object_local_sizes if v > 0.0])
        speed_values = _clean_vals(metrics.get("A4", []))
        peak_flags = _clean_vals(metrics.get("A6", []))
        peak_speeds = [speed_values[i] for i, flag in enumerate(peak_flags) if i < len(speed_values) and abs(flag) > 0.0]
        peak_speed_mean = _safe_mean(peak_speeds) if peak_speeds else _safe_mean(speed_values)
        vertex_deltas = [_csv_float(row, "VertexDelta", "VerticesDelta", "VertDelta", "Vertex", default=0.0) for row in data]
        ngon_deltas = [_csv_float(row, "NgonDelta", "NGonDelta", "NgonsDelta", default=0.0) for row in data]
        tri_deltas = [_csv_float(row, "TriDelta", "TriangleDelta", "TrianglesDelta", default=0.0) for row in data]
        normal_deltas = [_csv_float(row, "NormalDelta", "NormalsDelta", default=0.0) for row in data]
        nonmanifold_deltas = [_csv_float(row, "NonManifoldDelta", "NonmanifoldDelta", "NonManifold", "Nonmanifold", default=0.0) for row in data]
        # Error totals mean newly introduced issues; negative deltas are fixes and
        # are reported separately instead of being counted as new errors.
        ngon_errors = [max(v, 0.0) for v in ngon_deltas]
        tri_errors = [max(v, 0.0) for v in tri_deltas]
        normal_errors = [max(v, 0.0) for v in normal_deltas]
        nonmanifold_errors = [max(v, 0.0) for v in nonmanifold_deltas]
        mesh_issue_created = [sum(max(v, 0.0) for v in values) for values in zip(ngon_deltas, tri_deltas, normal_deltas, nonmanifold_deltas)]
        mesh_issue_resolved = [sum(max(-v, 0.0) for v in values) for values in zip(ngon_deltas, tri_deltas, normal_deltas, nonmanifold_deltas)]
        mesh_issue_activity = [a + b for a, b in zip(mesh_issue_created, mesh_issue_resolved)]
        modifier_deltas = [
            _signed_change(
                row,
                ("ModifierDelta", "Modifier", "Modifier actionsDelta", "Modifier actions"),
                ("ModifierCreated", "ModifiersCreated"),
                ("ModifierDeleted", "ModifiersDeleted"),
            ) for row in data
        ]
        object_deltas = [
            _signed_change(
                row,
                ("ObjectDelta", "ObjectsDelta"),
                ("ObjectCreated", "ObjectsCreated"),
                ("ObjectDeleted", "ObjectsDeleted"),
            ) for row in data
        ]
        ctrl_v_values = [_csv_float(row, "CtrlV", default=0.0) for row in data]
        shift_d_values = [_csv_float(row, "ShiftD", default=0.0) for row in data]
        alt_d_values = [_csv_float(row, "AltD", default=0.0) for row in data]
        duplicate_values = [
            abs(_csv_float(row, "Duplicate", "DuplicateAction", default=0.0))
            if _csv_has_value(row, "Duplicate", "DuplicateAction")
            else max(abs(_csv_float(row, "CtrlV", default=0.0)), abs(_csv_float(row, "ShiftD", default=0.0)))
            for row in data
        ]
        instance_values = [
            abs(_csv_float(row, "Instance", "InstanceAction", default=0.0))
            if _csv_has_value(row, "Instance", "InstanceAction")
            else abs(_csv_float(row, "AltD", default=0.0))
            for row in data
        ]
        uv_deploy_values = [
            _csv_float(row, "UVDeploy", default=0.0)
            if "UVDeploy" in row
            else _csv_float(row, "UVAction", "UV", default=0.0)
            for row in data
        ]
        occlusion_values = [
            1.0 if abs(_csv_float(row, "Occlusion", "OcclusionState", "Occluded", default=0.0)) > 0.0 else 0.0
            for row in data
        ]
        orthographic_values = [
            1.0 if abs(_csv_float(row, "Orthographic", "OrthoState", "OrthographicState", default=0.0)) > 0.0 else 0.0
            for row in data
        ]

        for key, values in metrics.items():
            vals = _clean_vals(values)
            abs_vals = [abs(v) for v in vals]

            st = scn.metric_stats.add()
            st.csv_name = csv_name
            st.key = key
            st.label = ANALYSIS.get(key, {}).get("label", key)
            st.object_local_size = object_local_size_mean
            st.peak_speed_mean = peak_speed_mean
            if key == "A13":
                st.ngon_error_total = _safe_sum(ngon_errors)
                st.tri_error_total = _safe_sum(tri_errors)
                st.normal_error_total = _safe_sum(normal_errors)
                st.nonmanifold_error_total = _safe_sum(nonmanifold_errors)
                st.issue_created_total = _safe_sum(mesh_issue_created)
                st.issue_resolved_total = _safe_sum(mesh_issue_resolved)
            # For a group, each source session has the same statistical
            # weight. Otherwise CSVs sampled more frequently would dominate.
            if session_count > 1:
                st.value = _session_metric_mean(session_metrics, key)
                st.mean = st.value
                st.weighted_mean = st.value
                st.std = _session_metric_mean_std(session_metrics, key)
            else:
                st.value = _safe_mean(vals)
                st.mean = _safe_mean(vals)
                st.weighted_mean = _safe_weighted_mean(vals)
                st.std = _safe_std(vals)
            st.min = _safe_min(vals)
            st.max = _safe_max(vals)

            st.total = _safe_sum(vals)
            st.abs_total = _safe_sum(abs_vals)

            event_count = float(sum(1 for v in abs_vals if v > 0.0))

            # Signed balance metrics.
            if key == "A11":
                st.created_total = _safe_sum([v for v in modifier_deltas if v > 0.0])
                st.deleted_total = _safe_sum([-v for v in modifier_deltas if v < 0.0])
                st.total = _safe_sum(modifier_deltas)
                st.abs_total = st.created_total + st.deleted_total
                event_count = float(sum(1 for v in modifier_deltas if abs(v) > 0.0))
            elif key == "A12":
                st.created_total = _safe_sum([v for v in vertex_deltas if v > 0.0])
                st.deleted_total = _safe_sum([-v for v in vertex_deltas if v < 0.0])
                st.total = _safe_sum(vertex_deltas)
                st.abs_total = st.created_total + st.deleted_total
                event_count = float(sum(1 for v in vertex_deltas if abs(v) > 0.0))
            elif key == "A13":
                st.total = _safe_sum(vals)
                st.abs_total = _safe_sum(mesh_issue_created)
                event_count = _safe_sum(mesh_issue_created)
            elif key == "A16":
                st.created_total = _safe_sum([v for v in object_deltas if v > 0.0])
                st.deleted_total = _safe_sum([-v for v in object_deltas if v < 0.0])
                st.total = _safe_sum(object_deltas)
                st.abs_total = st.created_total + st.deleted_total
                event_count = float(sum(1 for v in object_deltas if abs(v) > 0.0))
            elif key == "A10":
                st.ctrl_v_total = _safe_sum([abs(v) for v in ctrl_v_values])
                st.shift_d_total = _safe_sum([abs(v) for v in shift_d_values])
                st.alt_d_total = _safe_sum([abs(v) for v in alt_d_values])
                st.duplicate_total = _safe_sum(duplicate_values)
                st.instance_total = _safe_sum(instance_values)
                st.total = st.duplicate_total + st.instance_total
                st.abs_total = st.total
                event_count = st.total
            elif key == "A15":
                st.uv_deploy_total = _safe_sum([abs(v) for v in uv_deploy_values])
                st.uv_transform_total = 0.0
                st.uv_associated_total = 0.0
                st.total = float(sum(1 for v in uv_deploy_values if abs(v) > 0.0))
                st.abs_total = st.total
                event_count = st.total
            elif key in {"A17", "A19"}:
                state_values = occlusion_values if key == "A17" else orthographic_values
                activations = 0.0
                previous = 0.0
                for value in state_values:
                    current = 1.0 if value >= 0.5 else 0.0
                    if current > 0.5 and previous <= 0.5:
                        activations += 1.0
                    previous = current

                active_sec = 0.0
                q_active_sec = [0.0, 0.0, 0.0, 0.0]
                q_total_sec = [0.0, 0.0, 0.0, 0.0]
                if data and len(data) > 1 and times_abs:
                    first_time = times_abs[0]
                    scale = (total_time_sec / raw_duration) if raw_duration > 0 and total_time_sec > 0 else 0.0
                    for i in range(len(data) - 1):
                        dt_raw = max(times_abs[i + 1] - times_abs[i], 0.0)
                        dt = dt_raw * scale if scale > 0 else 0.0
                        start_scaled = max((times_abs[i] - first_time) * scale, 0.0) if scale > 0 else 0.0
                        mid_scaled = start_scaled + dt * 0.5
                        q_idx = min(max(int((mid_scaled / total_time_sec) * 4.0), 0), 3) if total_time_sec > 0 else 0
                        q_total_sec[q_idx] += dt
                        if state_values[i] >= 0.5:
                            active_sec += dt
                            q_active_sec[q_idx] += dt

                st.activations = activations
                st.time_active_min = active_sec / 60.0
                st.pct_active = (100.0 * active_sec / total_time_sec) if total_time_sec > 0 else 0.0
                st.total = st.pct_active
                st.abs_total = activations
                event_count = activations
                q_pct = [(100.0 * x / y) if y > 0 else 0.0 for x, y in zip(q_active_sec, q_total_sec)]
                st.q1, st.q2, st.q3, st.q4 = q_pct

            st.count = event_count

            if session_count > 1 and key in {"A17", "A19"}:
                # See-through is a state metric: average each session's active
                # percentage and quartile percentages equally.
                pct_sessions = []
                active_min_sessions = []
                activation_sessions = []
                q_pct_sessions = [[], [], [], []]
                for rows, sm in zip(analysis_sessions, session_metrics):
                    states = _clean_vals(sm.get(key, []))
                    times_s = [_row_time(row) for row in rows]
                    if len(rows) < 2 or len(times_s) < 2:
                        continue
                    first_s = times_s[0]
                    raw_s = max(times_s[-1] - first_s, 0.0)
                    active_raw = 0.0
                    q_active = [0.0] * 4
                    q_total = [0.0] * 4
                    acts = 0.0
                    prev = 0.0
                    for value in states:
                        cur = 1.0 if value >= 0.5 else 0.0
                        if cur > 0.5 and prev <= 0.5:
                            acts += 1.0
                        prev = cur
                    for i in range(len(rows) - 1):
                        dt = max(times_s[i + 1] - times_s[i], 0.0)
                        mid = max(times_s[i] - first_s, 0.0) + dt * 0.5
                        qi = min(max(int((mid / raw_s) * 4.0), 0), 3) if raw_s > 0 else 0
                        q_total[qi] += dt
                        state = states[i] if i < len(states) else 0.0
                        if state >= 0.5:
                            active_raw += dt
                            q_active[qi] += dt
                    dur_min_s = _safe_last(_clean_vals(sm.get("A1", [])))
                    pct_sessions.append((100.0 * active_raw / raw_s) if raw_s > 0 else 0.0)
                    active_min_sessions.append((dur_min_s * active_raw / raw_s) if raw_s > 0 else 0.0)
                    activation_sessions.append(acts)
                    for qi in range(4):
                        q_pct_sessions[qi].append((100.0 * q_active[qi] / q_total[qi]) if q_total[qi] > 0 else 0.0)
                st.pct_active = _safe_mean(pct_sessions)
                st.time_active_min = _safe_mean(active_min_sessions)
                st.activations = _safe_mean(activation_sessions)
                st.count = st.activations
                st.total = st.pct_active
                st.abs_total = st.activations
                st.q1, st.q2, st.q3, st.q4 = [_safe_mean(v) for v in q_pct_sessions]

            # Event frequency is always expressed per minute.
            if key in {"A2", "A6", "A10", "A11", "A12", "A13", "A15", "A16", "A17", "A18", "A19"}:
                st.rate_per_min = event_count / total_time_min if total_time_min > 0 else 0.0
                st.rate_per_hour = event_count / total_time_hour if total_time_hour > 0 else 0.0

            # Other accumulated/intensity metrics keep magnitude/time semantics.
            else:
                st.rate_per_min = st.abs_total / total_time_min if total_time_min > 0 else 0.0
                st.rate_per_hour = st.abs_total / total_time_hour if total_time_hour > 0 else 0.0

            st.delta_total = _delta_total(vals)
            st.delta_per_sec = _delta_per_sec(vals, total_time_sec)

            if key == "A3":
                # Pause-duration quartiles, expressed in minutes.
                st.q1, st.q2, st.q3, st.q4 = _quartile_sums(abs_vals)
            elif key in {"A2", "A6", "A7", "A8", "A9", "A10", "A15", "A18"}:
                event_vals = [1.0 if abs(v) > 0.0 else 0.0 for v in vals]
                st.q1, st.q2, st.q3, st.q4 = _quartile_sums(event_vals)
            elif key in {"A17", "A19"}:
                pass
            elif key in {"A10", "A11", "A12", "A13", "A15", "A16", "A18"}:
                # Signed algebraic balance inside each quartile.
                st.q1, st.q2, st.q3, st.q4 = _quartile_sums(vals)
            else:
                st.q1, st.q2, st.q3, st.q4 = _quartile_sums(abs_vals)

            if key == "A1":
                # A group duration is the arithmetic mean of its member
                # sessions, never the accumulated duration of all members.
                st.total = group_duration_mean_min if session_count > 1 else _safe_last(vals)
                st.value = st.total
                st.mean = st.total
                st.weighted_mean = st.total
                st.rate_per_min = 0.0
                st.rate_per_hour = 0.0

            # Totals shown for a group are per-session averages.  Summing all
            # participants makes a larger group appear artificially more active.
            if session_count > 1 and key != "A1":
                # State metrics (A17/A19) have already been averaged session by
                # session above; accumulated/event metrics still need division.
                if key not in {"A17", "A19"}:
                    additive_fields = (
                        "total", "abs_total", "count", "created_total", "deleted_total",
                        "ctrl_v_total", "shift_d_total", "alt_d_total", "duplicate_total",
                        "instance_total", "uv_deploy_total", "uv_transform_total",
                        "uv_associated_total", "activations", "time_active_min", "switches",
                        "ngon_error_total", "tri_error_total", "normal_error_total",
                        "nonmanifold_error_total", "issue_created_total", "issue_resolved_total",
                        "q1", "q2", "q3", "q4",
                    )
                    for field in additive_fields:
                        setattr(st, field, getattr(st, field) / session_count)

                # Frequencies use the average session duration and the average
                # event/activity amount, matching the semantics of the card.
                if group_duration_mean_min > 0.0:
                    if key in {"A2", "A6", "A10", "A11", "A12", "A13", "A15", "A16", "A17", "A18", "A19"}:
                        st.rate_per_min = st.count / group_duration_mean_min
                        st.rate_per_hour = st.count / (group_duration_mean_min / 60.0)
                    else:
                        st.rate_per_min = st.abs_total / group_duration_mean_min
                        st.rate_per_hour = st.abs_total / (group_duration_mean_min / 60.0)

            if key == "A14" and data:
                mode_vals = vals
                time_object = 0.0
                time_edit = 0.0
                switches = 0.0
                q_object = [0.0, 0.0, 0.0, 0.0]
                q_edit = [0.0, 0.0, 0.0, 0.0]
                q_switches = [0.0, 0.0, 0.0, 0.0]

                scale = (total_time_sec / raw_duration) if raw_duration > 0 and total_time_sec > 0 else 0.0
                first_time = times_abs[0] if times_abs else 0.0

                for i in range(len(data) - 1):
                    dt_raw = max(times_abs[i + 1] - times_abs[i], 0.0)
                    dt = dt_raw * scale if scale > 0 else 0.0
                    start_scaled = max((times_abs[i] - first_time) * scale, 0.0) if scale > 0 else 0.0
                    mid_scaled = start_scaled + dt * 0.5
                    if total_time_sec > 0:
                        q_idx = min(max(int((mid_scaled / total_time_sec) * 4.0), 0), 3)
                    else:
                        q_idx = min(i * 4 // max(len(data) - 1, 1), 3)

                    mode = mode_vals[i] if i < len(mode_vals) else 0.0

                    if mode == 1.0:
                        time_object += dt
                        q_object[q_idx] += dt
                    elif mode == 2.0:
                        time_edit += dt
                        q_edit[q_idx] += dt

                    next_mode = mode_vals[i + 1] if i + 1 < len(mode_vals) else mode
                    if next_mode != mode:
                        switches += 1.0
                        end_scaled = start_scaled + dt
                        if total_time_sec > 0:
                            switch_q = min(max(int((end_scaled / total_time_sec) * 4.0), 0), 3)
                        else:
                            switch_q = q_idx
                        q_switches[switch_q] += 1.0

                q_totals = [max(q_object[i] + q_edit[i], 1e-9) for i in range(4)]
                q_obj_pct = [(q_object[i] / q_totals[i]) * 100.0 if q_totals[i] > 0 else 0.0 for i in range(4)]
                q_edit_pct = [(q_edit[i] / q_totals[i]) * 100.0 if q_totals[i] > 0 else 0.0 for i in range(4)]

                st.time_object = time_object
                st.time_edit = time_edit
                st.pct_object = time_object / total_time_sec * 100.0 if total_time_sec > 0 else 0.0
                st.pct_edit = time_edit / total_time_sec * 100.0 if total_time_sec > 0 else 0.0
                st.switches = switches
                st.pct_object_q1, st.pct_object_q2, st.pct_object_q3, st.pct_object_q4 = q_obj_pct
                st.pct_edit_q1, st.pct_edit_q2, st.pct_edit_q3, st.pct_edit_q4 = q_edit_pct
                st.mode_switch_q1, st.mode_switch_q2, st.mode_switch_q3, st.mode_switch_q4 = q_switches
                # Keep q1-q4 meaningful for generic displays: they now hold mode switches per quartile.
                st.q1, st.q2, st.q3, st.q4 = q_switches

                if session_count > 1:
                    # Object/Edit percentages must also be equal-weighted by
                    # session instead of duration-weighted by the pooled CSV.
                    session_obj_pct = []
                    session_edit_pct = []
                    session_switch_rates = []
                    session_obj_q = [[], [], [], []]
                    session_edit_q = [[], [], [], []]
                    for rows, sm in zip(analysis_sessions, session_metrics):
                        mode_vals_s = _clean_vals(sm.get("A14", []))
                        times_s = [_row_time(row) for row in rows]
                        if len(rows) < 2 or len(times_s) < 2:
                            continue
                        obj_t = edit_t = 0.0
                        switches_s = 0.0
                        q_obj_s = [0.0] * 4
                        q_edit_s = [0.0] * 4
                        q_total_s = [0.0] * 4
                        first_s, last_s = times_s[0], times_s[-1]
                        raw_s = max(last_s - first_s, 0.0)
                        for i in range(len(rows) - 1):
                            dt = max(times_s[i + 1] - times_s[i], 0.0)
                            mid = max(times_s[i] - first_s, 0.0) + dt * 0.5
                            qi = min(max(int((mid / raw_s) * 4.0), 0), 3) if raw_s > 0 else 0
                            q_total_s[qi] += dt
                            mode = mode_vals_s[i] if i < len(mode_vals_s) else 0.0
                            if mode == 1.0:
                                obj_t += dt; q_obj_s[qi] += dt
                            elif mode == 2.0:
                                edit_t += dt; q_edit_s[qi] += dt
                            nxt = mode_vals_s[i + 1] if i + 1 < len(mode_vals_s) else mode
                            if nxt != mode:
                                switches_s += 1.0
                        denom = obj_t + edit_t
                        if denom > 0:
                            session_obj_pct.append(100.0 * obj_t / denom)
                            session_edit_pct.append(100.0 * edit_t / denom)
                        dur_min_s = _safe_last(_clean_vals(sm.get("A1", [])))
                        if dur_min_s > 0:
                            session_switch_rates.append(switches_s / dur_min_s)
                        for qi in range(4):
                            if q_total_s[qi] > 0:
                                session_obj_q[qi].append(100.0 * q_obj_s[qi] / q_total_s[qi])
                                session_edit_q[qi].append(100.0 * q_edit_s[qi] / q_total_s[qi])
                    st.time_object /= session_count
                    st.time_edit /= session_count
                    st.switches /= session_count
                    st.pct_object = _safe_mean(session_obj_pct)
                    st.pct_edit = _safe_mean(session_edit_pct)
                    st.pct_object_q1, st.pct_object_q2, st.pct_object_q3, st.pct_object_q4 = [_safe_mean(v) for v in session_obj_q]
                    st.pct_edit_q1, st.pct_edit_q2, st.pct_edit_q3, st.pct_edit_q4 = [_safe_mean(v) for v in session_edit_q]
   
def _session_duration_min_from_metrics(metrics):
    times = series_to_array(metrics.get("A1", []))
    times = times[np.isfinite(times)]
    if times.size == 0:
        return 0.0
    return max(float(times[-1]), 0.0)


def _time_weighted_binary_percent(times, states):
    """Time-weighted percentage for a 0/1 state series."""
    x = series_to_array(times)
    y = series_to_array(states)
    n = min(x.size, y.size)
    if n < 2:
        return 100.0 * float(np.mean(y[:n] >= 0.5)) if n else 0.0
    x = np.asarray(x[:n], dtype=float)
    y = np.asarray(y[:n], dtype=float)
    valid = np.isfinite(x) & np.isfinite(y)
    x, y = x[valid], y[valid]
    if x.size < 2:
        return 100.0 * float(np.mean(y >= 0.5)) if y.size else 0.0
    dt = np.maximum(np.diff(x), 0.0)
    total = float(np.sum(dt))
    if total <= 1e-12:
        return 100.0 * float(np.mean(y >= 0.5))
    active = float(np.sum(dt * (y[:-1] >= 0.5)))
    return 100.0 * active / total


def radar_summary_value(metric_key, metrics):
    """Return one comparable session-level scalar for G3/radar.

    Event and signed-change metrics are normalized per minute so long sessions
    do not automatically dominate short sessions. Occlusion is time-weighted %.
    """
    vals = series_to_array(metrics.get(metric_key, []))
    vals = vals[np.isfinite(vals)]
    if vals.size == 0:
        return None, ""

    duration_min = max(_session_duration_min_from_metrics(metrics), 1e-9)

    if metric_key == "A1":
        return float(vals[-1]), "min"
    if metric_key in {"A2", "A3"}:
        return float(np.sum(vals > 0.0)), "stops"
    if metric_key == "A4":
        return float(np.mean(vals)), "local size/min"
    if metric_key == "A5":
        return float(np.mean(vals)), "× local size"
    if metric_key in {"A6", "A7", "A8", "A9"}:
        return float(np.sum(vals > 0.0)) / duration_min, "peaks/min"
    if metric_key == "A10":
        return float(np.sum(vals)) / duration_min, "events/min"
    if metric_key == "A11":
        return float(np.sum(vals)) / duration_min, "net modifiers/min"
    if metric_key == "A12":
        return float(np.sum(vals)) / duration_min, "net vertices/min"
    if metric_key == "A13":
        return float(np.sum(vals)) / duration_min, "net issues/min"
    if metric_key == "A14":
        return float(np.mean(vals)), "mode"
    if metric_key == "A15":
        return float(np.sum(vals > 0.0)) / duration_min, "events/min"
    if metric_key == "A16":
        return float(np.sum(vals)) / duration_min, "net objects/min"
    if metric_key in {"A17", "A19"}:
        return _time_weighted_binary_percent(metrics.get("A1", []), metrics.get(metric_key, [])), "% active"
    if metric_key == "A18":
        return float(np.sum(vals > 0.0)) / duration_min, "events/min"

    return float(np.mean(vals)), "units"


def normalize_radar_values(raw_values):
    if not raw_values:
        return []

    vals = np.asarray(raw_values, dtype=float)
    vals = np.nan_to_num(vals, nan=0.0, posinf=0.0, neginf=0.0)

    min_v = float(np.min(vals))
    max_v = float(np.max(vals))
    rng = max(max_v - min_v, 1e-9)

    return [0.05 + 0.95 * ((float(v) - min_v) / rng) for v in vals]


def _signed_log10_1p(values):
    """Compress numeric values while preserving sign and zeros."""
    arr = np.asarray(values, dtype=float)
    return np.sign(arr) * np.log10(1.0 + np.abs(arr))


def _forest_t_critical_95(df):
    """Two-sided 95% Student-t critical value without requiring SciPy."""
    df = max(int(df), 1)
    table = {
        1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571,
        6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262, 10: 2.228,
        11: 2.201, 12: 2.179, 13: 2.160, 14: 2.145, 15: 2.131,
        16: 2.120, 17: 2.110, 18: 2.101, 19: 2.093, 20: 2.086,
        21: 2.080, 22: 2.074, 23: 2.069, 24: 2.064, 25: 2.060,
        26: 2.056, 27: 2.052, 28: 2.048, 29: 2.045, 30: 2.042,
        40: 2.021, 60: 2.000, 120: 1.980,
    }
    if df in table:
        return table[df]
    if df > 120:
        return 1.960
    keys = sorted(table)
    lo = max(k for k in keys if k < df)
    hi = min(k for k in keys if k > df)
    fraction = (df - lo) / float(hi - lo)
    return table[lo] + fraction * (table[hi] - table[lo])


def forest_row_stats(metric_key, metrics, csv_name, use_log_scale=False):
    """Summarise one CSV series as a mean with a two-sided 95% t interval.

    The returned standard error is used by the comparative forest plot for a
    random-effects meta-analysis. On the optional transformed view, all
    calculations are explicitly performed on signed log10(1+|x|) values.
    """
    values = series_to_array(metrics.get(metric_key, []))
    values = values[np.isfinite(values)]
    if values.size == 0:
        return None

    original_values = values.copy()
    if use_log_scale:
        values = _signed_log10_1p(values)

    n = int(values.size)
    mean = float(np.mean(values))
    if n > 1:
        std = float(np.std(values, ddof=1))
        se = std / float(np.sqrt(n))
        critical = _forest_t_critical_95(n - 1)
        ci = critical * se
    else:
        std = 0.0
        se = float("nan")
        ci = 0.0

    return {
        "csv_name": csv_name,
        "mean": mean,
        "ci_low": mean - ci,
        "ci_high": mean + ci,
        "n": n,
        "std": std,
        "se": se,
        "scale": "signed log10(1+|x|)" if use_log_scale else "linear",
        "raw_mean": float(np.mean(original_values)),
    }


def forest_paired_difference_stats(reference_key, comparison_key, metrics, csv_name, use_log_scale=False):
    """Paired mean difference (comparison - reference) with a 95% t CI.

    Values are paired by row index. Only rows where both metrics are finite are
    retained. This is the correct within-user contrast when both metrics were
    recorded on the same observations/trials.
    """
    ref = series_to_array(metrics.get(reference_key, []))
    cmp = series_to_array(metrics.get(comparison_key, []))
    n_common = min(ref.size, cmp.size)
    if n_common <= 0:
        return None
    ref = np.asarray(ref[:n_common], dtype=float)
    cmp = np.asarray(cmp[:n_common], dtype=float)
    valid = np.isfinite(ref) & np.isfinite(cmp)
    ref = ref[valid]
    cmp = cmp[valid]
    if ref.size < 2:
        return None
    if use_log_scale:
        ref = _signed_log10_1p(ref)
        cmp = _signed_log10_1p(cmp)
    differences = cmp - ref
    n = int(differences.size)
    mean = float(np.mean(differences))
    std = float(np.std(differences, ddof=1))
    se = std / float(np.sqrt(n))
    critical = _forest_t_critical_95(n - 1)
    ci = critical * se
    return {
        "csv_name": csv_name,
        "mean": mean,
        "ci_low": mean - ci,
        "ci_high": mean + ci,
        "n": n,
        "std": std,
        "se": se,
        "scale": "paired signed-log difference" if use_log_scale else "paired difference",
    }


def _forest_metric_observations(metric_key, metrics):
    """Build comparable per-minute observations for the G2 forest plot.

    Raw logger rows are event-driven and irregularly spaced, so a mean per CSV
    row is not comparable between sessions. Event/change metrics are therefore
    aggregated into one-minute bins. Occlusion becomes time-weighted % per bin.
    """
    values = series_to_array(metrics.get(metric_key, []))
    times = series_to_array(metrics.get("A1", []))
    n = min(values.size, times.size) if times.size else values.size
    if n <= 0:
        return np.asarray([], dtype=float)

    values = np.asarray(values[:n], dtype=float)
    if times.size:
        times = np.asarray(times[:n], dtype=float)
    else:
        times = np.arange(n, dtype=float)

    valid = np.isfinite(values) & np.isfinite(times)
    values, times = values[valid], times[valid]
    if values.size == 0:
        return np.asarray([], dtype=float)

    # Continuous quantities keep their original per-observation distributions.
    if metric_key not in {"A6","A10","A11","A12","A13","A15","A16","A17","A18","A19"}:
        return values

    duration = max(float(times[-1]) if times.size else 0.0, 1e-9)
    bin_count = max(1, int(np.ceil(duration)))
    edges = np.arange(bin_count + 1, dtype=float)
    if edges[-1] < duration:
        edges = np.append(edges, duration)

    if metric_key in {"A17", "A19"}:
        out = []
        for b in range(len(edges) - 1):
            left, right = edges[b], edges[b + 1]
            active = 0.0
            total = 0.0
            for i in range(max(0, len(times) - 1)):
                seg_l, seg_r = float(times[i]), float(times[i + 1])
                overlap = max(0.0, min(seg_r, right) - max(seg_l, left))
                if overlap > 0:
                    total += overlap
                    if values[i] >= 0.5:
                        active += overlap
            if total > 0:
                out.append(100.0 * active / total)
        return np.asarray(out, dtype=float)

    # Event/change metrics: sum each minute. A6-A10/A15 are non-negative events;
    # A11-A13/A16 preserve sign, so each bin is a true net change/min.
    bins = np.zeros(max(1, len(edges) - 1), dtype=float)
    for tm, value in zip(times, values):
        b = min(max(int(np.floor(max(tm, 0.0))), 0), bins.size - 1)
        bins[b] += float(value)
    return bins


def forest_zscore_reference(metric_key, metrics_by_csv, use_log_scale=False):
    """Return the reference distribution of user-level means for one metric.

    Every CSV/user contributes one mean, regardless of how many observations it
    contains. Standardising user means (rather than pooling every raw sample)
    prevents long sessions from dominating the reference and avoids shrinking
    all displayed effects towards zero.
    """
    user_means = []
    user_ns = []
    for metrics in metrics_by_csv:
        values = _forest_metric_observations(metric_key, metrics)
        values = values[np.isfinite(values)]
        if use_log_scale and values.size:
            values = _signed_log10_1p(values)
        if values.size:
            user_means.append(float(np.mean(values)))
            user_ns.append(int(values.size))
    if len(user_means) < 2:
        return None
    means = np.asarray(user_means, dtype=float)
    mean = float(np.mean(means))
    std = float(np.std(means, ddof=1))
    if not np.isfinite(std) or std <= 1e-12:
        return None
    return {
        "metric_key": metric_key,
        "mean": mean,
        "std": std,
        "n_total": int(len(user_means)),
        "observation_count": int(sum(user_ns)),
    }


def forest_zscore_row_stats(metric_key, metrics, csv_name, reference_mean, reference_std, use_log_scale=False):
    """Return a descriptive user-mean z-score with autocorrelation-adjusted CI.

    Consecutive interaction samples are usually serially correlated. Treating
    every CSV row as independent would make confidence intervals unrealistically
    narrow. We therefore estimate a lag-1 effective sample size and use it for
    the standard error and Student-t degrees of freedom. This remains a
    descriptive approximation, not proof that the raw metric is normally
    distributed.
    """
    values = _forest_metric_observations(metric_key, metrics)
    values = values[np.isfinite(values)]
    if values.size < 3:
        return None
    if not np.isfinite(reference_std) or abs(float(reference_std)) <= 1e-12:
        return None

    original_values = values.copy()
    if use_log_scale:
        values = _signed_log10_1p(values)

    n_raw = int(values.size)
    raw_mean = float(np.mean(values))
    raw_std = float(np.std(values, ddof=1))
    if not np.isfinite(raw_std) or raw_std <= 1e-15:
        return None

    # Lag-1 autocorrelation. Clamp negative correlation to zero so that the
    # effective sample size never exceeds the observed number of rows.
    x0 = values[:-1] - float(np.mean(values[:-1]))
    x1 = values[1:] - float(np.mean(values[1:]))
    denom = float(np.sqrt(np.sum(x0 * x0) * np.sum(x1 * x1)))
    rho1 = float(np.sum(x0 * x1) / denom) if denom > 1e-15 else 0.0
    rho1 = min(max(rho1, 0.0), 0.99)
    n_eff = float(n_raw * (1.0 - rho1) / (1.0 + rho1))
    n_eff = min(float(n_raw), max(2.0, n_eff))

    raw_se = raw_std / float(np.sqrt(n_eff))
    mean = (raw_mean - float(reference_mean)) / float(reference_std)
    se = raw_se / float(reference_std)
    if not np.isfinite(se) or se <= 0.0:
        return None

    df_eff = max(1, int(np.floor(n_eff)) - 1)
    critical = _forest_t_critical_95(df_eff)
    ci = critical * se
    return {
        "csv_name": csv_name,
        "mean": float(mean),
        "ci_low": float(mean - ci),
        "ci_high": float(mean + ci),
        "n": n_raw,
        "n_eff": n_eff,
        "rho1": rho1,
        "std": float(raw_std / reference_std),
        "se": float(se),
        "scale": "descriptive z-score of signed log10(1+|x|) user mean" if use_log_scale else "descriptive z-score of user mean",
        "raw_mean": raw_mean,
        "raw_untransformed_mean": float(np.mean(original_values)),
        "raw_std": raw_std,
        "reference_mean": float(reference_mean),
        "reference_std": float(reference_std),
    }

# Herramientas para la monitorización y análisis de procesos de modelado 3D en Blender
# Copyright (C) 2026 María Molina Goyena
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# at your option any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.

import os
import re
import json
import bpy
import numpy as np
from bpy.props import CollectionProperty, StringProperty, IntProperty

from .ui_helpers import *
from .ui_properties import *
from .ui_graph_service import visualize_graph
from .texts import UI_TEXT, tr, wrap_lines, region_character_width

class ANALI_OT_SelectCSVPath(bpy.types.Operator):
    """Open the file selector to choose a folder or a specific CSV.

    If a CSV is selected, the working folder is updated, the list is refreshed,
    and only that file is selected. If a folder is selected, all compatible CSV
    files inside it are scanned.
    """
    bl_idname = "anali.select_csv_path"
    bl_label = UI_TEXT['SELECT_FOLDER_OR_CSV']
    bl_description = UI_TEXT['SELECT_A_FOLDER_OR_CSV_AND_UPDATE_THE_ANALYZABLE_FILE_LIST']

    @classmethod
    def description(cls, context, properties):
        if context is not None and getattr(context, "scene", None) is not None:
            return tr(context.scene, cls.bl_description)
        return cls.bl_description

    filepath: StringProperty(subtype="FILE_PATH")
    directory: StringProperty(subtype="DIR_PATH")
    filename: StringProperty()
    filter_glob: StringProperty(default="*.csv", options={'HIDDEN'})

    def execute(self, context):
        scn = context.scene
        path = bpy.path.abspath(self.filepath or self.directory)
        if os.path.isfile(path) and path.lower().endswith('.csv'):
            scn.csv_folder = os.path.dirname(path)
            bpy.ops.anali.detect_csv()
            for item in scn.csv_items:
                item.selected = os.path.abspath(item.name) == os.path.abspath(path)
        else:
            scn.csv_folder = path
            bpy.ops.anali.detect_csv()
        update_csv_analysis_store(scn)
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class ANALI_OT_DetectCSV(bpy.types.Operator):
    """Scan the configured folder and rebuild the CSV list.

    Existing file selections are preserved, and the internal metric store is
    recalculated so the UI and graphs use synchronized data.
    """
    bl_idname = "anali.detect_csv"
    bl_label = UI_TEXT['SCAN_CSV']
    bl_description = UI_TEXT['FIND_CSV_FILES_IN_THE_SELECTED_FOLDER_AND_REFRESH_THE_LIST_WHILE_KEEPI']

    @classmethod
    def description(cls, context, properties):
        if context is not None and getattr(context, "scene", None) is not None:
            return tr(context.scene, cls.bl_description)
        return cls.bl_description

    def execute(self, context):
        scn = context.scene
        prev_state = {item.name: item.selected for item in scn.csv_items}
        scn.csv_items.clear()
        for path in detect_csvs(scn.csv_folder):
            item = scn.csv_items.add()
            item.name = path
            item.selected = prev_state.get(path, False)
        update_csv_analysis_store(scn)
        self.report({'INFO'}, f"{len(scn.csv_items)} {tr(scn, UI_TEXT['CSV_FILES_DETECTED'])}")
        return {'FINISHED'}




class ANALI_OT_CreateCSVGroup(bpy.types.Operator):
    bl_idname = "anali.create_csv_group"
    bl_label = UI_TEXT['CREATE_CSV_GROUP']
    bl_description = UI_TEXT['CREATE_ONE_VIRTUAL_CSV_SOURCE_FROM_THE_CURRENTLY_SELECTED_CSV_FILES']

    group_name: StringProperty(name=UI_TEXT['GROUP_NAME'], default="CSV Group")

    @classmethod
    def description(cls, context, properties):
        return tr(context.scene, cls.bl_description) if context and getattr(context, "scene", None) else cls.bl_description

    def invoke(self, context, event):
        selected = [item for item in context.scene.csv_items if item.selected]
        if len(selected) < 2:
            self.report({'ERROR'}, tr(context.scene, UI_TEXT['SELECT_AT_LEAST_TWO_CSV_FILES_TO_CREATE_A_GROUP']))
            return {'CANCELLED'}
        return context.window_manager.invoke_props_dialog(self, width=420)

    def execute(self, context):
        scn = context.scene
        paths = [item.name for item in scn.csv_items if item.selected and os.path.isfile(item.name)]
        if len(paths) < 2:
            self.report({'ERROR'}, tr(scn, UI_TEXT['SELECT_AT_LEAST_TWO_CSV_FILES_TO_CREATE_A_GROUP']))
            return {'CANCELLED'}
        name = (self.group_name or "CSV Group").strip()
        existing = {group.name for group in scn.csv_groups}
        base = name
        suffix = 2
        while name in existing:
            name = f"{base} {suffix}"
            suffix += 1
        group = scn.csv_groups.add()
        group.name = name
        group.member_paths = json.dumps(paths, ensure_ascii=False)
        group.selected = True
        scn.csv_group_index = len(scn.csv_groups) - 1
        for item in scn.csv_items:
            if item.name in paths:
                item.selected = False
        update_csv_analysis_store(scn)
        self.report({'INFO'}, tr(scn, UI_TEXT['CSV_GROUP_CREATED']))
        return {'FINISHED'}


class ANALI_OT_RemoveCSVGroup(bpy.types.Operator):
    bl_idname = "anali.remove_csv_group"
    bl_label = UI_TEXT['REMOVE_CSV_GROUP']
    bl_description = UI_TEXT['REMOVE_THE_SELECTED_CSV_GROUP_WITHOUT_DELETING_ITS_SOURCE_FILES']

    @classmethod
    def description(cls, context, properties):
        return tr(context.scene, cls.bl_description) if context and getattr(context, "scene", None) else cls.bl_description

    def execute(self, context):
        scn = context.scene
        index = int(getattr(scn, "csv_group_index", -1))
        if index < 0 or index >= len(scn.csv_groups):
            self.report({'ERROR'}, tr(scn, UI_TEXT['NO_CSV_GROUP_SELECTED']))
            return {'CANCELLED'}
        scn.csv_groups.remove(index)
        scn.csv_group_index = min(max(0, index - 1), max(0, len(scn.csv_groups) - 1))
        update_csv_analysis_store(scn)
        return {'FINISHED'}


class ANALI_OT_SelectCSVGroupMembers(bpy.types.Operator):
    bl_idname = "anali.select_csv_group_members"
    bl_label = UI_TEXT['SELECT_GROUP_MEMBERS']
    bl_description = UI_TEXT['SELECT_ORIGINAL_MEMBERS_HELP']

    @classmethod
    def description(cls, context, properties):
        if context is not None and getattr(context, "scene", None) is not None:
            return tr(context.scene, cls.bl_description)
        return cls.bl_description

    def execute(self, context):
        scn = context.scene
        index = int(getattr(scn, "csv_group_index", -1))
        if index < 0 or index >= len(scn.csv_groups):
            return {'CANCELLED'}
        try:
            members = set(json.loads(scn.csv_groups[index].member_paths or "[]"))
        except Exception:
            members = set()
        for item in scn.csv_items:
            item.selected = item.name in members
        scn.csv_groups[index].selected = False
        update_csv_analysis_store(scn)
        return {'FINISHED'}


class ANALI_OT_ContextHelp(bpy.types.Operator):
    """Display long contextual help in a responsive dialog."""
    bl_idname = "anali.context_help"
    bl_label = UI_TEXT['CONTEXT_HELP']
    bl_description = UI_TEXT['OPEN_DETAILED_CONTEXTUAL_HELP']

    title: StringProperty(default="")
    message: StringProperty(default="")
    dialog_width: IntProperty(default=640, options={'HIDDEN'})

    @classmethod
    def description(cls, context, properties):
        if context is not None:
            return tr(context.scene, getattr(properties, "message", "") or cls.bl_description)
        return getattr(properties, "message", "") or cls.bl_description

    def invoke(self, context, event):
        # The dialog width follows the available window width but remains usable
        # on small screens. Text is wrapped again on every draw call.
        region_width = getattr(context.region, "width", 420)
        window_width = getattr(context.window, "width", region_width)
        dialog_width = max(420, min(720, int(max(region_width, window_width * 0.45))))
        self.dialog_width = dialog_width
        return context.window_manager.invoke_props_dialog(
            self,
            width=dialog_width,
            title=tr(context.scene, self.title or UI_TEXT['CONTEXT_HELP']),
        )

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        title = tr(scene, self.title or UI_TEXT['CONTEXT_HELP'])
        text = tr(scene, self.message or self.bl_description)

        # Match the Data Logger long-help style: a clear title followed by
        # separate boxed paragraphs whose contents wrap to the available UI.
        # Existing long-help strings may use either explicit newlines or the
        # standard Controls / Result / Requirements markers.
        for marker in (
            " Controls:", " Result:", " Requirements and notes:",
            " Controles:", " Resultado:", " Requisitos y notas:",
        ):
            text = text.replace(marker, "\n\n" + marker.strip())

        paragraphs = [part.strip() for part in text.splitlines() if part.strip()]
        if not paragraphs:
            paragraphs = [text]

        for paragraph in paragraphs:
            box = layout.box()
            col = box.column(align=True)
            col.scale_y = 0.9
            # Wrap against the popup itself, not the underlying 3D View region.
            # Using context.region here makes text overflow when the viewport is wide.
            chars = max(38, min(88, int((self.dialog_width - 70) / 7.2)))
            for line in wrap_lines(context, paragraph, width=chars):
                col.label(text=line)

    def execute(self, context):
        return {'FINISHED'}


class ANALI_OT_ContextHelpES(bpy.types.Operator):
    """Display long contextual help in a responsive dialog."""
    bl_idname = "anali.context_help_es"
    bl_label = "Ayuda contextual"
    bl_description = UI_TEXT['OPEN_DETAILED_CONTEXTUAL_HELP']

    title: StringProperty(default="")
    message: StringProperty(default="")
    dialog_width: IntProperty(default=640, options={'HIDDEN'})

    @classmethod
    def description(cls, context, properties):
        if context is not None:
            return tr(context.scene, getattr(properties, "message", "") or cls.bl_description)
        return getattr(properties, "message", "") or cls.bl_description

    def invoke(self, context, event):
        # The dialog width follows the available window width but remains usable
        # on small screens. Text is wrapped again on every draw call.
        region_width = getattr(context.region, "width", 420)
        window_width = getattr(context.window, "width", region_width)
        dialog_width = max(420, min(720, int(max(region_width, window_width * 0.45))))
        self.dialog_width = dialog_width
        return context.window_manager.invoke_props_dialog(
            self,
            width=dialog_width,
            title=tr(context.scene, self.title or UI_TEXT['CONTEXT_HELP']),
        )

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        title = tr(scene, self.title or UI_TEXT['CONTEXT_HELP'])
        text = tr(scene, self.message or self.bl_description)

        # Match the Data Logger long-help style: a clear title followed by
        # separate boxed paragraphs whose contents wrap to the available UI.
        # Existing long-help strings may use either explicit newlines or the
        # standard Controls / Result / Requirements markers.
        for marker in (
            " Controls:", " Result:", " Requirements and notes:",
            " Controles:", " Resultado:", " Requisitos y notas:",
        ):
            text = text.replace(marker, "\n\n" + marker.strip())

        paragraphs = [part.strip() for part in text.splitlines() if part.strip()]
        if not paragraphs:
            paragraphs = [text]

        for paragraph in paragraphs:
            box = layout.box()
            col = box.column(align=True)
            col.scale_y = 0.9
            # Wrap against the popup itself, not the underlying 3D View region.
            # Using context.region here makes text overflow when the viewport is wide.
            chars = max(38, min(88, int((self.dialog_width - 70) / 7.2)))
            for line in wrap_lines(context, paragraph, width=chars):
                col.label(text=line)

    def execute(self, context):
        return {'FINISHED'}


class ANALI_OT_CalculateCSVMetricStats(bpy.types.Operator):
    """Calculate descriptive statistics for CSV metrics in selected CSV files.

    This operator only analyzes CSV interaction data. It does not modify meshes
    or invoke the model-metrics operator. It generates totals, means, rates,
    quartiles, duration in minutes, and contextual data such as speed associated
    with peaks and local object size.
    """
    bl_idname = "anali.calculate_csv_metric_stats"
    bl_label = UI_TEXT['CALCULATE_CSV_METRIC_STATS']
    bl_description = UI_TEXT['CALCULATE_CSV_METRICS_FOR_SELECTED_CSV_FILES_WITH_DESCRIPTIONS_QUARTIL']

    @classmethod
    def description(cls, context, properties):
        if context is not None and getattr(context, "scene", None) is not None:
            return tr(context.scene, cls.bl_description)
        return cls.bl_description

    def execute(self, context):
        scn = context.scene

        # Accept both individually selected CSV files and selected CSV groups.
        selected_csvs = selected_csv_sources(scn)
        if not selected_csvs:
            self.report({'WARNING'}, tr(scn, UI_TEXT['NO_CSV_SELECTED']))
            return {'CANCELLED'}

        update_scene_metric_stats(context)
        self.report({'INFO'}, tr(scn, UI_TEXT['METRIC_STATISTICS_CALCULATED']))
        return {'FINISHED'}


class OBJECT_OT_CalculateMetrics(bpy.types.Operator):
    """Calculate metrics for the mesh selected in the add-on panel.

    Requires ``scene.anali_target_obj`` to be a MESH. Results are stored in
    scene["metrics_data"] so the mesh panel can display them without
    recalculating until the user requests it again.
    """
    bl_idname = "object.calculate_metrics"
    bl_label = UI_TEXT['CALCULATE_METRICS']
    bl_description = UI_TEXT['CALCULATE_GEOMETRIC_METRICS_FOR_THE_ACTIVE_MODEL_AND_IF_AVAILABLE_COMP']

    @classmethod
    def description(cls, context, properties):
        if context is not None and getattr(context, "scene", None) is not None:
            return tr(context.scene, cls.bl_description)
        return cls.bl_description

    def execute(self, context):
        scn = context.scene
        # Always use the object explicitly selected in the panel.
        # The active/selected object in the Blender scene is intentionally ignored.
        obj = scn.anali_target_obj
        reference_obj = scn.reference_obj
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, tr(scn, UI_TEXT['SELECT_A_MESH_OBJECT']))
            return {'CANCELLED'}
        metrics = calculate_model_metrics(
            obj,
            reference_obj if reference_obj and reference_obj.type == 'MESH' else None,
            octree_max_depth=scn.anali_octree_max_depth,
            octree_max_items=scn.anali_octree_max_items,
            octree_limit_mode=scn.anali_octree_limit_mode,
            align_similarity=True,
        )
        store = dict(scn.get("metrics_data", {}))
        store[obj.name] = metrics
        scn["metrics_data"] = store
        return {'FINISHED'}





DATA_LOGGER_MESH_JSON = "data_logger_mesh_metrics.json"
DATA_LOGGER_MESH_CSV = "data_logger_mesh_metrics.csv"
_DATA_LOGGER_META_FIELDS = {
    "SavedAtUnix", "ObjectName", "Error", "schema_version", "logger_version",
    "saved_at_unix", "blend_file", "calculation_source", "source",
}


def _data_logger_scalar(value):
    """Return an ID-property-safe scalar, or None for unsupported/invalid values."""
    if isinstance(value, bool):
        return bool(value)
    if isinstance(value, (int, float)):
        number = float(value)
        if not np.isfinite(number):
            return None
        return int(value) if isinstance(value, int) else number
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    lowered = text.lower()
    if lowered in {"true", "yes", "sí", "si"}:
        return True
    if lowered in {"false", "no"}:
        return False
    try:
        number = float(text.replace(",", "."))
    except ValueError:
        return None
    return number if np.isfinite(number) else None


def _clean_data_logger_metrics(raw_metrics):
    cleaned = {}
    for key, value in dict(raw_metrics or {}).items():
        key = str(key).strip()
        if not key or key in _DATA_LOGGER_META_FIELDS or key.lower() == "similarity":
            continue
        scalar = _data_logger_scalar(value)
        if scalar is not None:
            cleaned[key] = scalar
    return cleaned


def _load_data_logger_mesh_metrics_from_blend():
    """Read Data Logger mesh metrics embedded in the current .blend.

    JSON is preferred because it preserves booleans and exact field names. The
    dedicated CSV text block is accepted as a fallback for older logger files.
    """
    json_text = bpy.data.texts.get(DATA_LOGGER_MESH_JSON)
    if json_text is not None:
        payload = json.loads(json_text.as_string() or "{}")
        objects = payload.get("objects", {}) if isinstance(payload, dict) else {}
        result = {}
        for object_name, raw_metrics in dict(objects or {}).items():
            metrics = _clean_data_logger_metrics(raw_metrics)
            if metrics:
                result[str(object_name)] = metrics
        if result:
            blend_name = os.path.basename(bpy.data.filepath) or "Unsaved.blend"
            renamed = {}
            for index, metrics in enumerate(result.values(), start=1):
                record_name = blend_name if index == 1 else f"{blend_name} ({index})"
                renamed[record_name] = metrics
            source_id = f"blend::{bpy.path.abspath(bpy.data.filepath) or '<unsaved>'}"
            return renamed, source_id

    csv_text = bpy.data.texts.get(DATA_LOGGER_MESH_CSV)
    if csv_text is not None:
        import csv
        import io
        reader = csv.DictReader(io.StringIO(csv_text.as_string()))
        result = {}
        for row in reader:
            object_name = str(row.get("ObjectName", "")).strip()
            if not object_name or str(row.get("Error", "")).strip():
                continue
            metrics = _clean_data_logger_metrics(row)
            if metrics:
                result[object_name] = metrics
        if result:
            blend_name = os.path.basename(bpy.data.filepath) or "Unsaved.blend"
            renamed = {}
            for index, metrics in enumerate(result.values(), start=1):
                record_name = blend_name if index == 1 else f"{blend_name} ({index})"
                renamed[record_name] = metrics
            source_id = f"blend::{bpy.path.abspath(bpy.data.filepath) or '<unsaved>'}"
            return renamed, source_id

    return {}, ""




def _load_data_logger_mesh_metrics_from_file(filepath):
    """Load external Data Logger metrics using the source filename as key.

    The internal ObjectName is deliberately not exposed as the observation
    name. This makes several exports distinguishable even when every logger
    file contains the generic name ``CombinedSceneMesh``.
    """
    filepath = bpy.path.abspath(filepath or "")
    if not filepath or not os.path.isfile(filepath):
        return {}, ""

    source_name = os.path.basename(filepath)
    source_id = f"file::{os.path.normcase(os.path.abspath(filepath))}"
    extension = os.path.splitext(filepath)[1].lower()
    observations = []

    if extension == ".json":
        with open(filepath, "r", encoding="utf-8-sig") as handle:
            payload = json.load(handle)
        objects = payload.get("objects", {}) if isinstance(payload, dict) else {}
        for _object_name, raw_metrics in dict(objects or {}).items():
            metrics = _clean_data_logger_metrics(raw_metrics)
            if metrics:
                observations.append(metrics)

    elif extension == ".csv":
        import csv
        with open(filepath, "r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                if str(row.get("Error", "")).strip():
                    continue
                metrics = _clean_data_logger_metrics(row)
                if metrics:
                    observations.append(metrics)
    else:
        return {}, source_id

    result = {}
    for index, metrics in enumerate(observations, start=1):
        record_name = source_name if index == 1 else f"{source_name} ({index})"
        result[record_name] = metrics
    return result, source_id


def _store_data_logger_mesh_metrics(scene, imported, source_id):
    """Accumulate one import source while preserving association identifiers.

    Existing records of the same source are updated in place. Their insertion
    order and names stay stable, so Blender dynamic enum values used by
    Data ↔ Mesh associations do not move when another file is imported.
    """
    if not imported:
        return 0

    store = dict(scene.get("metrics_data", {}))
    try:
        source_records = json.loads(scene.get("data_logger_mesh_source_records", "{}") or "{}")
        if not isinstance(source_records, dict):
            source_records = {}
    except Exception:
        source_records = {}

    previous_names = [str(name) for name in source_records.get(source_id, [])]
    imported_items = list(imported.items())
    stored_names = []
    renamed = {}

    # Update existing slots first. Assigning to an existing dictionary key does
    # not change its insertion position, which keeps enum ordering stable.
    shared_count = min(len(previous_names), len(imported_items))
    for index in range(shared_count):
        old_name = previous_names[index]
        _requested_name, metrics = imported_items[index]
        if old_name in store:
            store[old_name] = metrics
            final_name = old_name
        else:
            # Recover gracefully if an older version removed the stored record.
            final_name = old_name
            store[final_name] = metrics
        stored_names.append(final_name)

    # Remove obsolete extra observations from this source and clear only the
    # associations that referenced those records.
    obsolete_names = previous_names[len(imported_items):]
    for old_name in obsolete_names:
        store.pop(old_name, None)
        for pair in getattr(scene, "anali_data_mesh_pairs", []):
            try:
                if str(getattr(pair, "mesh_record", "") or "") == old_name:
                    pair.mesh_record = "__NONE__"
            except Exception:
                pass

    # Add new observations after all existing records. Names from other sources
    # are protected, while records already owned by this source keep their name.
    protected_names = set(store.keys())
    for requested_name, metrics in imported_items[shared_count:]:
        base_name = str(requested_name)
        final_name = base_name
        suffix = 2
        while final_name in protected_names:
            final_name = f"{base_name} [{suffix}]"
            suffix += 1
        store[final_name] = metrics
        protected_names.add(final_name)
        stored_names.append(final_name)

    source_records[source_id] = stored_names
    all_imported_names = [
        str(name)
        for names in source_records.values()
        if isinstance(names, list)
        for name in names
    ]
    
    scene["metrics_data"] = store
    scene["data_logger_mesh_source"] = source_id
    scene["data_logger_mesh_count"] = len(all_imported_names)
    scene["data_logger_mesh_names"] = json.dumps(all_imported_names, ensure_ascii=False)
    scene["data_logger_mesh_source_records"] = json.dumps(source_records, ensure_ascii=False)
    return len(stored_names)


def _redraw_analysis_ui(context):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return
    for window in window_manager.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            area.tag_redraw()


class ANALI_OT_SelectDataLoggerMeshMetricsFile(bpy.types.Operator):
    """Select and immediately import one or more external mesh-metric files."""
    bl_idname = "anali.select_data_logger_mesh_metrics_file"
    bl_label = UI_TEXT['SELECT_DATA_LOGGER_MESH_METRICS_FILES']
    bl_description = UI_TEXT['SELECT_ONE_OR_MORE_JSON_OR_CSV_FILES_AND_IMPORT_THEIR_MODEL_OBSERVATIO']

    filepath: StringProperty(subtype="FILE_PATH")
    directory: StringProperty(subtype="DIR_PATH")
    files: CollectionProperty(type=bpy.types.OperatorFileListElement)
    filter_glob: StringProperty(default="*.json;*.csv", options={'HIDDEN'})

    @classmethod
    def description(cls, context, properties):
        if context is not None and getattr(context, "scene", None) is not None:
            return tr(context.scene, cls.bl_description)
        return cls.bl_description

    def execute(self, context):
        directory = bpy.path.abspath(self.directory or "")
        selected_paths = []
        for file_item in self.files:
            name = str(getattr(file_item, "name", "") or "").strip()
            if name:
                selected_paths.append(os.path.join(directory, name))

        # Blender may provide only filepath when a single file is chosen.
        if not selected_paths:
            path = bpy.path.abspath(self.filepath or "")
            if path:
                selected_paths.append(path)

        valid_paths = []
        for path in selected_paths:
            path = bpy.path.abspath(path)
            if os.path.isfile(path) and os.path.splitext(path)[1].lower() in {".json", ".csv"}:
                valid_paths.append(path)

        if not valid_paths:
            self.report({'ERROR'}, tr(context.scene, UI_TEXT['SELECT_ONE_OR_MORE_VALID_JSON_OR_CSV_DATA_LOGGER_MESH_METRICS_FILES']))
            return {'CANCELLED'}

        imported_files = 0
        imported_observations = 0
        errors = []
        for path in valid_paths:
            try:
                imported, source_id = _load_data_logger_mesh_metrics_from_file(path)
                if not imported:
                    errors.append(os.path.basename(path))
                    continue
                imported_observations += _store_data_logger_mesh_metrics(context.scene, imported, source_id)
                imported_files += 1
                context.scene.anali_data_logger_mesh_file = path
            except Exception as exc:
                errors.append(f"{os.path.basename(path)}: {exc}")

        _redraw_analysis_ui(context)
        if imported_files <= 0:
            detail = "; ".join(errors[:3])
            message = tr(context.scene, UI_TEXT['NO_DATA_LOGGER_MESH_METRICS_WERE_FOUND_IN_THE_SELECTED_FILES'])
            self.report({'ERROR'}, f"{message}: {detail}" if detail else message)
            return {'CANCELLED'}

        message = (
            f"{tr(context.scene, UI_TEXT['IMPORTED_MESH_FILES'])}: {imported_files} · "
            f"{tr(context.scene, UI_TEXT['IMPORTED_MESH_OBSERVATIONS'])}: {imported_observations}"
        )
        if errors:
            message += f" · {tr(context.scene, UI_TEXT['SKIPPED_FILES'])}: {len(errors)}"
        self.report({'INFO'}, message)
        return {'FINISHED'}

    def invoke(self, context, event):
        current = bpy.path.abspath(getattr(context.scene, "anali_data_logger_mesh_file", "") or "")
        if current:
            self.filepath = current
            self.directory = os.path.dirname(current)
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class ANALI_OT_ImportDataLoggerMeshMetrics(bpy.types.Operator):
    """Load embedded Data Logger mesh observations into Analysis 3D."""
    bl_idname = "anali.import_data_logger_mesh_metrics"
    bl_label = UI_TEXT['IMPORT_DATA_LOGGER_MESH_METRICS']
    bl_description = UI_TEXT['USE_THE_MODEL_METRICS_EMBEDDED_BY_DATA_LOGGER_3D_FOR_TABLES_AND_GRAPHS']

    @classmethod
    def description(cls, context, properties):
        if context is not None and getattr(context, "scene", None) is not None:
            return tr(context.scene, cls.bl_description)
        return cls.bl_description

    def execute(self, context):
        # This button always imports only the Data Logger text blocks embedded
        # in the currently open .blend. External JSON/CSV files are handled by
        # the Select button, which supports selecting several files at once.
        try:
            imported, source_id = _load_data_logger_mesh_metrics_from_blend()
        except Exception as exc:
            self.report({'ERROR'}, f"{tr(context.scene, UI_TEXT['DATA_LOGGER_MESH_DATA_COULD_NOT_BE_READ'])}: {exc}")
            return {'CANCELLED'}

        if not imported:
            self.report({'WARNING'}, tr(context.scene, UI_TEXT['NO_DATA_LOGGER_MESH_METRICS_WERE_FOUND_IN_THIS_BLEND_FILE']))
            return {'CANCELLED'}

        # Replace only observations with matching names. Calculated records for
        # other scene meshes remain available alongside imported observations.
        count = _store_data_logger_mesh_metrics(context.scene, imported, source_id)
        _redraw_analysis_ui(context)
        blend_name = os.path.basename(bpy.data.filepath) or "Unsaved.blend"
        self.report({'INFO'}, f"{tr(context.scene, UI_TEXT['IMPORTED_MESH_OBSERVATIONS'])}: {count} · {blend_name}")
        return {'FINISHED'}


class ANALI_OT_ClearGraphs(bpy.types.Operator):
    """Remove the 3D graphs generated by the add-on in the current scene.

    This does not delete CSV files, calculated metrics, or user objects outside
    the visualization layer generated by the add-on.
    """
    bl_idname = "anali.clear_graphs"
    bl_label = UI_TEXT['CLEAR_GRAPHS']
    bl_description = UI_TEXT['CLEAR_THE_3D_GRAPHS_GENERATED_BY_THE_ADD_ON_FROM_THE_SCENE']

    @classmethod
    def description(cls, context, properties):
        if context is not None and getattr(context, "scene", None) is not None:
            return tr(context.scene, cls.bl_description)
        return cls.bl_description

    def execute(self, context):
        clear_previous_graphs(context.scene)
        return {'FINISHED'}


class ANALI_OT_RestoreSceneObjects(bpy.types.Operator):
    """Show objects hidden while inspecting graphs."""
    bl_idname = "anali.restore_scene_objects"
    bl_label = UI_TEXT['RESTORE_SCENE_OBJECTS']
    bl_description = UI_TEXT['UNHIDE_MODELS_AND_OTHER_SCENE_OBJECTS_HIDDEN_BY_GRAPH_VISUALIZATION']

    @classmethod
    def description(cls, context, properties):
        if context is not None and getattr(context, "scene", None) is not None:
            return tr(context.scene, cls.bl_description)
        return cls.bl_description

    def execute(self, context):
        restore_hidden_scene_objects(context.scene, context=context)
        self.report({'INFO'}, tr(context.scene, UI_TEXT['HIDDEN_SCENE_OBJECTS_RESTORED']))
        return {'FINISHED'}


class ANALI_OT_G1ChangeWindow(bpy.types.Operator):
    """Move G1 backward or forward by one complete data window."""
    bl_idname = "anali.g1_change_window"
    bl_label = UI_TEXT['CHANGE_INTERACTION_GRAPH_WINDOW']
    bl_description = UI_TEXT['MOVE_TO_THE_PREVIOUS_OR_NEXT_G1_DATA_WINDOW_AND_REDRAW_THE_GRAPH']

    direction: EnumProperty(
        items=(('PREV', 'Previous', 'Previous data window'), ('NEXT', 'Next', 'Next data window')),
        default='NEXT',
    )

    @classmethod
    def description(cls, context, properties):
        scene = getattr(context, "scene", None) if context is not None else None
        direction = getattr(properties, "direction", "NEXT")
        label = "Previous data window" if direction == "PREV" else "Next data window"
        return tr(scene, label) if scene is not None else label

    def execute(self, context):
        scn = context.scene
        total = max(1, int(getattr(scn, 'anali_g1_last_total_rows', 1)))
        percentage = min(100.0, max(1.0, float(getattr(scn, 'anali_g1_window_size', 20.0))))
        size = max(1, min(total, int(__import__('math').ceil(total * percentage / 100.0))))
        old_start = max(0, int(getattr(scn, 'anali_g1_window_start', 0)))
        old_global = bool(getattr(scn, 'anali_g1_global_view', True))
        max_start = max(0, total - size)
        if self.direction == 'PREV':
            if old_global:
                return {'FINISHED'}
            if old_start <= 0:
                scn.anali_g1_global_view = True
                scn.anali_g1_window_start = 0
            else:
                scn.anali_g1_window_start = max(0, old_start - size)
        else:
            if old_global:
                scn.anali_g1_global_view = False
                scn.anali_g1_window_start = 0
            elif old_start < max_start:
                scn.anali_g1_window_start = min(max_start, old_start + size)
            else:
                # Already on the final valid window. Do not create an empty page.
                return {'FINISHED'}
        result = visualize_graph(context, self.report)
        if result == {'CANCELLED'}:
            scn.anali_g1_window_start = old_start
            scn.anali_g1_global_view = old_global
        return result

class ANALI_OT_VisualizeGraph(bpy.types.Operator):
    """Generate the selected 3D visualization from the active CSV metrics.

    Logic is delegated to ui_graph_service.visualize_graph so this operator
    stays as a thin Blender layer: it validates context, runs generation, and
    returns status messages to the user.
    """
    bl_idname = "anali.visualize_graph"
    bl_label = UI_TEXT['VISUALIZE_GRAPH']
    bl_description = UI_TEXT['CREATE_THE_CONFIGURED_3D_GRAPH_USING_THE_SELECTED_CSV_FILES_AND_METRIC']

    @classmethod
    def description(cls, context, properties):
        if context is not None and getattr(context, "scene", None) is not None:
            return tr(context.scene, cls.bl_description)
        return cls.bl_description

    def execute(self, context):
        return visualize_graph(context, self.report)

class ANALI_OT_VisualizeTable(bpy.types.Operator):
    """Create a paginated 3D table from the selected CSV metrics."""
    bl_idname = "anali.visualize_table"
    bl_label = UI_TEXT['VISUALIZE_DATA_TABLE']
    bl_description = UI_TEXT['CREATE_A_READABLE_3D_DATA_TABLE_FROM_THE_SELECTED_CSV_FILES_AND_METRIC']

    @classmethod
    def description(cls, context, properties):
        if context is not None and getattr(context, "scene", None) is not None:
            return tr(context.scene, cls.bl_description)
        return cls.bl_description

    def execute(self, context):
        from .ui_table_service import generate_data_table
        return generate_data_table(context, self.report)


class ANALI_OT_ClearTables(bpy.types.Operator):
    """Remove generated 3D data tables without touching user objects."""
    bl_idname = "anali.clear_tables"
    bl_label = UI_TEXT['CLEAR_DATA_TABLES']
    bl_description = UI_TEXT['REMOVE_THE_3D_DATA_TABLES_GENERATED_BY_THE_ADD_ON']

    @classmethod
    def description(cls, context, properties):
        if context is not None and getattr(context, "scene", None) is not None:
            return tr(context.scene, cls.bl_description)
        return cls.bl_description

    def execute(self, context):
        from .ui_table_service import clear_data_tables
        clear_data_tables(context.scene)
        return {'FINISHED'}


class ANALI_OT_TableChangePage(bpy.types.Operator):
    """Move through row or metric pages and redraw the current table."""
    bl_idname = "anali.table_change_page"
    bl_label = UI_TEXT['CHANGE_TABLE_PAGE']
    bl_description = UI_TEXT['MOVE_TO_ANOTHER_TABLE_PAGE_AND_REGENERATE_THE_3D_TABLE']

    direction: EnumProperty(
        items=(
            ('ROW_PREV', 'Previous rows', ''), ('ROW_NEXT', 'Next rows', ''),
            ('COL_PREV', 'Previous metrics', ''), ('COL_NEXT', 'Next metrics', ''),
        ),
        default='ROW_NEXT',
    )

    @classmethod
    def description(cls, context, properties):
        scene = getattr(context, "scene", None) if context is not None else None
        labels = {
            'ROW_PREV': 'Previous rows',
            'ROW_NEXT': 'Next rows',
            'COL_PREV': 'Previous metrics',
            'COL_NEXT': 'Next metrics',
        }
        label = labels.get(getattr(properties, "direction", "ROW_NEXT"), 'Next rows')
        return tr(scene, label) if scene is not None else label

    def execute(self, context):
        scn = context.scene
        if self.direction == 'ROW_PREV':
            scn.anali_table_row_page = max(1, scn.anali_table_row_page - 1)
        elif self.direction == 'ROW_NEXT':
            scn.anali_table_row_page += 1
        elif self.direction == 'COL_PREV':
            scn.anali_table_col_page = max(1, scn.anali_table_col_page - 1)
        else:
            scn.anali_table_col_page += 1
        from .ui_table_service import generate_data_table
        return generate_data_table(context, self.report)


# Language-specific arrow operators keep Blender's tooltip title localized.
# The original direction-based operators remain the implementation source of truth.
class ANALI_OT_G1Prev(bpy.types.Operator):
    bl_idname = "anali.g1_prev"
    bl_label = "Previous data window"
    bl_description = "Previous data window"
    def execute(self, context):
        return bpy.ops.anali.g1_change_window(direction='PREV')

class ANALI_OT_G1PrevES(bpy.types.Operator):
    bl_idname = "anali.g1_prev_es"
    bl_label = "Ventana de datos anterior"
    bl_description = "Ventana de datos anterior"
    def execute(self, context):
        return bpy.ops.anali.g1_change_window(direction='PREV')

class ANALI_OT_G1Next(bpy.types.Operator):
    bl_idname = "anali.g1_next"
    bl_label = "Next data window"
    bl_description = "Next data window"
    def execute(self, context):
        return bpy.ops.anali.g1_change_window(direction='NEXT')

class ANALI_OT_G1NextES(bpy.types.Operator):
    bl_idname = "anali.g1_next_es"
    bl_label = "Ventana de datos siguiente"
    bl_description = "Ventana de datos siguiente"
    def execute(self, context):
        return bpy.ops.anali.g1_change_window(direction='NEXT')

class _ANALI_TableArrowBase:
    direction = 'ROW_NEXT'
    def execute(self, context):
        return bpy.ops.anali.table_change_page(direction=self.direction)

class ANALI_OT_TableRowPrev(_ANALI_TableArrowBase, bpy.types.Operator):
    bl_idname = "anali.table_row_prev"
    bl_label = "Previous rows"
    bl_description = "Previous rows"
    direction = 'ROW_PREV'

class ANALI_OT_TableRowPrevES(_ANALI_TableArrowBase, bpy.types.Operator):
    bl_idname = "anali.table_row_prev_es"
    bl_label = "Filas anteriores"
    bl_description = "Filas anteriores"
    direction = 'ROW_PREV'

class ANALI_OT_TableRowNext(_ANALI_TableArrowBase, bpy.types.Operator):
    bl_idname = "anali.table_row_next"
    bl_label = "Next rows"
    bl_description = "Next rows"
    direction = 'ROW_NEXT'

class ANALI_OT_TableRowNextES(_ANALI_TableArrowBase, bpy.types.Operator):
    bl_idname = "anali.table_row_next_es"
    bl_label = "Filas siguientes"
    bl_description = "Filas siguientes"
    direction = 'ROW_NEXT'

class ANALI_OT_TableColPrev(_ANALI_TableArrowBase, bpy.types.Operator):
    bl_idname = "anali.table_col_prev"
    bl_label = "Previous metrics"
    bl_description = "Previous metrics"
    direction = 'COL_PREV'

class ANALI_OT_TableColPrevES(_ANALI_TableArrowBase, bpy.types.Operator):
    bl_idname = "anali.table_col_prev_es"
    bl_label = "Métricas anteriores"
    bl_description = "Métricas anteriores"
    direction = 'COL_PREV'

class ANALI_OT_TableColNext(_ANALI_TableArrowBase, bpy.types.Operator):
    bl_idname = "anali.table_col_next"
    bl_label = "Next metrics"
    bl_description = "Next metrics"
    direction = 'COL_NEXT'

class ANALI_OT_TableColNextES(_ANALI_TableArrowBase, bpy.types.Operator):
    bl_idname = "anali.table_col_next_es"
    bl_label = "Métricas siguientes"
    bl_description = "Métricas siguientes"
    direction = 'COL_NEXT'


class ANALI_OT_AddDataMeshPair(bpy.types.Operator):
    """Add an editable association between a data file and a calculated model."""
    bl_idname = "anali.add_data_mesh_pair"
    bl_label = UI_TEXT['ADD_DATA_MESH_PAIR']
    bl_description = UI_TEXT['ADD_A_ROW_THAT_ASSOCIATES_ONE_DATA_FILE_WITH_ONE_CALCULATED_MODEL']

    @classmethod
    def description(cls, context, properties):
        return tr(context.scene, cls.bl_description) if context and getattr(context, "scene", None) else cls.bl_description

    def execute(self, context):
        scn = context.scene
        item = scn.anali_data_mesh_pairs.add()
        selected = [entry.name for entry in scn.csv_items if entry.selected]
        candidates = selected or [entry.name for entry in scn.csv_items]
        if candidates:
            item.data_path = candidates[min(len(scn.anali_data_mesh_pairs)-1, len(candidates)-1)]
        mesh_names = [str(name) for name in dict(scn.get("metrics_data", {})).keys()]
        if mesh_names:
            selected_name = mesh_names[min(len(scn.anali_data_mesh_pairs)-1, len(mesh_names)-1)]
            try:
                item.mesh_record = selected_name
            except Exception:
                pass
            legacy_obj = bpy.data.objects.get(selected_name)
            if legacy_obj is not None and legacy_obj.type == 'MESH':
                item.mesh_object = legacy_obj
        scn.anali_data_mesh_pair_index = max(0, len(scn.anali_data_mesh_pairs)-1)
        return {'FINISHED'}


class ANALI_OT_RemoveDataMeshPair(bpy.types.Operator):
    """Remove the selected data-model association."""
    index: bpy.props.IntProperty(default=-1, options={'HIDDEN'})
    bl_idname = "anali.remove_data_mesh_pair"
    bl_label = UI_TEXT['REMOVE_DATA_MESH_PAIR']
    bl_description = UI_TEXT['REMOVE_THE_SELECTED_ASSOCIATION_BETWEEN_A_DATA_FILE_AND_A_MODEL']

    @classmethod
    def description(cls, context, properties):
        return tr(context.scene, cls.bl_description) if context and getattr(context, "scene", None) else cls.bl_description

    def execute(self, context):
        scn = context.scene
        if not scn.anali_data_mesh_pairs:
            return {'CANCELLED'}
        requested = int(self.index) if int(self.index) >= 0 else int(scn.anali_data_mesh_pair_index)
        index = min(max(requested, 0), len(scn.anali_data_mesh_pairs)-1)
        scn.anali_data_mesh_pairs.remove(index)
        scn.anali_data_mesh_pair_index = min(index, max(0, len(scn.anali_data_mesh_pairs)-1))
        return {'FINISHED'}

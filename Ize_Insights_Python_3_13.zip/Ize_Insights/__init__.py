# Tools for monitoring and analysing 3D modelling workflows in Blender
# Copyright (C) 2026 María Molina Goyena
# SPDX-License-Identifier: GPL-3.0-or-later

bl_info = {
    "name": "Ize Insights",
    "author": "María",
    "version": (1, 3, 0),
    "blender": (4, 0, 0),
    "location": "3D View > Sidebar > Ize Insights",
    "description": "Advanced data analysis system with automatic metrics and 3D visualization",
    "category": "3D View",
}

try:
    import bpy
except ModuleNotFoundError:
    bpy = None

from . import dependency_ui
from .dependencies import add_local_site_packages, missing_dependencies, prepare_addon_installation

_missing = None
_full_modules = None


def _get_missing_dependencies():
    global _missing
    if _missing is None:
        _missing = missing_dependencies(force=True)
    return _missing


def _load_full_modules():
    global _full_modules
    if _full_modules is None:
        add_local_site_packages()
        from . import utils, graphs, ui
        _full_modules = (utils, graphs, ui)
    return _full_modules


def register():
    if bpy is None:
        raise RuntimeError("Ize Insights can only be registered inside Blender.")

    prepare_addon_installation()
    missing = _get_missing_dependencies()
    if missing:
        dependency_ui.register_bootstrap()
        print(f"[Ize Insights] Missing bundled dependencies: {missing}")
        return

    utils, graphs, ui = _load_full_modules()
    utils.register()
    graphs.register()
    ui.register()


def unregister():
    if bpy is None:
        return

    if _get_missing_dependencies():
        dependency_ui.unregister_bootstrap()
        return

    if _full_modules is not None:
        utils, graphs, ui = _full_modules
        ui.unregister()
        graphs.unregister()
        utils.unregister()
    if hasattr(bpy.types.Scene, "reference_obj"):
        del bpy.types.Scene.reference_obj

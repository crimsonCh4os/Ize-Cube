# Herramientas para la monitorización y análisis de procesos de modelado 3D en Blender
# Copyright (C) 2026 María Molina Goyena
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# at your option any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.

import bpy
import json
import math

from .ui_helpers import *
from .ui_properties import *
from .texts import UI_TEXT, tr, get_language, region_character_width, wrap_lines, label_value_lines


_CORR_MODEL_METRICS = [
    ("N_faces", "Polygon count"),
    ("N_meshes", "Mesh count"),
    ("Face_by_mesh", "Polygon per mesh"),
    ("Angle", "Mean edge angle"),
    ("Non_quads", "Non-quad polygon count"),
    ("Non_quads_percentage", "Non-quad polygon percentage"),
    ("Vertex_duplicate", "Duplicate vertices count"),
    ("Vertex_duplicate_percentage", "Duplicate vertices percentage"),
    ("Non_manifold", "Non-manifold vertex count"),
    ("Non_manifold_percentage", "Non-manifold vertex percentage"),
    ("Normal_count", "Inverted polygon normal count"),
    ("Normal_percentage", "Inverted polygon normal percentage"),
    ("UV_area", "UV coverage"),
    ("UV_islands", "Island count"),
    ("UV_stretch", "UV stretch percentage"),
    ("UV_textel_density", "Texel density deviation"),
    ("Transformations", "Transforms applied"),
    ("Position", "World origin alignment"),
    ("Similarity", "Similarity vs. Reference"),
]

# Canonical user-facing labels for the live Model Metrics panel.  Metric keys
# are storage/schema identifiers and must never leak directly into the UI.
_MODEL_METRIC_LABELS = dict(_CORR_MODEL_METRICS)
_MODEL_METRIC_LABELS["Surface_area_3D"] = "3D surface area"

class ANALI_UL_CSVList(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "selected", text="")
        row.label(text=os.path.basename(item.name))


class ANALI_UL_CSVGroupList(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "selected", text="")
        row.label(text=item.name, icon='GROUP')
        try:
            count = len(json.loads(item.member_paths or "[]"))
        except Exception:
            count = 0
        row.label(text=str(count))


class ANALI_UL_AnalysisList(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "enabled", text=tr(context.scene, item.label))
        row.label(text=f"[{tr(context.scene, item.typology)}]")

def _context_help_id(scn):
    """Use an operator whose RNA label matches the add-on language."""
    return "anali.context_help_es" if get_language(scn) == "ES" else "anali.context_help"


class ANALI_PT_MainPanel(bpy.types.Panel):
    bl_label = UI_TEXT['IZE_INSIGHTS']
    bl_category = "Ize Insights"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'

    def draw_header_preset(self, context):
        scn = context.scene
        op = self.layout.operator(_context_help_id(scn), text="", icon='INFO', emboss=False)
        op.title = tr(scn, UI_TEXT['INSIGHTS_DETAILED_HELP_TITLE'])
        op.message = tr(scn, UI_TEXT['INSIGHTS_DETAILED_HELP'])

    def draw(self, context):
        scn = context.scene
        layout = self.layout

        language_box = layout.box()
        language_row = language_box.row(align=True)
        language_row.label(text=tr(scn, UI_TEXT['LANGUAGE']), icon='WORLD')
        language_row.prop(scn, "anali_language", text="")

        row = layout.row(align=True)
        tab_labels = {
            'DATA': UI_TEXT['TAB_DATA'],
            'MESH': UI_TEXT['TAB_MODELS'],
            'TABLES': UI_TEXT['TAB_TABLES'],
            'GRAPHS': UI_TEXT['TAB_GRAPHS'],
        }
        for tab_id in ('DATA', 'MESH', 'TABLES', 'GRAPHS'):
            # Draw the tabs from the actual EnumProperty instead of routing
            # through wm.context_set_enum.  Blender can then expose the
            # translated enum-item description as the hover tooltip rather
            # than the generic "Set a context value" operator help.
            row.prop_enum(
                scn,
                "anali_ui_tab",
                tab_id,
                text=tr(scn, tab_labels[tab_id]),
            )

        # Top-level contextual help for the four main work areas.  Only the
        # active tab is described, keeping the tab bar compact in narrow N-panels.
        tab_help_keys = {
            'DATA': 'TAB_DATA_HELP',
            'MESH': 'TAB_MODELS_HELP',
            'TABLES': 'TAB_TABLES_HELP',
            'GRAPHS': 'TAB_GRAPHS_HELP',
        }
        active_tab = scn.anali_ui_tab if scn.anali_ui_tab in tab_help_keys else 'DATA'
        tab_help_row = layout.row(align=True)
        tab_help_split = tab_help_row.split(factor=0.88, align=True)
        tab_help_left = tab_help_split.row(align=True)
        tab_help_right = tab_help_split.row(align=True)
        tab_help_right.alignment = 'RIGHT'
        tab_help_left.label(text=tr(scn, tab_labels[active_tab]))
        tab_help = tab_help_right.operator(_context_help_id(scn), text="", icon='INFO', emboss=False)
        tab_help.title = tr(scn, tab_labels[active_tab])
        tab_help.message = tr(scn, UI_TEXT[tab_help_keys[active_tab]])

        if scn.anali_ui_tab == 'DATA':
            self._draw_data_tab(context, layout, scn)
        elif scn.anali_ui_tab == 'MESH':
            self._draw_mesh_tab(context, layout, scn)
        elif scn.anali_ui_tab == 'TABLES':
            self._draw_tables_tab(context, layout, scn)
        else:
            self._draw_graphs_tab(context, layout, scn)

    def _wrap_lines(self, context, text, width=None):
        return wrap_lines(context, text, width=width)

    def _label_wrap(self, context, layout, text, icon='NONE', width=None):
        lines = self._wrap_lines(context, text, width)
        for i, line in enumerate(lines):
            layout.label(text=line, icon=icon if i == 0 else 'NONE')

    def _context_section_header(self, parent, scn, title, help_key, icon='INFO', expanded_prop=None, help_icon='INFO'):
        """Draw one homogeneous section header throughout the add-on.

        Pattern: disclosure triangle, section icon, plain title, flexible space,
        and an INFO button that opens the long contextual explanation.
        """
        # Use a two-cell split instead of separator_spacer(). In narrow N-panels
        # Blender can place the trailing widget outside the box and draw a small
        # clipped fragment at the right edge. A bounded split keeps both cells
        # inside the available width on every panel and UI scale.
        row = parent.row(align=True)
        row.scale_y = 1.08
        split = row.split(factor=0.90, align=True)
        left = split.row(align=True)
        right = split.row(align=True)
        right.alignment = 'RIGHT'
        if expanded_prop:
            expanded = bool(getattr(scn, expanded_prop, True))
            left.prop(scn, expanded_prop, text="", icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT', emboss=False)
        left.label(text=tr(scn, title), icon=icon)
        op = right.operator(_context_help_id(scn), text="", icon=help_icon, emboss=False)
        op.title = tr(scn, title)
        op.message = tr(scn, help_key)
        return row

    def _info_box(self, context, parent, lines, icon='INFO', width=None):
        """Draw fixed explanatory text with live N-panel width wrapping."""
        ib = parent.box()
        # Rebuild one translated paragraph on every draw. This avoids three
        # independently wrapped fragments and responds correctly when the
        # sidebar is resized, opened, or closed.
        paragraph = " ".join(tr(context.scene, text).strip() for text in lines if text)
        wrapped = wrap_lines(
            context, paragraph, width=width, reserve_px=82,
        )
        for idx, line in enumerate(wrapped):
            ib.label(text=line, icon=icon if idx == 0 else 'NONE')
        return ib

    def _metric_row_wrap(self, context, parent, label, value, help_text=""):
        """Draw one metric without contextual-help icons.

        Contextual help is intentionally attached only to group titles.
        """
        col = parent.column(align=True)
        for i, line in enumerate(label_value_lines(context, tr(context.scene, label), str(value))):
            col.label(text=line, icon='DOT' if i == 0 else 'NONE')


    def _draw_toggle_collection(self, parent, scn, collection, prop_name, label_fn, columns=2):
        """Draw collection selections like the correlation metric buttons."""
        grid = parent.grid_flow(columns=columns, even_columns=True, even_rows=False, align=True)
        for item in collection:
            grid.prop(item, prop_name, text=label_fn(item), toggle=True)
        return grid

    def _draw_analysis_toggles(self, parent, scn, columns=2):
        return self._draw_toggle_collection(
            parent, scn, scn.analysis_items, "enabled",
            lambda item: f"{tr(scn, item.label)} · {tr(scn, item.typology)}",
            columns=columns,
        )

    def _graph_metric_meaning(self, scn, key, model=False):
        es = get_language(scn) == "ES"
        if model:
            meanings = {
                "UV_area": ("Área ocupada en UV; valor numérico." if es else "Occupied UV area; numeric value."),
                "UV_islands": ("Número de islas UV." if es else "Number of UV islands."),
                "UV_stretch": ("Distorsión UV; menor suele indicar menos estiramiento." if es else "UV distortion; lower usually means less stretch."),
                "UV_textel_density": ("Densidad de téxel relativa." if es else "Relative texel density."),
                "Normal_percentage": ("Porcentaje de normales invertidas; 0% es ninguna." if es else "Percentage of inverted normals; 0% means none."),
                "Transformations": ("Estado: 0 = no aplicadas; 1 = aplicadas." if es else "State: 0 = not applied; 1 = applied."),
                "Position": ("Estado: 0 = fuera del origen; 1 = en el origen global." if es else "State: 0 = away from origin; 1 = at world origin."),
                "Non_quads_percentage": ("Porcentaje de caras que no son quads." if es else "Percentage of faces that are not quads."),
                "Vertex_duplicate": ("Cantidad de vértices duplicados." if es else "Count of duplicate vertices."),
                "Vertex_duplicate_percentage": ("Porcentaje de vértices duplicados." if es else "Percentage of duplicate vertices."),
                "Non_manifold": ("Cantidad de vértices non-manifold." if es else "Count of non-manifold vertices."),
                "Non_manifold_percentage": ("Vértices non-manifold como porcentaje del total de vértices." if es else "Non-manifold vertices as a percentage of total vertices."),
                "N_faces": ("Cantidad total de caras." if es else "Total face count."),
                "N_meshes": ("Número de componentes de malla desconectados." if es else "Number of disconnected mesh components."),
                "Face_by_mesh": ("Promedio de caras por componente de malla." if es else "Average faces per mesh component."),
                "Angle": ("Ángulo medio entre caras adyacentes, en grados." if es else "Mean angle between adjacent faces, in degrees."),
                "Similarity": ("Similitud con la referencia en porcentaje; mayor = más similar." if es else "Similarity to the reference in percent; higher = more similar."),
            }
            return meanings.get(key, "")
        meanings = {
            "A1": ("Duración de sesión en minutos." if es else "Session duration in minutes."),
            "A2": ("Pausas detectadas; en series temporales el valor es duración, 0 = sin pausa." if es else "Detected pauses; in time series the value is duration, 0 = no pause."),
            "A3": ("Pausas por fase; 0 = sin pausa en esa muestra." if es else "Pauses by phase; 0 = no pause in that sample."),
            "A4": ("Velocidad de vista relativa al tamaño local; se expresa en tamaños locales por minuto." if es else "View speed relative to local size; expressed in local sizes per minute."),
            "A5": ("Distancia entre vista y objeto relativa al tamaño local; 1 equivale a un tamaño local." if es else "View-to-object distance relative to local size; 1 equals one local size."),
            "A6": ("Evento: 0 = no pico; 1 = pico detectado con velocidad de vista normalizada por el tamaño local." if es else "Event: 0 = no peak; 1 = peak detected from view speed normalized by local size."),
            "A7": ("Evento: 0 = no pico; 1 = pico de movimiento inactivo." if es else "Event: 0 = no peak; 1 = idle-movement peak."),
            "A8": ("Evento: 0 = no pico; 1 = pico de movimiento activo." if es else "Event: 0 = no peak; 1 = active-movement peak."),
            "A9": ("Evento: 0 = no pico; 1 = pico de desplazamiento." if es else "Event: 0 = no peak; 1 = travel peak."),
            "A10": ("Eventos de reutilización: Duplicar o Instanciar; en resúmenes puede mostrarse como tasa." if es else "Reuse events: Duplicate or Instance; summaries may show a rate."),
            "A11": ("Cambio de modificadores: positivo = creados, negativo = eliminados, 0 = neto sin cambio." if es else "Modifier change: positive = created, negative = removed, 0 = no net change."),
            "A12": ("Cambio de vértices: positivo = añadidos, negativo = eliminados." if es else "Vertex change: positive = added, negative = removed."),
            "A13": ("Cambio de problemas de malla: positivo = generados, negativo = eliminados/resueltos." if es else "Mesh-issue change: positive = generated, negative = removed/resolved."),
            "A14": ("Modo de trabajo: 0 = Otro, 1 = Object Mode, 2 = Edit Mode. Un valor más alto significa mayor predominio de Edit Mode. En vistas descriptivas se muestran porcentajes Object/Edit siempre que es posible." if es else "Work mode: 0 = Other, 1 = Object Mode, 2 = Edit Mode. A higher value means greater Edit Mode predominance. Descriptive views show Object/Edit percentages whenever possible."),
            "A15": ("Evento UV: 0 = ninguna acción UV completada; 1 = acción UV completada." if es else "UV event: 0 = no completed UV action; 1 = completed UV action."),
            "A16": ("Cambio de objetos: positivo = creados, negativo = eliminados." if es else "Object change: positive = created, negative = removed."),
            "A17": ("Estado de oclusión: 0 = desactivado; 1 = X-Ray/Wireframe activo." if es else "Occlusion state: 0 = off; 1 = X-Ray/Wireframe active."),
            "A18": ("Evento de deshacer: 0 = ninguno; 1 = acción registrada." if es else "Undo event: 0 = none; 1 = recorded action."),
            "A19": ("Estado de vista: 0 = perspectiva/otro; 1 = ortográfica." if es else "View state: 0 = perspective/other; 1 = orthographic."),
        }
        base = meanings.get(key, "")
        graph = getattr(scn, "selected_graph", "G1")
        if not base:
            return base
        if graph == "G1":
            extra = (" En G1 se conserva la serie real y se añade un resumen corto de lo detectado en la ventana visible." if es else " G1 keeps the real series and adds a short summary of what was detected in the visible window.")
        elif graph == "G2":
            g2 = {
                "A1": "El valor real es el tiempo medio observado en la serie; Z indica su posición respecto al grupo." if es else "The real value is the mean elapsed-time observation; Z locates it relative to the group.",
                "A2": "El valor real resume duración de pausa; Z compara ese nivel entre fuentes." if es else "The real value summarizes pause duration; Z compares that level across sources.",
                "A3": "El valor real resume la pausa por fase; Z compara ese nivel entre fuentes." if es else "The real value summarizes phase-pause duration; Z compares that level across sources.",
                "A4": "Se muestra la velocidad media relativa al tamaño local y su Z." if es else "The mean speed relative to local size and its Z are shown.",
                "A5": "Se muestra la distancia media en múltiplos del tamaño local y su Z." if es else "The mean distance in multiples of local size and its Z are shown.",
                "A6": "El valor real se expresa como picos por minuto; Z compara esa frecuencia." if es else "The real value is peaks per minute; Z compares that frequency.",
                "A7": "El valor real se expresa como picos por minuto; Z compara esa frecuencia." if es else "The real value is peaks per minute; Z compares that frequency.",
                "A8": "El valor real se expresa como picos por minuto; Z compara esa frecuencia." if es else "The real value is peaks per minute; Z compares that frequency.",
                "A9": "El valor real se expresa como picos por minuto; Z compara esa frecuencia." if es else "The real value is peaks per minute; Z compares that frequency.",
                "A10": "El valor real es eventos de reutilización por minuto; Z compara esa frecuencia." if es else "The real value is reuse events per minute; Z compares that frequency.",
                "A11": "El valor real es cambio neto de modificadores por minuto; el signo conserva dirección." if es else "The real value is net modifier change per minute; the sign preserves direction.",
                "A12": "El valor real es cambio neto de vértices por minuto; el signo conserva dirección." if es else "The real value is net vertex change per minute; the sign preserves direction.",
                "A13": "El valor real es balance neto de incidencias por minuto; positivo genera y negativo resuelve." if es else "The real value is net mesh-issue balance per minute; positive generates and negative resolves.",
                "A14": "Se muestran porcentajes Object/Edit/Other junto a Z; Z se calcula sobre el código 0/1/2 y un valor mayor significa más predominio de Edit Mode." if es else "Object/Edit/Other percentages are shown beside Z; Z is computed from the 0/1/2 code and a higher value means greater Edit Mode predominance.",
                "A15": "El valor real es acciones UV por minuto; Z compara esa frecuencia." if es else "The real value is UV actions per minute; Z compares that frequency.",
                "A16": "El valor real es cambio neto de objetos por minuto; el signo conserva dirección." if es else "The real value is net object change per minute; the sign preserves direction.",
                "A17": "El valor real es porcentaje de tiempo con oclusión activa; Z compara ese porcentaje." if es else "The real value is percent of time with occlusion active; Z compares that percentage.",
                "A18": "El valor real es eventos de deshacer por minuto; Z compara esa tasa." if es else "The real value is Undo events per minute; Z compares that rate.",
                "A19": "El valor real es porcentaje de tiempo en vista ortográfica; Z compara ese porcentaje." if es else "The real value is percent of time in orthographic view; Z compares that percentage.",
            }
            extra = " " + g2.get(key, "")
        elif graph == "G3":
            g3 = {
                "A1":"Radar usa duración final (min).", "A2":"Radar usa número de pausas.", "A3":"Radar usa número de pausas por fase.",
                "A4":"Radar usa velocidad media en tamaños locales/min.", "A5":"Radar usa distancia media en múltiplos del tamaño local.",
                "A6":"Radar usa picos/min.", "A7":"Radar usa picos/min.", "A8":"Radar usa picos/min.", "A9":"Radar usa picos/min.",
                "A10":"Radar usa reutilizaciones/min.", "A11":"Radar usa cambio neto de modificadores/min.", "A12":"Radar usa cambio neto de vértices/min.",
                "A13":"Radar usa balance neto de incidencias/min.", "A14":"Radar normaliza el valor medio 0/1/2; el eje se etiqueta como Other/Object/Edit y un valor más alto significa mayor predominio de Edit Mode.",
                "A15":"Radar usa acciones UV/min.", "A16":"Radar usa cambio neto de objetos/min.", "A17":"Radar usa % de tiempo con oclusión activa.", "A18":"Radar usa eventos de deshacer/min.", "A19":"Radar usa % de tiempo en vista ortográfica.",
            } if es else {
                "A1":"Radar uses final duration (min).", "A2":"Radar uses pause count.", "A3":"Radar uses phase-pause count.",
                "A4":"Radar uses mean speed in local sizes/min.", "A5":"Radar uses mean distance in multiples of local size.",
                "A6":"Radar uses peaks/min.", "A7":"Radar uses peaks/min.", "A8":"Radar uses peaks/min.", "A9":"Radar uses peaks/min.",
                "A10":"Radar uses reuse events/min.", "A11":"Radar uses net modifier change/min.", "A12":"Radar uses net vertex change/min.",
                "A13":"Radar uses net mesh-issue balance/min.", "A14":"Radar normalizes the mean 0/1/2 value; the axis is labelled Other/Object/Edit and a higher value means greater Edit Mode predominance.",
                "A15":"Radar uses UV actions/min.", "A16":"Radar uses net object change/min.", "A17":"Radar uses % time with occlusion active.", "A18":"Radar uses Undo events/min.", "A19":"Radar uses % time in orthographic view.",
            }
            extra = " " + g3.get(key, "")
        else:
            extra = (" En el heatmap, r relaciona el resumen de sesión de esta métrica con la métrica de la otra fila/columna; el signo de r indica dirección, no el significado del estado." if es else " In the heatmap, r relates this metric's session summary to the other row/column metric; the sign of r indicates relationship direction, not the meaning of the state.")
        return base + extra

    def _graph_reading_help(self, scn):
        es = get_language(scn) == "ES"
        graph = scn.selected_graph
        general = {
            "G1": ("El eje horizontal sigue la sesión. Cada métrica conserva su valor real y su unidad; los estados usan nombres/códigos discretos. La escala superpuesta 0–100% solo coloca métricas con rangos distintos en el mismo espacio y no sustituye el valor real." if es else "The horizontal axis follows the session. Each metric keeps its real value and unit; states use discrete names/codes. The 0–100% overlay scale only places different ranges in the same space and does not replace the real value."),
            "G2": ("Cada métrica se dibuja en un bloque independiente con su propio eje Z. Cada fila muestra primero el valor real y después Z. Z=0 es la media de referencia; Z>0 está por encima y Z<0 por debajo. Las barras son el IC 95% ajustado cuando existe. Para Work Mode se muestran porcentajes Object/Edit/Other." if es else "Each metric is drawn in its own block with its own Z axis. Every row shows the real value first and Z second. Z=0 is the reference mean; Z>0 is above it and Z<0 below it. Bars are adjusted 95% CIs when available. Work Mode is shown as Object/Edit/Other percentages."),
            "G3": ("El radio del radar es comparativo: 0 = mínimo observado y 1 = máximo observado para cada eje. Un 0.8 radial significa 80% del rango observado, no un valor real de 0.8. Los ejes muestran nombre y unidad real; Work Mode se expresa como Other/Object/Edit. La leyenda identifica directamente cada archivo o modelo." if es else "Radar radius is comparative: 0 = observed minimum and 1 = observed maximum for each axis. A radial 0.8 means 80% of the observed range, not a real value of 0.8. Axes show the name and real unit; Work Mode is expressed as Other/Object/Edit. The legend directly identifies each file or model."),
            "G4": ("Cada celda es una correlación de Pearson r entre -1 y 1: +1 relación lineal positiva fuerte, 0 sin relación lineal clara, -1 relación lineal negativa fuerte. Correlación no implica causalidad y los estados 0/1/2 se interpretan según su métrica." if es else "Each cell is a Pearson correlation r from -1 to 1: +1 strong positive linear relation, 0 no clear linear relation, -1 strong negative linear relation. Correlation does not imply causation and 0/1/2 states retain their metric-specific meaning."),
        }.get(graph, "")
        lines = [general]
        for item in scn.analysis_items:
            if item.enabled:
                meaning = self._graph_metric_meaning(scn, item.key, model=False)
                if meaning:
                    lines.append(f"{tr(scn, ANALYSIS.get(item.key, {}).get('label', item.key))}: {meaning}")
        if graph in {"G1", "G2", "G3"}:
            try:
                sources = selected_csv_sources(scn)
            except Exception:
                sources = []
            if sources:
                lines.append("Observaciones:" if es else "Observations:")
                for idx, path in enumerate(sources):
                    lines.append(os.path.basename(path))
        if graph in {"G2", "G3", "G4"}:
            vector_name = "anali_corr_mesh_metrics" if graph == "G4" else "anali_graph_mesh_metrics"
            enabled = getattr(scn, vector_name, [])
            for idx, (key, label) in enumerate(_CORR_MODEL_METRICS):
                if idx < len(enabled) and enabled[idx]:
                    meaning = self._graph_metric_meaning(scn, key, model=True)
                    if meaning:
                        lines.append(f"{tr(scn, label)}: {meaning}")
        return "\n".join(lines)

    def _draw_data_tab(self, context, layout, scn):
        box = layout.box()
        self._context_section_header(box, scn, "1. Data import", "CSV_IMPORT_LONG_HELP", icon='FILE_FOLDER', expanded_prop="anali_show_csv_import")
        if scn.anali_show_csv_import:
            row = box.row(align=True)
            row.prop(scn, "csv_folder", text="")
            row.operator("anali.select_csv_path", text=tr(scn, UI_TEXT['SELECT']))
            self._draw_toggle_collection(box, scn, scn.csv_items, "selected", lambda item: os.path.basename(item.name), columns=2)
            box.operator("anali.detect_csv", text=tr(scn, UI_TEXT['REFRESH_LIST']))

            groups = box.box()
            self._context_section_header(groups, scn, "Data groups", "CSV_GROUPS_LONG_HELP", icon='GROUP')
            self._draw_toggle_collection(groups, scn, scn.csv_groups, "selected", lambda item: f"{item.name} ({len(json.loads(item.member_paths or '[]'))})", columns=2)
            controls = groups.row(align=True)
            controls.operator("anali.create_csv_group", text=tr(scn, UI_TEXT['CREATE_GROUP']), icon='ADD')
            controls.operator("anali.remove_csv_group", text=tr(scn, UI_TEXT['REMOVE_GROUP']), icon='REMOVE')
            if len(scn.csv_groups) > 0:
                members_row = groups.row(align=True)
                members_row.operator("anali.select_csv_group_members", text=tr(scn, UI_TEXT['SELECT_ORIGINAL_MEMBERS']), icon='RESTRICT_SELECT_OFF')
                short_help = members_row.operator(_context_help_id(scn), text="", icon='QUESTION', emboss=False)
                short_help.title = tr(scn, UI_TEXT['SELECT_ORIGINAL_MEMBERS'])
                short_help.message = tr(scn, UI_TEXT['SELECT_ORIGINAL_MEMBERS_HELP'])


        box = layout.box()
        self._context_section_header(box, scn, "2. Global Data Metrics", "GLOBAL_CSV_METRICS_LONG_HELP", icon='SPREADSHEET', expanded_prop="anali_show_global_metrics")
        if scn.anali_show_global_metrics:
            box.operator("anali.calculate_csv_metric_stats", text=tr(scn, UI_TEXT['CALCULATE_DATA_METRIC_STATS']))

            if len(scn.metric_stats) > 0:
                self._draw_csv_metric_stats(context, box, scn)
            else:
                box.label(text=tr(scn, UI_TEXT['NO_METRICS_CALCULATED_YET']), icon='INFO')

    def _draw_csv_metric_stats(self, context, layout, scn):
        """Draw Data metrics statistics with short visible text.

        Long explanations are shown as tooltips when hovering over
        the info icon. Visible labels are wrapped into 18-20 character
        lines to avoid overly long horizontal rows.
        """
        # Clean, borderless metrics area. The parent section already provides
        # the visual container, so nested boxes only add noise.
        box_stats = layout.column(align=True)
        title_row = box_stats.row(align=True)
        title_row.scale_y = 1.18
        box_stats.separator(type='LINE')

        def _find_stat(csv_name, key):
            for st in scn.metric_stats:
                if getattr(st, "csv_name", "") == csv_name and getattr(st, "key", "") == key:
                    return st
            return None

        csv_names = []
        for st in scn.metric_stats:
            name = getattr(st, "csv_name", "")
            if name not in csv_names:
                csv_names.append(name)

        def _num(v, decimals=0):
            try:
                if decimals <= 0:
                    return f"{float(v):.0f}"
                return f"{float(v):.{decimals}f}"
            except Exception:
                return "0"

        def _wrap(text, width=None):
            return wrap_lines(context, tr(scn, str(text or "")), width=width)

        def _label(box, text, icon='NONE', width=None):
            lines = _wrap(text, width)
            for i, line in enumerate(lines):
                box.label(text=line, icon=icon if (i == 0 and icon != 'NONE') else 'NONE')


        def _header(parent, text, tooltip="", icon='NONE'):
            """Draw a clean highlighted title without an enclosing box."""
            parent.separator(factor=0.22)
            row = parent.row(align=True)
            row.scale_y = 1.16
            split = row.split(factor=0.88, align=True)
            left = split.row(align=True)
            right = split.row(align=True)
            right.alignment = 'RIGHT'
            left.label(text=tr(scn, text), icon=icon if icon != 'NONE' else 'DOT')
            if tooltip:
                help_op = right.operator(_context_help_id(scn), text="", icon='QUESTION', emboss=False)
                help_op.title = tr(scn, text)
                help_op.message = tr(scn, tooltip)

        def _section(parent, title, tooltip="", icon='NONE'):
            # A thin separator and a scaled title replace nested framed boxes.
            section = parent.column(align=True)
            section.separator(type='LINE')
            _header(section, title, tooltip, icon=icon)
            return section

        def _q_lines(box, q1, q2, q3, q4, unit="events", decimals=0):
            for label, value in (("Q1", q1), ("Q2", q2), ("Q3", q3), ("Q4", q4)):
                _metric_value(box, label, value, unit, decimals)

        def _metric_value(box, title, value, unit="", decimals=0):
            suffix = f" {tr(scn, unit)}" if unit else ""
            value_text = f"{_num(value, decimals)}{suffix}"
            for index, line in enumerate(label_value_lines(context, tr(scn, title), value_text)):
                box.label(text=line, icon='DOT' if index == 0 else 'NONE')

        def _rate_block(box, abs_value, rate_value, rate_unit, rate_decimals=2):
            _metric_value(box, "Total", abs_value, "", 0)
            _metric_value(box, "Frequency", rate_value, rate_unit, rate_decimals)

        # Show users/files in a fixed three-column grid. Blender automatically
        # starts a new row after every three entries, keeping each user's full
        # metric card together inside one grid cell.
        users_grid = box_stats.grid_flow(
            row_major=True,
            columns=3,
            even_columns=True,
            even_rows=False,
            align=True,
        )

        for csv_name in csv_names:
            user_column = users_grid.column(align=True)
            clean_name = os.path.basename(csv_name).replace("_data.csv", "").replace(".csv", "")
            user_title = user_column.row(align=True)
            user_title.scale_y = 1.20
            _label(user_title, clean_name, icon='FILE', width=14)

            details = user_column.column(align=True)

            a1 = _find_stat(csv_name, "A1")
            a2 = _find_stat(csv_name, "A2")
            temporal_parent = details
            if a1 or a2:
                temporal_parent = _section(
                    details,
                    UI_TEXT['TEMPORAL_ACTIVITY'],
                    UI_TEXT['TEMPORAL_ACTIVITY_HELP'],
                    icon='SORTTIME',
                )
            if a1:
                b = _section(temporal_parent, UI_TEXT['SESSION_DURATION'], UI_TEXT['SESSION_DURATION_HELP'], icon='TIME')
                _metric_value(b, tr(scn, UI_TEXT['DURATION']), a1.total, UI_TEXT['MINUTES_ABBR'], 2)

            if a2:
                b = _section(
                    temporal_parent,
                    UI_TEXT['PAUSES'],
                    "They are detected based on unusually long intervals without editing events and are also expressed in terms of quartiles.",
                    icon='PAUSE',
                )
                _metric_value(b, "Total pauses", a2.count, "pauses", 0)
                _metric_value(b, "Frequency", a2.rate_per_min, "pauses/min", 2)
                _q_lines(b, a2.q1, a2.q2, a2.q3, a2.q4, "", 0)

            a4 = _find_stat(csv_name, "A4")
            a5 = _find_stat(csv_name, "A5")
            representative_stat = _find_stat(csv_name, "A6")
            a17 = _find_stat(csv_name, "A17")
            a19 = _find_stat(csv_name, "A19")
            view_parent = details
            if a4 or a5 or representative_stat or a17 or a19:
                view_parent = _section(
                    details,
                    UI_TEXT['VIEW_NAVIGATION'],
                    UI_TEXT['VIEW_NAVIGATION_HELP'],
                    icon='VIEW3D',
                )
            if a4:
                b = _section(
                    view_parent,
                    UI_TEXT['VIEW_SPEED'],
                    "Average user speed calculated based on displacement and the time between rows. The local size is the bounding box used as a reference.",
                    icon='FCURVE',
                )
                local_size = getattr(a4, "object_local_size", 0.0)
                # Convert m/min divided by local size to local sizes per minute.
                normalized_speed = (
                    (a4.mean / local_size)
                    if local_size and local_size > 0.0
                    else 0.0
                )

                _metric_value(b, "Mean", speed_bu_min_to_m_min(scn, a4.mean), "m/min", 2)
                _metric_value(b, "Std. dev.", speed_bu_min_to_m_min(scn, a4.std), "m/min", 2)
                _metric_value(b, "Local size", distance_bu_to_m(scn, local_size), "m", 2)
                _metric_value(
                    b,
                    "Normalized speed",
                    normalized_speed,
                    "local size/min",
                    2,
                )

            if a5:
                b = _section(
                    view_parent,
                    UI_TEXT['DISTANCE_TO_OBJECT'],
                    "Average distance between the user and the object. A relative distance of 1.0 corresponds to the size of the object, allowing for comparisons between objects of different sizes.",
                    icon='EMPTY_SINGLE_ARROW',
                )
                local_size = getattr(a5, "object_local_size", 0.0)
                relative_distance = (
                    a5.mean / local_size
                    if local_size and local_size > 0.0
                    else 0.0
                )

                _metric_value(b, "Mean", distance_bu_to_m(scn, a5.mean), "m", 2)
                _metric_value(b, "Std. dev.", distance_bu_to_m(scn, a5.std), "m", 2)
                _metric_value(b, "Local size", distance_bu_to_m(scn, local_size), "m", 2)
                _metric_value(
                    b,
                    "Relative distance",
                    relative_distance,
                    "x local size",
                    2,
                )

            if representative_stat:
                b = _section(
                    view_parent,
                    UI_TEXT['VIEW_MOVEMENT_PEAKS'],
                    "Detects unusually high movement speed during the session and highlights periods in which the user moves significantly faster than usual.",
                    icon='NORMALIZE_FCURVES',
                )
                _metric_value(b, "Total peaks", representative_stat.count, "peaks", 0)
                _metric_value(b, "Frequency", representative_stat.rate_per_min, "peaks/min", 2)
                peak_speed_bu_min = getattr(representative_stat, "peak_speed_mean", 0.0)
                object_local_size = getattr(representative_stat, "object_local_size", 0.0)
                peak_speed_local_min = (
                    peak_speed_bu_min / object_local_size
                    if object_local_size and object_local_size > 0.0
                    else 0.0
                )
                _metric_value(
                    b,
                    "Mean peak speed",
                    peak_speed_local_min,
                    "local size/min",
                    2,
                )
                _q_lines(
                    b,
                    representative_stat.q1,
                    representative_stat.q2,
                    representative_stat.q3,
                    representative_stat.q4,
                    "peaks",
                )

            if a17:
                b = _section(view_parent, UI_TEXT['OCCLUSION'],
                    "X-Ray/Wireframe use measured as state: activations, active minutes and percentage of session.",
                    icon='OVERLAY')
                _metric_value(b, "Activations", getattr(a17, "activations", 0.0), "events", 0)
                _metric_value(b, "Active time", getattr(a17, "time_active_min", 0.0), "min", 2)
                _metric_value(b, "Session active", getattr(a17, "pct_active", 0.0), "%", 2)
                _metric_value(b, "Activation frequency", a17.rate_per_min, "events/min", 2)
                _q_lines(b, a17.q1, a17.q2, a17.q3, a17.q4, "% active")

            if a19:
                b = _section(view_parent, UI_TEXT['ORTHOGRAPHIC_VIEW'], UI_TEXT['ORTHOGRAPHIC_VIEW_HELP'], icon='VIEW_ORTHO')
                _metric_value(b, "Activations", getattr(a19, "activations", 0.0), "events", 0)
                _metric_value(b, "Active time", getattr(a19, "time_active_min", 0.0), "min", 2)
                _metric_value(b, "Session active", getattr(a19, "pct_active", 0.0), "%", 2)
                _metric_value(b, "Activation frequency", a19.rate_per_min, "events/min", 2)
                _q_lines(b, a19.q1, a19.q2, a19.q3, a19.q4, "% active")
            a12 = _find_stat(csv_name, "A12")
            a13 = _find_stat(csv_name, "A13")
            a16 = _find_stat(csv_name, "A16")
            if a12 or a13 or a16:
                b = _section(
                    details,
                    UI_TEXT['MODEL_EVOLUTION'],
                    UI_TEXT['MODEL_EVOLUTION_HELP'],
                    icon='VERTEXSEL',
                )
                if a12:
                    sub = _section(b, UI_TEXT['VERTEX_CHANGES'], "Shows vertices added, removed, and their net result.", icon='SNAP_VERTEX')
                    _metric_value(sub, "Added", getattr(a12, "created_total", 0.0), "vertices", 0)
                    _metric_value(sub, "Removed", getattr(a12, "deleted_total", 0.0), "vertices", 0)
                    _metric_value(sub, "Net change", a12.total, "vertices", 0)
                    _metric_value(sub, "Frequency", a12.rate_per_min, "events/min", 2)
                    _q_lines(sub, a12.q1, a12.q2, a12.q3, a12.q4, "net vertices")
                if a13:
                    sub = _section(b, UI_TEXT['MESH_ISSUE_CHANGES'], "New issues and resolved issues are separated. Error totals count only issues introduced, not their later resolution.", icon='MESH_DATA')
                    _metric_value(sub, "Errors generated", getattr(a13, "issue_created_total", a13.abs_total), "errors", 0)
                    _metric_value(sub, "Errors resolved", getattr(a13, "issue_resolved_total", 0.0), "errors", 0)
                    _metric_value(sub, "Net change", a13.total, "errors", 0)
                    _metric_value(sub, "Ngons generated", getattr(a13, "ngon_error_total", 0.0), "errors", 0)
                    _metric_value(sub, "Triangles generated", getattr(a13, "tri_error_total", 0.0), "errors", 0)
                    _metric_value(sub, "Normals generated", getattr(a13, "normal_error_total", 0.0), "errors", 0)
                    _metric_value(sub, "Non-manifold generated", getattr(a13, "nonmanifold_error_total", 0.0), "errors", 0)
                    _metric_value(sub, "Generation rate", a13.rate_per_min, "err/min", 2)
                    _q_lines(sub, a13.q1, a13.q2, a13.q3, a13.q4, "errors")
                if a16:
                    sub = _section(b, UI_TEXT['OBJECT_CHANGES'], "Shows objects created, deleted, and their net balance.", icon='OBJECT_DATA')
                    _metric_value(sub, "Created", getattr(a16, "created_total", 0.0), "objects", 0)
                    _metric_value(sub, "Deleted", getattr(a16, "deleted_total", 0.0), "objects", 0)
                    _metric_value(sub, "Net change", a16.total, "objects", 0)
                    _metric_value(sub, "Frequency", a16.rate_per_min, "events/min", 2)
                    _q_lines(sub, a16.q1, a16.q2, a16.q3, a16.q4, "net objects")

            a14 = _find_stat(csv_name, "A14")
            a10 = _find_stat(csv_name, "A10")
            a11 = _find_stat(csv_name, "A11")
            a15 = _find_stat(csv_name, "A15")
            a18 = _find_stat(csv_name, "A18")
            tools_parent = details
            if a14 or a10 or a11 or a15 or a18:
                tools_parent = _section(
                    details,
                    UI_TEXT['TOOLS_ACTIONS'],
                    UI_TEXT['TOOLS_ACTIONS_HELP'],
                    icon='RESTRICT_SELECT_OFF',
                )
            if a14:
                b = _section(tools_parent, UI_TEXT['WORK_MODE'],
                    "Percentage of time in Object Mode and Edit Mode, plus mode-switch frequency.",
                    icon='TOOL_SETTINGS')
                total_mode_min = max((a14.time_object + a14.time_edit) / 60, 0.000001)
                _metric_value(b, "Object Mode", a14.pct_object, "%", 2)
                _metric_value(b, "Edit Mode", a14.pct_edit, "%", 2)
                _metric_value(b, "Mode changes", a14.switches / total_mode_min, "chg/min", 2)
                _q_lines(b, a14.pct_object_q1, a14.pct_object_q2, a14.pct_object_q3, a14.pct_object_q4, "% Object")
                _q_lines(b, a14.pct_edit_q1, a14.pct_edit_q2, a14.pct_edit_q3, a14.pct_edit_q4, "% Edit")

            if a10:
                b = _section(tools_parent, UI_TEXT['SHORTCUT_REUSE'],
                    "Ctrl+V and Shift+D are shown together as Duplicate. Alt+D is shown as Instance.",
                    icon='DUPLICATE')
                _metric_value(b, "Duplicate", getattr(a10, "duplicate_total", 0.0), "events", 0)
                _metric_value(b, "Instance", getattr(a10, "instance_total", 0.0), "events", 0)
                _metric_value(b, "Total", a10.total, "events", 0)
                _metric_value(b, "Frequency", a10.rate_per_min, "events/min", 2)
                _q_lines(b, a10.q1, a10.q2, a10.q3, a10.q4, "events")

            if a11:
                b = _section(
                    tools_parent,
                    UI_TEXT['MODIFIER_CHANGES'],
                    "Separates modifiers created and deleted. Net change is created minus deleted; quartiles show the signed balance in each quarter.",
                    icon='MODIFIER_ON',
                )
                _metric_value(b, "Created", getattr(a11, "created_total", 0.0), "modifiers", 0)
                _metric_value(b, "Deleted", getattr(a11, "deleted_total", 0.0), "modifiers", 0)
                _metric_value(b, "Net change", a11.total, "modifiers", 0)
                _metric_value(b, "Frequency", a11.rate_per_min, "events/min", 2)
                _q_lines(b, a11.q1, a11.q2, a11.q3, a11.q4, "net modifiers")

            if a15:
                b = _section(tools_parent, UI_TEXT['UV_WORK'], UI_TEXT['UV_WORK_PANEL_HELP'],
                    icon='UV')
                _metric_value(b, "Unwrap / deploy events", getattr(a15, "uv_deploy_total", a15.total), "events", 0)
                _metric_value(b, "Frequency", a15.rate_per_min, "events/min", 2)
                _q_lines(b, a15.q1, a15.q2, a15.q3, a15.q4, "events")

            if a18:
                b = _section(tools_parent, UI_TEXT['UNDO_ACTIONS'], UI_TEXT['UNDO_ACTIONS_HELP'], icon='LOOP_BACK')
                _metric_value(b, "Total", a18.total, "events", 0)
                _metric_value(b, "Frequency", a18.rate_per_min, "events/min", 2)
                _q_lines(b, a18.q1, a18.q2, a18.q3, a18.q4, "events")




    def _draw_mesh_tab(self, context, layout, scn):
        # --- 1. CSV Mesh Link ---
        box = layout.box()
        self._context_section_header(box, scn, "1. Model selector", "MESH_LINK_LONG_HELP", icon='OBJECT_DATA', expanded_prop="anali_show_mesh_binding")
        if scn.anali_show_mesh_binding:
            target_row = box.row(align=True)
            target_row.prop(scn, "anali_target_obj", text=tr(scn, UI_TEXT['OBJECT_MODEL']))
            target_help = target_row.operator(_context_help_id(scn), text="", icon='QUESTION', emboss=False)
            target_help.title = tr(scn, UI_TEXT['OBJECT_MODEL'])
            target_help.message = tr(scn, UI_TEXT['MODEL_TARGET_HELP'])
            reference_row = box.row(align=True)
            reference_row.prop(scn, "reference_obj", text=tr(scn, UI_TEXT['REFERENCE_MODEL']))
            reference_help = reference_row.operator(_context_help_id(scn), text="", icon='QUESTION', emboss=False)
            reference_help.title = tr(scn, UI_TEXT['REFERENCE_MODEL'])
            reference_help.message = tr(scn, UI_TEXT['MODEL_REFERENCE_HELP'])

        # --- 2. Mesh Metrics ---
        box = layout.box()
        self._context_section_header(box, scn, "2. Model Metrics", "MESH_METRICS_LONG_HELP", icon='SPREADSHEET', expanded_prop="anali_show_model_metrics")
        if scn.anali_show_model_metrics:
            actions = box.column(align=True)
            actions.operator("object.calculate_metrics", text=tr(scn, UI_TEXT['CALCULATE_MODEL_METRICS']))
            import_row = actions.row(align=True)
            import_row.operator(
                "anali.import_data_logger_mesh_metrics",
                text=tr(scn, UI_TEXT['IMPORT_DATA_LOGGER_MODEL_METRICS']),
                icon='IMPORT',
            )
            import_row.operator(
                "anali.select_data_logger_mesh_metrics_file",
                text=tr(scn, UI_TEXT['SELECT']),
                icon='FILE_FOLDER',
            )
            selected_logger_file = bpy.path.abspath(getattr(scn, "anali_data_logger_mesh_file", "") or "")
            if selected_logger_file:
                file_row = box.row(align=True)
                file_row.label(text=os.path.basename(selected_logger_file), icon='FILE')
            imported_count = int(scn.get("data_logger_mesh_count", 0))
            if imported_count:
                status = box.row(align=True)
                status.label(
                    text=f"{tr(scn, UI_TEXT['DATA_LOGGER_MESH_OBSERVATIONS'])}: {imported_count}",
                    icon='CHECKMARK',
                )
            # Display metrics for the object chosen in the panel, not for the
            # currently active object in the 3D scene.
            obj = scn.anali_target_obj
            if obj and obj.type == 'MESH':
                metrics_data = scn.get("metrics_data", {})
                if obj.name in metrics_data:
                    inner = box.column(align=True)
                    inner.separator(type='LINE')
                    object_title = inner.row(align=True)
                    object_title.scale_y = 1.20
                    self._label_wrap(context, object_title, f"{tr(scn, UI_TEXT['OBJECT_MODEL'])}:  {obj.name}", icon='OBJECT_DATA')
                    mesh_help = {}
                    mesh_structure_keys = ["N_faces", "N_meshes", "Face_by_mesh", "Angle", "Non_quads", "Non_quads_percentage"]
                    mesh_topology_keys = ["Vertex_duplicate", "Vertex_duplicate_percentage", "Non_manifold", "Non_manifold_percentage", "Normal_count", "Normal_percentage"]
                    uv_keys = ["UV_area", "UV_islands", "UV_stretch", "UV_textel_density"]
                    transform_keys = ["Transformations", "Position"]
                    similarity_keys = ["Similarity"]

                    data_dict = metrics_data[obj.name]

                    def _format_mesh_metric(key, value):
                        percentage_keys = {
                            "Non_quads_percentage", "Vertex_duplicate_percentage",
                            "Non_manifold_percentage", "Normal_percentage",
                            "UV_area", "UV_stretch", "UV_textel_density", "Similarity",
                        }
                        boolean_keys = {"Transformations", "Position"}
                        if key in boolean_keys:
                            if isinstance(value, str):
                                truth = value.strip().lower() in {"1", "true", "yes", "sí", "si"}
                            else:
                                truth = bool(value)
                            return tr(scn, "Yes" if truth else "No")
                        if key in percentage_keys:
                            try:
                                return f"{float(value):.2f}%"
                            except (TypeError, ValueError):
                                return "0.00%"
                        if key == "Angle":
                            try:
                                return f"{float(value):.2f}°"
                            except (TypeError, ValueError):
                                return "0.00°"
                        if key == "Face_by_mesh":
                            try:
                                return f"{float(value):.2f}"
                            except (TypeError, ValueError):
                                return "0.00"
                        return str(value)

                    def _draw_metric_group(parent, title, tooltip, icon, keys):
                        """Draw model-metric categories like Calculate Data Metrics.

                        Each category starts with a full-width separator line,
                        followed by a category title and its detailed INFO help.
                        """
                        group_keys = [k for k in keys if k in data_dict]
                        if not group_keys:
                            return

                        section = parent.column(align=True)
                        section.separator(type='LINE')

                        header = section.row(align=True)
                        header.scale_y = 1.16
                        split = header.split(factor=0.88, align=True)
                        left = split.row(align=True)
                        right = split.row(align=True)
                        right.alignment = 'RIGHT'
                        left.label(text=tr(scn, title), icon=icon)
                        help_op = right.operator(
                            _context_help_id(scn),
                            text="",
                            icon='QUESTION',
                            emboss=False,
                        )
                        help_op.title = tr(scn, title)
                        help_op.message = tr(scn, tooltip)

                        section.separator(factor=0.12)
                        for k in group_keys:
                            label = _MODEL_METRIC_LABELS.get(k, k.replace('_', ' '))
                            self._metric_row_wrap(
                                context,
                                section,
                                label,
                                _format_mesh_metric(k, data_dict[k]),
                            )

                    _draw_metric_group(
                        inner, "Mesh structure",
                        "MESH_STRUCTURE_LONG_HELP",
                        'MOD_WIREFRAME', mesh_structure_keys,
                    )
                    _draw_metric_group(
                        inner, "Mesh topology",
                        "MESH_TOPOLOGY_LONG_HELP",
                        'MESH_DATA', mesh_topology_keys,
                    )
                    _draw_metric_group(
                        inner, "UV Mapping",
                        "UV_MAPPING_LONG_HELP",
                        'UV', uv_keys,
                    )
                    _draw_metric_group(
                        inner, "Transform state",
                        "TRANSFORM_STATE_LONG_HELP",
                        'OBJECT_ORIGIN', transform_keys,
                    )
                    _draw_metric_group(
                        inner, "Shape similarity",
                        "SHAPE_SIMILARITY_LONG_HELP",
                        'CONSTRAINT', similarity_keys,
                    )

                    covered = set(mesh_structure_keys + mesh_topology_keys + uv_keys + transform_keys + similarity_keys)
                    extra = [k for k in data_dict if k not in covered]
                    for k in extra:
                        label = _MODEL_METRIC_LABELS.get(k, k.replace('_', ' '))
                        self._metric_row_wrap(context, inner, label, _format_mesh_metric(k, data_dict[k]))
                else:
                    box.label(text=tr(scn, UI_TEXT['SELECT_A_MESH_AND_CALCULATE_METRICS']), icon='QUESTION')
            else:
                box.label(text=tr(scn, UI_TEXT['NO_ACTIVE_MODEL_FOUND']), icon='ERROR')

        # --- 3. Explicit Data ↔ Model associations ---
        correlation_box = layout.box()
        self._context_section_header(
            correlation_box,
            scn,
            "3. Data ↔ Model associations",
            "DATA_MESH_ASSOCIATIONS_LONG_HELP",
            icon='LINKED',
            expanded_prop="anali_show_data_mesh_pairs",
        )
        if scn.anali_show_data_mesh_pairs:

            pairs = scn.anali_data_mesh_pairs

            for pair_index, pair in enumerate(pairs):
                pair_box = correlation_box.box()
                header = pair_box.row(align=True)
                header.label(text=f"{tr(scn, UI_TEXT['ASSOCIATION'])} {pair_index + 1}", icon='LINKED')
                remove = header.operator("anali.remove_data_mesh_pair", text="", icon='X')
                remove.index = pair_index

                data_row = pair_box.row(align=True)
                data_row.label(text=tr(scn, UI_TEXT['DATA_FILE']), icon='FILE')
                data_row.prop_search(pair, "data_path", scn, "csv_items", text="")

                mesh_row = pair_box.row(align=True)
                mesh_row.label(text=tr(scn, UI_TEXT['MODEL_DATA']), icon='MESH_DATA')
                mesh_row.prop(pair, "mesh_record", text="")

            controls = correlation_box.row(align=True)
            controls.scale_y = 1.10
            controls.operator("anali.add_data_mesh_pair", text=tr(scn, UI_TEXT['ADD_ASSOCIATION']), icon='ADD')
            controls.operator("anali.remove_data_mesh_pair", text=tr(scn, UI_TEXT['REMOVE_ASSOCIATION']), icon='REMOVE')

            valid_count = sum(
                1 for pair in pairs
                if bool(getattr(pair, "data_path", ""))
                and str(getattr(pair, "mesh_record", "") or "") not in {"", "__NONE__"}
            )
            status = correlation_box.row(align=True)
            status.label(
                text=f"{tr(scn, UI_TEXT['VALID_ASSOCIATIONS'])}: {valid_count}",
                icon='CHECKMARK' if valid_count else 'ERROR',
            )

    def _draw_tables_tab(self, context, layout, scn):
        if len(scn.analysis_items) == 0:
            try:
                refresh_analysis_list(None, context)
            except Exception as exc:
                print(f"[tables] Could not initialise metric list: {exc}")
        selected_csv_count = selected_csv_file_count(scn)
        selected_group_count = selected_csv_group_count(scn)
        selected_metric_count = sum(1 for item in scn.analysis_items if item.enabled)

        box = layout.box()
        self._context_section_header(box, scn, "1. Table content", "TABLE_CONTENT_LONG_HELP", icon='SPREADSHEET', expanded_prop="anali_show_table_config")
        if scn.anali_show_table_config:
            status = box.box()
            status.label(text=f"{tr(scn, UI_TEXT['DATA_FILES_SELECTED'])}: {selected_csv_count}", icon='FILE')
            status.label(text=f"{tr(scn, UI_TEXT['DATA_GROUPS_SELECTED'])}: {selected_group_count}", icon='GROUP')
            status.label(text=f"{tr(scn, UI_TEXT['METRICS_SELECTED'])}: {selected_metric_count}", icon='CHECKMARK')
            if selected_csv_count == 0 and selected_group_count == 0:
                status.label(text=tr(scn, UI_TEXT['SELECT_CSV_FILES_IN_THE_DATA_TAB']), icon='ERROR')

            source_row = box.row(align=True)
            source_row.prop(scn, "anali_table_source", text=tr(scn, UI_TEXT['TABLE_DATA_SOURCE']))
            source_help = source_row.operator(_context_help_id(scn), text="", icon='QUESTION', emboss=False)
            source_help.title = tr(scn, UI_TEXT['TABLE_DATA_SOURCE'])
            source_help.message = tr(scn, UI_TEXT['TABLE_DATA_SOURCE_HELP'])
            if scn.anali_table_source == 'DATA':
                box.prop(scn, "anali_table_statistic", text=tr(scn, UI_TEXT['DISPLAYED_VALUE']))
                self._draw_analysis_toggles(box, scn, columns=2)
            else:
                mesh_status = box.box()
                try:
                    mesh_count = len(scn.get("metrics_data", {}))
                except Exception:
                    mesh_count = 0
                mesh_status.label(text=f"{tr(scn, UI_TEXT['CALCULATED_MESH_OBSERVATIONS'])}: {mesh_count}", icon='MESH_DATA')
                mesh_grid = mesh_status.grid_flow(columns=2, even_columns=True, even_rows=False, align=True)
                for metric_index, (_metric_key, metric_label) in enumerate(_CORR_MODEL_METRICS):
                    mesh_grid.prop(scn, "anali_graph_mesh_metrics", index=metric_index, text=tr(scn, metric_label), toggle=True)

        box = layout.box()
        self._context_section_header(box, scn, "2. Create / Control", "TABLE_CONTROL_LONG_HELP", icon='RENDER_STILL', expanded_prop="anali_show_actions_config")
        if scn.anali_show_actions_config:
            row = box.row(align=True)
            row.scale_y = 1.25
            row.operator("anali.visualize_table", text=tr(scn, UI_TEXT['CREATE_3D_TABLE']), icon='SPREADSHEET')
            row = box.row(align=True)
            row.operator("anali.clear_tables", text=tr(scn, UI_TEXT['CLEAR_TABLE']), icon='TRASH')
            row.operator("anali.restore_scene_objects", text=tr(scn, UI_TEXT['RESTORE_OBJECTS']), icon='HIDE_OFF')

        box = layout.box()
        self._context_section_header(box, scn, "3. Layout and pagination", "TABLE_LAYOUT_LONG_HELP", icon='ALIGN_JUSTIFY', expanded_prop="anali_show_layout_config")
        if scn.anali_show_layout_config:
            row = box.row(align=True)
            row.prop(scn, "anali_table_rows_per_page", text=tr(scn, UI_TEXT['ROWS_2']))
            row.prop(scn, "anali_table_cols_per_page", text=tr(scn, UI_TEXT['COLUMNS_2']))

            nav = box.column(align=True)
            row = nav.row(align=True)
            row.operator("anali.table_row_prev_es" if get_language(scn) == "ES" else "anali.table_row_prev", text="", icon='TRIA_LEFT')
            row.prop(scn, "anali_table_row_page", text=tr(scn, UI_TEXT['ROW_PAGE']), slider=True)
            row.operator("anali.table_row_next_es" if get_language(scn) == "ES" else "anali.table_row_next", text="", icon='TRIA_RIGHT')

            row = nav.row(align=True)
            row.operator("anali.table_col_prev_es" if get_language(scn) == "ES" else "anali.table_col_prev", text="", icon='TRIA_LEFT')
            row.prop(scn, "anali_table_col_page", text=tr(scn, UI_TEXT['COLUMN_PAGE']), slider=True)
            row.operator("anali.table_col_next_es" if get_language(scn) == "ES" else "anali.table_col_next", text="", icon='TRIA_RIGHT')

    def _draw_graphs_tab(self, context, layout, scn):
        box = layout.box() 
        self._context_section_header(box, scn, "1. Visual Settings", "GRAPH_SETTINGS_LONG_HELP", icon='GRAPH', expanded_prop="anali_show_graph_config")
        if scn.anali_show_graph_config:
            row = box.row(align=True)
            split = row.split(factor=0.90, align=True)
            split.prop(scn, "selected_graph", text=tr(scn, UI_TEXT['GRAPH']))
            help_cell = split.row(align=True)
            help_cell.alignment = 'RIGHT'
            graph_help_key = f"GRAPH_{scn.selected_graph}_LONG_HELP"
            graph_label = GRAPH_TYPES.get(scn.selected_graph, {}).get("label", "Graph")
            help_op = help_cell.operator(_context_help_id(scn), text="", icon='INFO', emboss=False)
            help_op.title = tr(scn, graph_label)
            help_op.message = tr(scn, graph_help_key)
            if scn.selected_graph == 'G4':
                info = box.box()
                mode_row = info.row(align=True)
                mode_row.prop_enum(
                    scn,
                    "anali_heatmap_correlation_mode",
                    'CSV_MESH',
                    text=tr(scn, UI_TEXT['DATA_MODEL']),
                )
                mode_row.prop_enum(
                    scn,
                    "anali_heatmap_correlation_mode",
                    'CSV_CSV',
                    text=tr(scn, UI_TEXT['DATA_DATA']),
                )
                mode_row.prop_enum(
                    scn,
                    "anali_heatmap_correlation_mode",
                    'MESH_MESH',
                    text=tr(scn, UI_TEXT['MODEL_MODEL']),
                )
                selected_csv_count = selected_csv_file_count(scn)
                selected_group_count = selected_csv_group_count(scn)
                try:
                    calculated_model_count = len(scn.get("metrics_data", {}))
                except Exception:
                    calculated_model_count = 0
                mode = getattr(scn, "anali_heatmap_correlation_mode", "CSV_MESH")
                if mode in {'CSV_MESH', 'CSV_CSV'}:
                    info.label(text=f"{tr(scn, UI_TEXT['DATA_FILES_SELECTED'])}: {selected_csv_count}", icon='FILE')
                    info.label(text=f"{tr(scn, UI_TEXT['DATA_GROUPS_SELECTED'])}: {selected_group_count}", icon='GROUP')
                if selected_csv_count == 0 and selected_group_count == 0:
                    info.label(text=tr(scn, UI_TEXT['SELECT_CSV_FILES_IN_THE_DATA_TAB']), icon='ERROR')
                if mode in {'CSV_MESH', 'MESH_MESH'}:
                    info.label(text=f"{tr(scn, UI_TEXT['CALCULATED_MESH_OBSERVATIONS'])}: {calculated_model_count}", icon='MESH_DATA')
                metric_box = info.box()
                metric_box.label(text=tr(scn, UI_TEXT['METRICS_SHOWN_IN_THE_CORRELATION_GRAPH']), icon='FILTER')

                if mode in {'CSV_MESH', 'CSV_CSV'}:
                    csv_box = metric_box.box()
                    csv_box.label(text=tr(scn, UI_TEXT['DATA_METRICS']), icon='SPREADSHEET')
                    grid = csv_box.grid_flow(columns=2, even_columns=True, even_rows=False, align=True)
                    for metric_index, (metric_key, metric_info) in enumerate(ANALYSIS.items()):
                        grid.prop(
                            scn,
                            "anali_corr_csv_metrics",
                            index=metric_index,
                            text=tr(scn, metric_info["label"]),
                            toggle=True,
                        )

                if mode in {'CSV_MESH', 'MESH_MESH'}:
                    mesh_box = metric_box.box()
                    mesh_box.label(text=tr(scn, UI_TEXT['MODEL_METRICS']), icon='MESH_DATA')
                    grid = mesh_box.grid_flow(columns=2, even_columns=True, even_rows=False, align=True)
                    for metric_index, (_metric_key, metric_label) in enumerate(_CORR_MODEL_METRICS):
                        grid.prop(
                            scn,
                            "anali_corr_mesh_metrics",
                            index=metric_index,
                            text=tr(scn, metric_label),
                            toggle=True,
                        )

                requirement = info.box()
                requirement.label(text=tr(scn, UI_TEXT['MINIMUM_OBSERVATIONS_3']), icon='ERROR')
            else:
                selected_csv_count = selected_csv_file_count(scn)
                selected_group_count = selected_csv_group_count(scn)
                selected_metric_count = sum(1 for item in scn.analysis_items if item.enabled)
                box.prop(scn, "anali_color_palette", text=tr(scn, UI_TEXT['COLOR_PALETTE']))
                box.label(text=f"{tr(scn, UI_TEXT['DATA_FILES_SELECTED'])}: {selected_csv_count}", icon='FILE')
                box.label(text=f"{tr(scn, UI_TEXT['DATA_GROUPS_SELECTED'])}: {selected_group_count}", icon='GROUP')
                box.label(text=f"{tr(scn, UI_TEXT['METRICS_SELECTED'])}: {selected_metric_count}", icon='CHECKMARK')
                if selected_csv_count == 0 and selected_group_count == 0:
                    box.label(text=tr(scn, UI_TEXT['SELECT_CSV_FILES_IN_THE_DATA_TAB']), icon='ERROR')
                opts = box.row(align=True)
                opts.scale_y = 1.08
                opts.prop(scn, "anali_use_log_scale", text=tr(scn, UI_TEXT['LOG_SCALE']), toggle=True, icon='IPO_EXPO')

                
            if scn.selected_graph == 'G3':
                radar_box = box.box()
                margin_row = radar_box.row(align=True)
                margin_row.prop(scn, "anali_radar_margin", text=("Margen del radar" if get_language(scn) == "ES" else "Radar margin"), slider=True)
                margin_help = margin_row.operator(
                    "anali.context_help_es" if get_language(scn) == "ES" else "anali.context_help",
                    text="", icon='QUESTION', emboss=False,
                )
                margin_help.title = "Radar margin"
                margin_help.message = UI_TEXT['EMPTY_RADIAL_MARGIN_KEPT_INSIDE_AND_OUTSIDE_THE_NORMALIZED_RADAR_DATA']
                radar_box.label(text=tr(scn, UI_TEXT['PER_METRIC_MIN_MAX_NORMALIZATION']), icon='IPO_EASE_IN_OUT')
                selected_data = sum(1 for item in scn.analysis_items if item.enabled)
                mesh_flags = tuple(getattr(scn, "anali_graph_mesh_metrics", ()))
                selected_model = sum(1 for enabled in mesh_flags if enabled)
                selected_total = selected_data + selected_model
                radar_box.label(
                    text=(f"Métricas del radar: {selected_total}/3 mínimo" if get_language(scn) == "ES" else f"Radar metrics: {selected_total}/3 minimum"),
                    icon='CHECKMARK' if selected_total >= 3 else 'ERROR',
                )
                if selected_total < 3:
                    warn = radar_box.box()
                    warn.alert = True
                    warn.label(text=tr(scn, UI_TEXT['RADAR_PLOT_NEEDS_AT_LEAST_THREE_SELECTED_DATA_OR_MODEL_METRICS']), icon='ERROR')
                if selected_total > 8:
                    warn = radar_box.box()
                    warn.alert = True
                    warn.label(text=(f"{selected_total} métricas: se recomiendan 8 o menos." if get_language(scn) == "ES" else f"{selected_total} metrics: 8 or fewer is recommended."), icon='ERROR')
            if scn.selected_graph == 'G1':
                window = box.box()
                visualizer_title = window.row(align=True)
                visualizer_title.label(text=tr(scn, UI_TEXT['DATA_VISUALIZER']), icon='PREVIEW_RANGE')
                visualizer_help = visualizer_title.operator(_context_help_id(scn), text="", icon='QUESTION', emboss=False)
                visualizer_help.title = tr(scn, UI_TEXT['DATA_VISUALIZER'])
                visualizer_help.message = tr(scn, UI_TEXT['DATA_VISUALIZER_HELP'])
                window.label(text=tr(scn, UI_TEXT['RANGE_OF_SAMPLES']))
                nav = window.row(align=True)
                nav.operator("anali.g1_prev_es" if get_language(scn) == "ES" else "anali.g1_prev", text="", icon='TRIA_LEFT')
                start = max(0, int(scn.anali_g1_window_start))
                percentage = min(100.0, max(1.0, float(scn.anali_g1_window_size)))
                total_rows = max(1, int(getattr(scn, "anali_g1_last_total_rows", 1)))
                size = max(1, min(total_rows, int(math.ceil(total_rows * percentage / 100.0))))
                end = min(total_rows, start + size)
                is_global = bool(getattr(scn, "anali_g1_global_view", True))
                nav.label(text=tr(scn, UI_TEXT['GLOBAL']) if is_global else f"{start + 1}–{end}", icon='WORLD' if is_global else 'PREVIEW_RANGE')
                nav.operator("anali.g1_next_es" if get_language(scn) == "ES" else "anali.g1_next", text="", icon='TRIA_RIGHT')
                mode_row = window.row(align=True)
                mode_row.prop_enum(scn, "anali_g1_display_mode", 'BANDS', text=tr(scn, UI_TEXT['BANDS']))
                mode_row.prop_enum(scn, "anali_g1_display_mode", 'OVERLAY', text=tr(scn, UI_TEXT['OVERLAY']))
                window_row = window.row(align=True)
                window_row.prop(scn, "anali_g1_window_size", text=tr(scn, UI_TEXT['ROWS_PER_WINDOW']), slider=True)
                window_help = window_row.operator(_context_help_id(scn), text="", icon='QUESTION', emboss=False)
                window_help.title = tr(scn, UI_TEXT['ROWS_PER_WINDOW'])
                window_help.message = tr(scn, UI_TEXT['TIMELINE_WINDOW_HELP'])

            if scn.selected_graph in {'G2', 'G3'}:
                    try:
                        calculated_model_count = len(scn.get("metrics_data", {}))
                    except Exception:
                        calculated_model_count = 0
                    mesh_box = box.box()
                    mesh_box.label(text=tr(scn, UI_TEXT['MODEL_METRICS']), icon='MESH_DATA')
                    mesh_box.label(text=f"{tr(scn, UI_TEXT['CALCULATED_MODEL_OBSERVATIONS'])}: {calculated_model_count}")
                    mesh_grid = mesh_box.grid_flow(columns=2, even_columns=True, even_rows=False, align=True)
                    for metric_index, (_metric_key, metric_label) in enumerate(_CORR_MODEL_METRICS):
                        mesh_grid.prop(
                            scn,
                            "anali_graph_mesh_metrics",
                            index=metric_index,
                            text=tr(scn, metric_label),
                            toggle=True,
                        )
                    if scn.selected_graph == 'G3':
                        mesh_box.label(
                            text=tr(scn, UI_TEXT['CSV_AND_MODEL_OBSERVATIONS_ARE_PAIRED_BY_NAME_OR_ORDER_WHEN_BOTH_METRI']),
                            icon='LINKED',
                        )
            
            if scn.selected_graph != 'G4':
                metrics_box = box.box()
                self._label_wrap(
                    context,
                    metrics_box,
                    tr(scn, UI_TEXT['DATA_METRICS']),
                    icon='SPREADSHEET',
                )

                self._draw_analysis_toggles(
                    metrics_box,
                    scn,
                    columns=2,
                )

                
        box = layout.box()
        self._context_section_header(box, scn, "2. Render / Control", "RENDER_CONTROLS_LONG_HELP", icon='RENDER_STILL', expanded_prop="anali_show_render_controls")

        if scn.anali_show_render_controls:
            row = box.row(align=True)
            row.prop(scn, "axis_scale_x", text=tr(scn, UI_TEXT['SCALE_X']))
            row.prop(scn, "axis_scale_y", text=tr(scn, UI_TEXT['SCALE_Y']))
            row.prop(scn, "axis_scale_z", text=tr(scn, UI_TEXT['SCALE_Z']))
            row = box.row(align=True)
            row.operator("anali.clear_graphs", text=tr(scn, UI_TEXT['CLEAR_GRAPHS']))
            row.operator("anali.restore_scene_objects", text=tr(scn, UI_TEXT['RESTORE_OBJECTS']))
            row = box.row(align=True)
            row.operator("anali.visualize_graph", text=tr(scn, UI_TEXT['VISUALIZE_3D_GRAPH']))

# Herramientas para la monitorización y análisis de procesos de modelado 3D en Blender
# Copyright (C) 2026 María Molina Goyena
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# at your option any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.

"""Blender UI registration facade.

This module intentionally contains no business logic. The former monolithic UI
implementation has been split into helpers, property models, operators and
panels so Blender registration remains thin and maintainable.
"""

import bpy
from bpy.props import BoolProperty, BoolVectorProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty

from .ui_properties import MetricStatItem, CSVItem, CSVGroupItem, AnalysisItem, DataMeshPairItem
from .ui_helpers import GRAPH_TYPES, refresh_analysis_list
from .analytics import ANALYSIS
from .texts import UI_TEXT, tr, translate_enum_items, LANG_EN, LANG_ES
from .ui_operators import (
    ANALI_OT_SelectCSVPath,
    ANALI_OT_DetectCSV,
    ANALI_OT_CalculateCSVMetricStats,
    ANALI_OT_ContextHelp,
    ANALI_OT_ContextHelpES,
    ANALI_OT_CreateCSVGroup,
    ANALI_OT_RemoveCSVGroup,
    ANALI_OT_SelectCSVGroupMembers,
    OBJECT_OT_CalculateMetrics,
    ANALI_OT_ImportDataLoggerMeshMetrics,
    ANALI_OT_SelectDataLoggerMeshMetricsFile,
    ANALI_OT_ClearGraphs,
    ANALI_OT_RestoreSceneObjects,
    ANALI_OT_G1ChangeWindow,
    ANALI_OT_G1Prev, ANALI_OT_G1PrevES, ANALI_OT_G1Next, ANALI_OT_G1NextES,
    ANALI_OT_VisualizeGraph,
    ANALI_OT_VisualizeTable,
    ANALI_OT_ClearTables,
    ANALI_OT_TableChangePage,
    ANALI_OT_TableRowPrev, ANALI_OT_TableRowPrevES, ANALI_OT_TableRowNext, ANALI_OT_TableRowNextES,
    ANALI_OT_TableColPrev, ANALI_OT_TableColPrevES, ANALI_OT_TableColNext, ANALI_OT_TableColNextES,
    ANALI_OT_AddDataMeshPair,
    ANALI_OT_RemoveDataMeshPair,
)
from .ui_panels import ANALI_UL_CSVList, ANALI_UL_CSVGroupList, ANALI_UL_AnalysisList, ANALI_PT_MainPanel





LANGUAGE_ITEMS = (
    (LANG_EN, "English", "Display the add-on in English"),
    (LANG_ES, "Español", "Mostrar el complemento en español"),
)

# Enum definitions keep one English source of truth. Spanish lives in texts.py.
_TAB_ITEMS = (
    ('DATA', UI_TEXT['TAB_DATA'], UI_TEXT.get('TAB_DATA_DESC', 'Data files and statistics')),
    ('MESH', UI_TEXT['TAB_MODELS'], UI_TEXT.get('TAB_MODELS_DESC', 'Model analysis')),
    ('TABLES', UI_TEXT['TAB_TABLES'], UI_TEXT.get('TAB_TABLES_DESC', '3D metric tables')),
    ('GRAPHS', UI_TEXT['TAB_GRAPHS'], UI_TEXT.get('TAB_GRAPHS_DESC', 'Graph configuration')),
)

_TABLE_STAT_ITEMS = (
    ('MEAN', 'Mean', 'Arithmetic mean of each metric series'),
    ('RAW', 'All raw values', 'Show every recorded value without aggregation'),
    ('MEDIAN', 'Median', 'Median of each metric series'),
    ('STD', 'Standard deviation', 'Sample standard deviation'),
    ('MIN', 'Minimum', 'Smallest observed value'),
    ('MAX', 'Maximum', 'Largest observed value'),
    ('SUM', 'Sum', 'Sum of all observed values'),
    ('COUNT', 'Count', 'Number of valid observations'),
    ('LAST', 'Last value', 'Last valid observed value'),
)

_HEATMAP_MODE_ITEMS = (
    ('CSV_MESH', 'Data ↔ Model', 'Correlate data behaviour metrics with calculated model metrics using paired data and model observations'),
    ('CSV_CSV', 'Data ↔ Data', 'Correlate data behaviour metrics with one another across the selected data files'),
    ('MESH_MESH', 'Model ↔ Model', 'Correlate calculated model metrics with one another across the analysed model objects'),
)

_ANALYSIS_MODE_ITEMS = (
    ('DESCRIPTIVE', 'Descriptive', 'Describe the selected observations'),
    ('COMPARATIVE', 'Comparative', 'Compare the selected observations'),
    ('INFERENTIAL', 'Inferential', 'Evaluate inferential relationships between observations'),
)

_OCTREE_LIMIT_ITEMS = (
    ('DEPTH', 'Maximum subdivisions', 'Stop after the selected maximum octree depth'),
    ('ELEMENTS', 'Maximum elements', 'Subdivide until each leaf contains at most the selected number of vertices'),
    ('BOTH', 'Both limits', 'Stop when either the depth or element limit is reached'),
)

_G1_DISPLAY_ITEMS = (
    ('BANDS', 'Bands', 'One independent vertical band per metric'),
    ('OVERLAY', 'Overlay', 'All metrics superimposed; each metric keeps its own real Y range'),
)

_TABLE_SOURCE_ITEMS = (
    ('DATA', 'Data metrics', 'Display metrics calculated from the selected data files'),
    ('MESH', 'Model metrics', 'Display metrics calculated for analysed model objects'),
)

_COLOR_PALETTE_ITEMS = (
    ('ibm_color_blind_safe', 'IBM Color Blind Safe', 'Accessible categorical palette'),
    ('viridis', 'Viridis', 'Perceptually uniform palette'),
    ('inferno', 'Inferno', 'High-contrast perceptually uniform palette'),
    ('plasma', 'Plasma', 'Vivid purple-to-yellow palette'),
    ('magma', 'Magma', 'Dark purple-to-yellow palette'),
    ('cividis', 'Cividis', 'Color-vision-friendly uniform palette'),
    ('turbo', 'Turbo', 'Broad high-contrast rainbow palette'),
    ('coolwarm', 'Coolwarm', 'Diverging blue-to-red palette'),
)


def _enum_scene(self, context):
    return getattr(context, 'scene', None) if context is not None else self


def _heatmap_mode_items(self, context):
    return translate_enum_items(_enum_scene(self, context), _HEATMAP_MODE_ITEMS)


def _tab_items(self, context):
    return translate_enum_items(_enum_scene(self, context), _TAB_ITEMS)


def _table_stat_items(self, context):
    return translate_enum_items(_enum_scene(self, context), _TABLE_STAT_ITEMS)

def _table_source_items(self, context):
    return translate_enum_items(_enum_scene(self, context), _TABLE_SOURCE_ITEMS)


def _analysis_mode_items(self, context):
    return translate_enum_items(_enum_scene(self, context), _ANALYSIS_MODE_ITEMS)


def _octree_limit_items(self, context):
    return translate_enum_items(_enum_scene(self, context), _OCTREE_LIMIT_ITEMS)


def _g1_display_items(self, context):
    return translate_enum_items(_enum_scene(self, context), _G1_DISPLAY_ITEMS)



def _color_palette_items(self, context):
    return translate_enum_items(_enum_scene(self, context), _COLOR_PALETTE_ITEMS)


_GRAPH_DESCRIPTIONS = {
    "G1": "Show selected metrics through ordered samples to inspect trends, peaks and pauses",
    "G2": "Compare central values and spread across files, groups or mesh observations",
    "G3": "Compare normalized multivariate profiles from data metrics, mesh metrics or associations",
    "G4": "Inspect Pearson correlations between selected data and/or mesh metrics",
}

_GRAPH_ENUM_ITEMS = tuple(
    (
        key,
        value["label"],
        _GRAPH_DESCRIPTIONS.get(key, UI_TEXT['GRAPH_TYPE']),
    )
    for key, value in GRAPH_TYPES.items()
)


def _graph_items(self, context):
    return translate_enum_items(_enum_scene(self, context), _GRAPH_ENUM_ITEMS)


def _update_language(self, context):
    """Redraw every Blender window after changing the add-on language."""
    window_manager = getattr(context, "window_manager", None) if context else None
    if window_manager is None:
        return
    for window in window_manager.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            area.tag_redraw()


def _update_log_scale(self, context):
    if getattr(self, "anali_use_log_scale", False):
        self.anali_use_compact_labels = False


def _update_compact_labels(self, context):
    if getattr(self, "anali_use_compact_labels", False):
        self.anali_use_log_scale = False


def _update_ui_tab(self, context):
    """Ensure the shared metric list exists as soon as Tables or Graphs opens."""
    if context is None or getattr(context, "scene", None) is None:
        return
    scene = context.scene
    if getattr(scene, "anali_ui_tab", "") in {'TABLES', 'GRAPHS'} and len(scene.analysis_items) == 0:
        refresh_analysis_list(None, context)
    if getattr(context, "screen", None) is not None:
        for area in context.screen.areas:
            area.tag_redraw()

CLASSES = (
    MetricStatItem,
    CSVItem,
    CSVGroupItem,
    AnalysisItem,
    DataMeshPairItem,
    ANALI_OT_SelectCSVPath,
    ANALI_OT_DetectCSV,
    ANALI_OT_CalculateCSVMetricStats,
    ANALI_OT_ContextHelp,
    ANALI_OT_ContextHelpES,
    ANALI_OT_CreateCSVGroup,
    ANALI_OT_RemoveCSVGroup,
    ANALI_OT_SelectCSVGroupMembers,
    OBJECT_OT_CalculateMetrics,
    ANALI_OT_ImportDataLoggerMeshMetrics,
    ANALI_OT_SelectDataLoggerMeshMetricsFile,
    ANALI_OT_ClearGraphs,
    ANALI_OT_RestoreSceneObjects,
    ANALI_OT_G1ChangeWindow,
    ANALI_OT_G1Prev, ANALI_OT_G1PrevES, ANALI_OT_G1Next, ANALI_OT_G1NextES,
    ANALI_OT_VisualizeGraph,
    ANALI_OT_VisualizeTable,
    ANALI_OT_ClearTables,
    ANALI_OT_TableChangePage,
    ANALI_OT_TableRowPrev, ANALI_OT_TableRowPrevES, ANALI_OT_TableRowNext, ANALI_OT_TableRowNextES,
    ANALI_OT_TableColPrev, ANALI_OT_TableColPrevES, ANALI_OT_TableColNext, ANALI_OT_TableColNextES,
    ANALI_OT_AddDataMeshPair,
    ANALI_OT_RemoveDataMeshPair,
    ANALI_UL_CSVList,
    ANALI_UL_CSVGroupList,
    ANALI_UL_AnalysisList,
    ANALI_PT_MainPanel,
)


def register() -> None:
    registered_classes = []
    try:
        for cls in CLASSES:
            bpy.utils.register_class(cls)
            registered_classes.append(cls)

        bpy.types.Scene.csv_items = CollectionProperty(type=CSVItem)
        bpy.types.Scene.csv_groups = CollectionProperty(type=CSVGroupItem)
        bpy.types.Scene.csv_group_index = IntProperty(default=0)
        bpy.types.Scene.analysis_items = CollectionProperty(type=AnalysisItem)
        bpy.types.Scene.anali_data_mesh_pairs = CollectionProperty(type=DataMeshPairItem)
        bpy.types.Scene.anali_data_mesh_pair_index = IntProperty(default=0, min=0)
        bpy.types.Scene.metric_stats = CollectionProperty(type=MetricStatItem)
        bpy.types.Scene.csv_index = IntProperty(default=0)
        bpy.types.Scene.analysis_index = IntProperty(default=0)
        bpy.types.Scene.csv_folder = StringProperty(subtype='DIR_PATH')
        bpy.types.Scene.anali_data_logger_mesh_file = StringProperty(
            name=UI_TEXT['DATA_LOGGER_MESH_METRICS_FILE'],
            description=UI_TEXT['EXTERNAL_JSON_OR_CSV_FILE_CONTAINING_DATA_LOGGER_MESH_METRICS'],
            subtype='FILE_PATH',
            default="",
        )

        # Register the language first. Dynamic enum callbacks below can then read
        # scene.anali_language safely during RNA registration in Blender 4.3/4.5.
        bpy.types.Scene.anali_language = EnumProperty(
            name=UI_TEXT['LANGUAGE_IDIOMA'],
            items=LANGUAGE_ITEMS,
            default=LANG_EN,
            update=_update_language,
        )

        bpy.types.Scene.selected_graph = EnumProperty(
            name=UI_TEXT['GRAPH'],
            items=_graph_items,
            default=0,
            update=refresh_analysis_list,
        )
        # Static RNA items are required for reliable registration in Blender 4.3.
        # The panel draws translated prop_enum buttons, so the visible labels still
        # change automatically with the add-on language.
        bpy.types.Scene.anali_heatmap_correlation_mode = EnumProperty(
            name=UI_TEXT['CORRELATION_TYPE'],
            description=UI_TEXT['CHOOSE_WHICH_METRIC_FAMILIES_ARE_CORRELATED_IN_THE_PEARSON_HEATMAP'],
            items=_heatmap_mode_items,
            default=0,
        )

        bpy.types.Scene.anali_corr_csv_metrics = BoolVectorProperty(
            name=UI_TEXT['DATA_METRICS'],
            description=UI_TEXT['CHOOSE_WHICH_DATA_METRICS_ARE_INCLUDED_IN_THE_CORRELATION_GRAPH'],
            size=len(ANALYSIS),
            default=tuple(True for _ in ANALYSIS),
        )
        bpy.types.Scene.anali_corr_mesh_metrics = BoolVectorProperty(
            name=UI_TEXT['MESH_METRICS'],
            description=UI_TEXT['CHOOSE_WHICH_MESH_METRICS_ARE_INCLUDED_IN_THE_CORRELATION_GRAPH'],
            size=19,
            default=(True,) * 19,
        )
        bpy.types.Scene.anali_graph_mesh_metrics = BoolVectorProperty(
            name=UI_TEXT['MESH_METRICS'],
            description=UI_TEXT['CHOOSE_WHICH_MESH_METRICS_ARE_INCLUDED_IN_G2_AND_G3'],
            size=19,
            default=(False,) * 19,
        )

        bpy.types.Scene.analysis_mode = EnumProperty(
            name=UI_TEXT['MODE'],
            items=_analysis_mode_items,
            default=0,
        )
        bpy.types.Scene.reference_obj = PointerProperty(name=UI_TEXT['REFERENCE_OBJECT'], type=bpy.types.Object, poll=lambda self, obj: obj.type == 'MESH')
        bpy.types.Scene.anali_octree_limit_mode = EnumProperty(
            name=UI_TEXT['OCTREE_LIMIT'],
            items=_octree_limit_items,
            default=2,
        )
        bpy.types.Scene.anali_octree_max_depth = IntProperty(
            name=UI_TEXT['MAXIMUM_SUBDIVISIONS'],
            description=UI_TEXT['MAXIMUM_OCTREE_DEPTH_USED_BY_GEOMETRIC_SIMILARITY'],
            default=8,
            min=1,
            max=24,
        )
        bpy.types.Scene.anali_octree_max_items = IntProperty(
            name=UI_TEXT['ELEMENTS_PER_NODE'],
            description=UI_TEXT['MAXIMUM_VERTICES_STORED_IN_AN_OCTREE_LEAF'],
            default=32,
            min=1,
            max=4096,
        )
        bpy.types.Scene.axis_scale_x = FloatProperty(name=UI_TEXT['SCALE_X'], default=5.0, min=0.1)
        bpy.types.Scene.axis_scale_y = FloatProperty(name=UI_TEXT['SCALE_Y'], default=5.0, min=0.1)
        bpy.types.Scene.axis_scale_z = FloatProperty(name=UI_TEXT['SCALE_Z'], default=1.5, min=0.1)
        bpy.types.Scene.anali_use_log_scale = BoolProperty(
            name=UI_TEXT['LOG_SCALE'],
            default=False,
            update=_update_log_scale,
        )
        bpy.types.Scene.anali_use_compact_labels = BoolProperty(
            name=UI_TEXT['COMPACT_LABELS'],
            default=False,
            update=_update_compact_labels,
        )
        bpy.types.Scene.anali_g1_window_size = FloatProperty(
            name=UI_TEXT['G1_WINDOW_PERCENTAGE'],
            description="",
            default=20.0,
            min=1.0,
            max=100.0,
            subtype='PERCENTAGE',
        )
        bpy.types.Scene.anali_g1_last_total_rows = IntProperty(
            name=UI_TEXT['G1_AVAILABLE_ROWS'],
            default=1,
            min=1,
            options={'HIDDEN'},
        )
        bpy.types.Scene.anali_g1_window_start = IntProperty(
            name=UI_TEXT['G1_WINDOW_START'],
            description="",
            default=0,
            min=0,
            max=100000000,
        )
        bpy.types.Scene.anali_g1_global_view = BoolProperty(
            name=UI_TEXT['G1_GLOBAL_VIEW'],
            description="",
            default=True,
        )
        bpy.types.Scene.anali_g1_display_mode = EnumProperty(
            name=UI_TEXT['G1_DISPLAY_MODE'],
            description="",
            items=_g1_display_items,
            default=0,
        )
        bpy.types.Scene.anali_radar_margin = FloatProperty(
            name=UI_TEXT['RADAR_MARGIN'],
            description="",
            default=0.10,
            min=0.0,
            max=0.20,
            subtype='PERCENTAGE',
        )
        bpy.types.Scene.anali_color_palette = EnumProperty(
            name=UI_TEXT['COLOR_PALETTE'],
            items=_color_palette_items,
            default=0,
        )
        bpy.types.Scene.anali_ui_tab = EnumProperty(
            name=UI_TEXT['SECTION'],
            items=_tab_items,
            update=_update_ui_tab,
        )
        bpy.types.Scene.anali_show_csv_import = BoolProperty(name=UI_TEXT['SHOW_DATA_IMPORT'], default=True)
        bpy.types.Scene.anali_show_global_metrics = BoolProperty(name=UI_TEXT['SHOW_GLOBAL_METRICS'], default=True)
        bpy.types.Scene.anali_show_mesh_binding = BoolProperty(name=UI_TEXT['SHOW_BINDING'], default=True)
        bpy.types.Scene.anali_show_model_metrics = BoolProperty(name=UI_TEXT['SHOW_MESH_METRICS'], default=True)
        bpy.types.Scene.anali_show_data_mesh_pairs = BoolProperty(name=UI_TEXT['SHOW_DATA_AND_MESH_ASSOCIATIONS'], default=True)
        bpy.types.Scene.anali_show_graph_config = BoolProperty(name=UI_TEXT['SHOW_VISUAL_SETTINGS'], default=True)
        bpy.types.Scene.anali_show_table_config = BoolProperty(name=UI_TEXT['SHOW_TABLE_SETTINGS'], default=True)
        bpy.types.Scene.anali_show_actions_config = BoolProperty(name=UI_TEXT['SHOW_TABLE_CONTROLSETTINGS'], default=True)
        bpy.types.Scene.anali_show_layout_config = BoolProperty(name=UI_TEXT['SHOW_TABLE_LAYOUT_SETTINGS'], default=True)
        bpy.types.Scene.anali_table_statistic = EnumProperty(
            name=UI_TEXT['VALUE'],
            items=_table_stat_items,
        )
        bpy.types.Scene.anali_table_source = EnumProperty(
            name=UI_TEXT['TABLE_DATA_SOURCE'],
            description="",
            items=_table_source_items,
        )
        bpy.types.Scene.anali_table_rows_per_page = IntProperty(name=UI_TEXT['ROWS_PER_PAGE'], default=10, min=1, max=30)
        bpy.types.Scene.anali_table_cols_per_page = IntProperty(name=UI_TEXT['COLUMNS_PER_PAGE'], default=4, min=1, max=8)
        bpy.types.Scene.anali_table_row_page = IntProperty(name=UI_TEXT['ROW_PAGE'], default=1, min=1, max=10000, soft_max=50)
        bpy.types.Scene.anali_table_col_page = IntProperty(name=UI_TEXT['COLUMN_PAGE'], default=1, min=1, max=10000, soft_max=50)
        bpy.types.Scene.anali_show_render_controls = BoolProperty(name=UI_TEXT['SHOW_RENDER_CONTROLS'], default=True)
        bpy.types.Scene.anali_target_obj = PointerProperty(name=UI_TEXT['OBJECT'], type=bpy.types.Object, poll=lambda self, obj: obj.type == 'MESH')
        metric_binding_items = [(key, value['label'], '') for key, value in ANALYSIS.items()]
        bpy.types.Scene.anali_bind_x_metric = EnumProperty(name=UI_TEXT['DATA_X'], items=metric_binding_items, default='A1')
        bpy.types.Scene.anali_bind_y_metric = EnumProperty(name=UI_TEXT['DATA_Y'], items=metric_binding_items, default='A4')
        bpy.types.Scene.anali_bind_z_metric = EnumProperty(name=UI_TEXT['DATA_Z'], items=metric_binding_items, default='A5')
        bpy.types.Scene.anali_bind_size_metric = EnumProperty(name=UI_TEXT['DATA_SIZE'], items=metric_binding_items, default='A16')

        if getattr(bpy.context, "scene", None) is not None:
            scene = bpy.context.scene
            if not getattr(scene, "anali_ui_tab", ""):
                scene.anali_ui_tab = 'DATA'
            if not getattr(scene, "anali_table_statistic", ""):
                scene.anali_table_statistic = 'MEAN'
            if not getattr(scene, "anali_table_source", ""):
                scene.anali_table_source = 'DATA'
            refresh_analysis_list(None, bpy.context)
    except Exception:
        # Roll back a partial registration so a failed property does not leave
        # panels active without their Scene properties.
        for prop in [
            "csv_items", "csv_groups", "csv_group_index", "analysis_items", "anali_data_mesh_pairs", "anali_data_mesh_pair_index", "metric_stats", "csv_index", "analysis_index",
            "csv_folder", "anali_data_logger_mesh_file", "selected_graph", "anali_heatmap_correlation_mode", "anali_corr_csv_metrics", "anali_corr_mesh_metrics", "anali_graph_mesh_metrics", "analysis_mode", "reference_obj",
            "anali_octree_limit_mode", "anali_octree_max_depth", "anali_octree_max_items",
            "axis_scale_x", "axis_scale_y", "axis_scale_z", "anali_use_log_scale",
            "anali_use_compact_labels", "anali_g1_window_size", "anali_g1_last_total_rows", "anali_g1_window_start", "anali_g1_global_view", "anali_g1_display_mode", "anali_radar_margin", "anali_color_palette", "anali_language",
            "anali_ui_tab", "anali_show_csv_import", "anali_show_global_metrics",
            "anali_show_mesh_binding", "anali_show_model_metrics", "anali_show_data_mesh_pairs",
            "anali_show_graph_config", "anali_show_table_config", "anali_show_layout_config", "anali_show_actions_config", "anali_table_statistic", "anali_table_source", "anali_table_rows_per_page", "anali_table_cols_per_page", "anali_table_row_page", "anali_table_col_page", "anali_show_render_controls",
            "anali_target_obj", "anali_bind_x_metric", "anali_bind_y_metric",
            "anali_bind_z_metric", "anali_bind_size_metric",
        ]:
            if hasattr(bpy.types.Scene, prop):
                delattr(bpy.types.Scene, prop)
        for cls in reversed(registered_classes):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
        raise

def unregister() -> None:
    for prop in [
        "csv_items", "csv_groups", "csv_group_index", "analysis_items", "anali_data_mesh_pairs", "anali_data_mesh_pair_index", "metric_stats", "csv_index", "analysis_index",
        "csv_folder", "selected_graph", "anali_heatmap_correlation_mode", "anali_corr_csv_metrics", "anali_corr_mesh_metrics", "anali_graph_mesh_metrics", "analysis_mode", "reference_obj",
            "anali_octree_limit_mode", "anali_octree_max_depth", "anali_octree_max_items",
        "axis_scale_x", "axis_scale_y", "axis_scale_z", "anali_use_log_scale", "anali_use_compact_labels", "anali_g1_window_size", "anali_g1_last_total_rows", "anali_g1_window_start", "anali_g1_global_view", "anali_g1_display_mode", "anali_radar_margin", "anali_color_palette", "anali_language", "anali_ui_tab",
        "anali_show_csv_import", "anali_show_global_metrics", "anali_show_mesh_binding",
        "anali_show_model_metrics", "anali_show_graph_config", "anali_show_table_config", "anali_show_layout_config", "anali_show_actions_config",  "anali_table_statistic", "anali_table_source", "anali_table_rows_per_page", "anali_table_cols_per_page", "anali_table_row_page", "anali_table_col_page", "anali_show_render_controls",
        "anali_target_obj", "anali_bind_x_metric", "anali_bind_y_metric",
        "anali_bind_z_metric", "anali_bind_size_metric",
    ]:
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)

    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

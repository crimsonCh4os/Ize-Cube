# Herramientas para la monitorización y análisis de procesos de modelado 3D en Blender
# Copyright (C) 2026 María Molina Goyena
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# at your option any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.

"""Dependency installer UI that loads without NumPy or Matplotlib."""
from __future__ import annotations
from .texts import UI_TEXT

import bpy

from .dependencies import dependencies_available, install_dependencies, missing_dependencies


class ANALI_OT_InstallDependencies(bpy.types.Operator):
    bl_idname = "anali.install_dependencies"
    bl_label = UI_TEXT['INSTALL_DEPENDENCIES_INSTALAR_DEPENDENCIAS']
    bl_description = (
        "Descarga e instala las dependencias binarias compatibles con Python 3.13 desde PyPI"
    )
    bl_options = {'REGISTER'}

    def execute(self, context):
        del context
        try:
            install_dependencies()
        except Exception as exc:
            self.report({'ERROR'}, f"Installation failed / Instalación fallida: {exc}")
            return {'CANCELLED'}

        self.report(
            {'INFO'},
            "Dependencies installed. Restart Blender. / Dependencias instaladas. Reinicia Blender.",
        )
        return {'FINISHED'}


class ANALI_PT_DependencyBootstrap(bpy.types.Panel):
    bl_label = UI_TEXT['ANALYSIS_3D_DEPENDENCIES_DEPENDENCIAS']
    bl_category = "Ize Insights"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'

    def draw(self, context):
        del context
        layout = self.layout
        missing = missing_dependencies()
        if not missing:
            layout.label(text=UI_TEXT['DEPENDENCIES_INSTALLED_DEPENDENCIAS_INSTALADAS'], icon='CHECKMARK')
            layout.label(text=UI_TEXT['RESTART_BLENDER_REINICIA_BLENDER'], icon='INFO')
            return

        box = layout.box()
        box.label(text=UI_TEXT['REQUIRED_LIBRARIES_ARE_MISSING'], icon='ERROR')
        box.label(text=UI_TEXT['FALTAN_BIBLIOTECAS_NECESARIAS'])
        box.label(text=UI_TEXT['MISSING_FALTAN_PREFIX'] + ', '.join(missing))
        box.operator(ANALI_OT_InstallDependencies.bl_idname, icon='IMPORT')
        box.label(text='Python 3.13 · Windows x64', icon='PACKAGE')
        box.label(text='Requiere conexión a Internet durante la instalación')
        box.label(text=UI_TEXT['RESTART_BLENDER_AFTERWARDS_REINICIA_BLENDER_DESPU_S'], icon='INFO')


_BOOTSTRAP_CLASSES = (ANALI_OT_InstallDependencies, ANALI_PT_DependencyBootstrap)


def _registered_class(cls):
    """Return Blender's currently registered class with the same Python name."""
    return getattr(bpy.types, cls.__name__, None)


def _safe_register_class(cls) -> None:
    """Register a class safely when an older add-on copy is still loaded."""
    existing = _registered_class(cls)
    if existing is cls:
        return

    # Installing an updated ZIP can leave the previous class object registered
    # until Blender finishes replacing the add-on. Remove that stale class first.
    if existing is not None:
        try:
            bpy.utils.unregister_class(existing)
        except (RuntimeError, ValueError):
            pass

    try:
        bpy.utils.register_class(cls)
    except (RuntimeError, ValueError) as exc:
        # Ignore only a genuine already-registered state; propagate other errors.
        current = _registered_class(cls)
        if current is not cls:
            raise exc


def _safe_unregister_class(cls) -> None:
    """Unregister only the class currently owned by this module."""
    existing = _registered_class(cls)
    if existing is None:
        return
    try:
        bpy.utils.unregister_class(existing)
    except (RuntimeError, ValueError):
        pass


def register_bootstrap() -> None:
    for cls in _BOOTSTRAP_CLASSES:
        _safe_register_class(cls)


def unregister_bootstrap() -> None:
    for cls in reversed(_BOOTSTRAP_CLASSES):
        _safe_unregister_class(cls)


def register_operator_only() -> None:
    _safe_register_class(ANALI_OT_InstallDependencies)


def unregister_operator_only() -> None:
    _safe_unregister_class(ANALI_OT_InstallDependencies)

# Tools for monitoring and analysing 3D modelling workflows in Blender
# Copyright (C) 2026 María Molina Goyena
# SPDX-License-Identifier: GPL-3.0-or-later

"""CSV compatibility and validation for Ize Logger / Ize Insights.

The normalised schema is intentionally compact. Current Ize Logger files use
schema v4. Historical v1/v2/v3 files remain readable; legacy columns are mapped to
the current names where needed instead of being reproduced in new exports.
"""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

SCHEMA_VERSION_V1 = 1
SCHEMA_VERSION_V2 = 2
SCHEMA_VERSION_V3 = 3
SCHEMA_VERSION_V4 = 4

CSV_HEADER_V4 = [
    "SchemaVersion", "LoggerVersion", "SessionID", "UserID",
    "TimeStamp",
    "UserX", "UserY", "UserZ",
    "ObjX", "ObjY", "ObjZ", "ObjRadius", "ObjectTransform",
    "VertexDelta", "NgonDelta", "TriDelta", "NormalDelta", "NonManifoldDelta",
    "ObjModeState", "EditModeState", "ModeChanged",
    "UVDeploy",
    "ObjectDelta", "ObjectCreated", "ObjectDeleted",
    "ModifierDelta", "ModifierCreated", "ModifierDeleted",
    "Duplicate", "Instance", "Undo", "Occlusion", "Orthographic",
]

# Backwards-compatible aliases used by the CSV-group materialiser and legacy code.
CSV_HEADER_V3 = CSV_HEADER_V4
CSV_HEADER_V2 = CSV_HEADER_V4

NUMERIC_COLUMNS = set(CSV_HEADER_V4) - {
    "LoggerVersion", "SessionID", "UserID"
}


def _norm(name: Any) -> str:
    return str(name).strip().lstrip("\ufeff")


def _float(mapping: Mapping[str, Any], *keys: str, default: float = 0.0) -> float:
    for key in keys:
        value = mapping.get(key, "")
        if value not in (None, ""):
            try:
                return float(str(value).strip().replace(",", "."))
            except (TypeError, ValueError):
                continue
    return default


def detect_schema_version(fieldnames: Iterable[str] | None) -> int:
    """Detect logger CSV generations, including anonymised historical files.

    User identifiers are optional metadata and must never be required to decide
    whether a CSV is a valid Ize Logger export. Older/anonymised exports may
    contain neither ``SchemaVersion`` nor ``USER_ID``. In that case we detect
    the schema from the stable workflow columns instead.
    """
    names = {_norm(name) for name in (fieldnames or []) if _norm(name)}

    if "SchemaVersion" in names:
        # Header inspection alone cannot distinguish modern schema generations;
        # they are normalized by the same path.
        return SCHEMA_VERSION_V4
    if "USER_ID" in names:
        return SCHEMA_VERSION_V1

    # Current/modern exports without metadata (for example anonymised or files
    # processed by external tools).  These semantic columns did not exist in
    # the original v1 layout.
    modern_markers = {
        "ObjectTransform", "ModeChanged", "ObjectCreated", "ObjectDeleted",
        "ModifierCreated", "ModifierDeleted", "Duplicate", "Instance",
        "NonManifoldDelta", "Occlusion",
    }
    if "TimeStamp" in names and modern_markers.intersection(names):
        return SCHEMA_VERSION_V4

    # Legacy v1 exports can legitimately lack USER_ID after anonymisation.
    # Require a distinctive set of logger columns so unrelated CSV files are
    # still rejected instead of being silently interpreted as workflow data.
    legacy_required = {
        "TimeStamp", "UserX", "UserY", "UserZ",
        "ObjX", "ObjY", "ObjZ", "ObjRadius",
        "VertexDelta", "NgonDelta", "TriDelta", "NormalDelta",
        "ObjModeState", "EditModeState", "ObjectDelta", "ModifierDelta",
    }
    if legacy_required.issubset(names):
        return SCHEMA_VERSION_V1

    raise ValueError(
        "CSV no reconocido: no contiene las columnas de un CSV de Ize Logger"
    )


def validate_header(fieldnames: Iterable[str] | None) -> dict[str, list[str] | int]:
    names = [_norm(name) for name in (fieldnames or [])]
    version = detect_schema_version(names)
    if version == SCHEMA_VERSION_V1:
        required = [
            "USER_ID", "TimeStamp", "UserX", "UserY", "UserZ",
            "ObjX", "ObjY", "ObjZ", "ObjRadius", "VertexDelta",
            "NgonDelta", "TriDelta", "NormalDelta",
            "ObjModeState", "EditModeState", "ObjectDelta", "ModifierDelta",
        ]
    else:
        required = [
            "SchemaVersion", "LoggerVersion", "SessionID", "UserID",
            "TimeStamp", "UserX", "UserY", "UserZ",
            "ObjX", "ObjY", "ObjZ", "ObjRadius", "VertexDelta",
            "NgonDelta", "TriDelta", "NormalDelta",
            "ObjModeState", "EditModeState", "ObjectDelta", "ModifierDelta",
        ]
    missing = [name for name in required if name not in names]
    extra = [name for name in names if name not in required]
    return {"schema_version": version, "missing": missing, "extra": extra}


def normalize_row(row: Mapping[str, Any]) -> dict[str, Any]:
    src = {_norm(k): v for k, v in row.items()}
    fieldnames = list(src.keys())
    version = detect_schema_version(fieldnames)

    result = {name: src.get(name, "") for name in CSV_HEADER_V4}
    if version == SCHEMA_VERSION_V1:
        result["SchemaVersion"] = "1"
        result["LoggerVersion"] = ""
        result["SessionID"] = ""
        result["UserID"] = src.get("USER_ID", "")
    else:
        result["SchemaVersion"] = str(src.get("SchemaVersion") or "2")

    # Current semantic columns derived from historical logger fields.
    result["ObjectTransform"] = int(bool(
        _float(src, "ObjectTransform")
        or _float(src, "ObjDeltaX") or _float(src, "ObjDeltaY")
        or _float(src, "ObjDeltaZ") or _float(src, "ObjDeltaRadius")
    ))
    result["UVDeploy"] = int(bool(
        _float(src, "UVDeploy")
        or (0.0 if "UVDeploy" in src else _float(src, "UVAction", "UV"))
    ))
    result["Duplicate"] = int(bool(
        _float(src, "Duplicate")
        or (0.0 if "Duplicate" in src else max(_float(src, "CtrlV"), _float(src, "ShiftD")))
    ))
    result["Instance"] = int(bool(
        _float(src, "Instance")
        or (0.0 if "Instance" in src else _float(src, "AltD"))
    ))
    result["Undo"] = int(bool(_float(src, "Undo")))
    result["Occlusion"] = int(bool(_float(src, "Occlusion", "OcclusionState", "Occluded")))
    result["Orthographic"] = int(bool(_float(src, "Orthographic", "OrthoState", "OrthographicState")))

    od = _float(src, "ObjectDelta")
    md = _float(src, "ModifierDelta")
    if result.get("ObjectCreated", "") in (None, ""):
        result["ObjectCreated"] = max(od, 0.0)
    if result.get("ObjectDeleted", "") in (None, ""):
        result["ObjectDeleted"] = max(-od, 0.0)
    if result.get("ModifierCreated", "") in (None, ""):
        result["ModifierCreated"] = max(md, 0.0)
    if result.get("ModifierDeleted", "") in (None, ""):
        result["ModifierDeleted"] = max(-md, 0.0)
    if result.get("NonManifoldDelta", "") in (None, ""):
        result["NonManifoldDelta"] = 0

    return result


def normalize_csv_rows(rows: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    return [normalize_row(row) for row in rows]


def coerce_numeric_row(row: Mapping[str, Any]) -> dict[str, Any]:
    """Convert numeric columns when possible; preserve metadata as text."""
    out = dict(row)
    for key in NUMERIC_COLUMNS:
        value = out.get(key, "")
        if value in (None, ""):
            out[key] = 0.0
            continue
        try:
            out[key] = float(str(value).strip().replace(",", "."))
        except (TypeError, ValueError):
            out[key] = 0.0
    return out

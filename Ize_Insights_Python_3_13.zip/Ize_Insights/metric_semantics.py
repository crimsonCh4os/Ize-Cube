# Central presentation semantics for Ize Insights metrics.

DATA_METRIC_PRESENTATION = {
    "A1":  {"kind":"continuous","visual":"continuous_line","short_en":"Session duration","short_es":"Duración de la sesión","unit_en":"min","unit_es":"min","radar_unit_en":"min","radar_unit_es":"min"},
    "A2":  {"kind":"continuous","visual":"continuous_line","short_en":"Pausses","short_es":"Pausas","unit_en":"min","unit_es":"min","radar_unit_en":"pauses","radar_unit_es":"pausas"},
    "A4":  {"kind":"continuous","visual":"continuous_line","short_en":"Navigation speed","short_es":"Velocidad de navegación","unit_en":"m/min","unit_es":"m/min","radar_unit_en":"local size/min","radar_unit_es":"tamaño local/min"},
    "A5":  {"kind":"continuous","visual":"continuous_line","short_en":"Distance to target","short_es":"Distancia al objetivo","unit_en":"m","unit_es":"m","radar_unit_en":"× local size","radar_unit_es":"× tamaño local"},
    "A6":  {"kind":"event","visual":"event_impulse","short_en":"Motion peaks","short_es":"Picos de movimiento","unit_en":"event","unit_es":"evento","radar_unit_en":"peaks/min","radar_unit_es":"picos/min"},
    "A17": {"kind":"state","visual":"categorical_step","short_en":"Non-occluded view","short_es":"Vista sin oclusión","unit_en":"state","unit_es":"estado","radar_unit_en":"% active","radar_unit_es":"% activo"},
    "A19": {"kind":"state","visual":"categorical_step","short_en":"Ortographic view","short_es":"Vista ortográfica","unit_en":"state","unit_es":"estado","radar_unit_en":"% active","radar_unit_es":"% activo"},
    "A12": {"kind":"balance","visual":"balance_zero_bar","short_en":"Vertex count","short_es":"Cantidad de vértices","unit_en":"vertex Δ","unit_es":"vértice Δ","radar_unit_en":"net/min","radar_unit_es":"neto/min"},
    "A13": {"kind":"balance","visual":"balance_zero_bar","short_en":"Topology issues","short_es":"Incidencias en la topología","unit_en":"issue Δ","unit_es":"incidencia Δ","radar_unit_en":"net/min","radar_unit_es":"neto/min"},
    "A16": {"kind":"balance","visual":"balance_zero_bar","short_en":"Object count","short_es":"Cantidad de objetos","unit_en":"object Δ","unit_es":"objeto Δ","radar_unit_en":"net/min","radar_unit_es":"neto/min"},
    "A14": {"kind":"state","visual":"categorical_step","short_en":"Work mode","short_es":"Modo de trabajo","unit_en":"state","unit_es":"estado","radar_unit_en":"state 0–2","radar_unit_es":"estado 0–2"},
    "A10": {"kind":"event","visual":"event_impulse","short_en":"Reuse actions","short_es":"Acciones de reutilización","unit_en":"events","unit_es":"eventos","radar_unit_en":"events/min","radar_unit_es":"eventos/min"},
    "A11": {"kind":"balance","visual":"balance_zero_bar","short_en":"Modifier usage","short_es":"Uso de modificadores","unit_en":"modifier Δ","unit_es":"modificador Δ","radar_unit_en":"net/min","radar_unit_es":"neto/min"},
    "A15": {"kind":"event","visual":"event_impulse","short_en":"UV editing","short_es":"Edición de UVs","unit_en":"event","unit_es":"evento","radar_unit_en":"actions/min","radar_unit_es":"acciones/min"},
    "A18": {"kind":"event","visual":"event_impulse","short_en":"Undo actions","short_es":"Acciones revertidas","unit_en":"event","unit_es":"evento","radar_unit_en":"events/min","radar_unit_es":"eventos/min"},
}


def metric_meta(key):
    return DATA_METRIC_PRESENTATION.get(key, {})


def metric_kind(key):
    return metric_meta(key).get("kind", "continuous")


def metric_unit(key, language="EN", radar=False):
    meta = metric_meta(key)
    suffix = "es" if str(language).upper() == "ES" else "en"
    field = f"radar_unit_{suffix}" if radar else f"unit_{suffix}"
    return meta.get(field, "")


def metric_short_label(key, language="EN"):
    meta = metric_meta(key)
    return meta.get("short_es" if str(language).upper() == "ES" else "short_en", key)


def metric_visual(key):
    return metric_meta(key).get("visual", "continuous_line")

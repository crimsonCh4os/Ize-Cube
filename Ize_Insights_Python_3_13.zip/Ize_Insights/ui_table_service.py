# Herramientas para la monitorización y análisis de procesos de modelado 3D en Blender
# Copyright (C) 2026 María Molina Goyena
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# at your option any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.

"""3D data-table generation for selected CSV metrics."""
from __future__ import annotations

import math
import os
import bpy
import numpy as np
from mathutils import Vector

from .analytics import ANALYSIS, compute_metrics_for_csv, series_to_array, _row_object_local_size, _csv_session_key, _row_time
from .constants import DEFAULT_MAX_REASONABLE_SPEED
from .graphs import create_axis, create_text_label, clear_previous_graphs, csv_color_by_index
from .ui_helpers import hide_non_graph_objects, frame_graph_camera, hide_viewport_guides, selected_csv_sources, scene_length_scale_m
from .utils import read_csv
from .texts import UI_TEXT, tr
from .metric_semantics import metric_unit as semantic_metric_unit



_METRIC_UNITS = {
    "A1": "min",
    "A2": "min",
    "A3": "min",
    "A4": "local size/min",
    "A5": "× local size",
    "A6": "peaks",
    "A7": "peaks",
    "A8": "peaks",
    "A9": "peaks",
    "A10": "events",
    "A11": "net modifiers",
    "A12": "net vertices",
    "A13": "net issues",
    "A14": "mode code",
    "A15": "events",
    "A16": "net objects",
    "A17": "% active",
    "A18": "events",
    "A19": "% active",
}


def _table_metrics_with_local_view_units(metrics, data):
    """Table-only copy with A4/A5 normalized by object local size and A6 recomputed from A4.

    Only the three view metrics requested for cross-user comparability are changed.
    All other table metrics keep their original values and units.
    """
    converted = {key: list(values) if isinstance(values, (list, tuple, np.ndarray)) else values for key, values in metrics.items()}
    sizes = np.asarray([_row_object_local_size(row) for row in data], dtype=float)
    positive_sizes = sizes[np.isfinite(sizes) & (sizes > 1e-12)]
    fallback = float(np.median(positive_sizes)) if positive_sizes.size else 1.0

    for key in ("A4", "A5"):
        vals = np.asarray(metrics.get(key, []), dtype=float)
        if vals.size == 0:
            continue
        out = vals.copy()
        n = min(vals.size, sizes.size)
        if n:
            denom = np.asarray(sizes[:n], dtype=float)
            denom = np.where(np.isfinite(denom) & (denom > 1e-12), denom, fallback)
            out[:n] = out[:n] / denom
        converted[key] = out.tolist()

    # Peak detection must use the normalized speed too; the peak unit remains a
    # count/state, but the classification no longer depends on world scale.
    local_speed = np.asarray(converted.get("A4", []), dtype=float)
    if local_speed.size and data:
        flags = np.zeros(local_speed.size, dtype=float)
        groups, current, current_key, previous_time = [], [], None, None
        for index, row in enumerate(data[:local_speed.size]):
            key = _csv_session_key(row, index)
            row_time = _row_time(row)
            if current and (key != current_key or (previous_time is not None and row_time < previous_time)):
                groups.append(current); current = []
            current.append(index); current_key = key; previous_time = row_time
        if current:
            groups.append(current)
        for indices in groups:
            vals = local_speed[np.asarray(indices, dtype=int)]
            positive = vals[np.isfinite(vals) & (vals > 0.0)]
            if positive.size:
                threshold = float(np.mean(positive) + 2.0 * np.std(positive))
                if threshold > 0.0:
                    idx = np.asarray(indices, dtype=int)
                    flags[idx] = np.where(np.isfinite(vals) & (vals >= threshold), 1.0, 0.0)
        converted["A6"] = flags.tolist()
    return converted


def _metric_unit(metric_key: str, statistic: str, scene=None) -> str:
    """Return a unit that matches the statistic actually displayed."""
    if statistic == 'COUNT':
        return tr(scene, UI_TEXT['VALUES']) if scene is not None else UI_TEXT['VALUES']

    # Signed delta metrics: SUM is the session net balance; other statistics
    # describe the per-row delta distribution and must not be labelled "net".
    signed_units = {
        "A11": ("modifiers", "net modifiers"),
        "A12": ("vertices", "net vertices"),
        "A13": ("issues", "net issues"),
        "A16": ("objects", "net objects"),
    }
    if metric_key in signed_units:
        per_row_unit, net_unit = signed_units[metric_key]
        unit = net_unit if statistic == 'SUM' else per_row_unit
    elif metric_key in {"A17", "A19"}:
        unit = "%" if statistic != 'RAW' else "state"
    else:
        unit = _METRIC_UNITS.get(metric_key, '')

    return tr(scene, unit) if scene is not None and unit else unit

def _stat_value(metric_key: str, values, statistic: str):
    arr = series_to_array(values)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return None

    if statistic == 'MEDIAN':
        value = float(np.median(arr))
    elif statistic == 'STD':
        value = float(np.std(arr, ddof=1)) if arr.size > 1 else 0.0
    elif statistic == 'MIN':
        value = float(np.min(arr))
    elif statistic == 'MAX':
        value = float(np.max(arr))
    elif statistic == 'SUM':
        value = float(np.sum(arr))
    elif statistic == 'COUNT':
        return float(arr.size)
    elif statistic == 'LAST':
        value = float(arr[-1])
    else:
        value = float(np.mean(arr))

    # State metrics are stored as 0/1. Aggregated table values should be displayed
    # as percentages when they describe prevalence; RAW keeps 0/1 untouched.
    if metric_key in {"A17", "A19"} and statistic in {'MEAN', 'MEDIAN', 'STD', 'MIN', 'MAX', 'LAST'}:
        value *= 100.0

    return value


def _stat_label(statistic: str, scene=None) -> str:
    label = {
        'MEAN': 'Mean', 'MEDIAN': 'Median', 'STD': 'Standard deviation',
        'MIN': 'Minimum', 'MAX': 'Maximum', 'SUM': 'Sum',
        'COUNT': 'Count', 'LAST': 'Last value', 'RAW': 'All raw values',
    }.get(statistic, statistic.title())
    return tr(scene, label) if scene is not None else label


def _format_cell(value) -> str:
    if value is None or not np.isfinite(value):
        return '—'
    return f"{float(value):.2f}"



def _format_metric_cell(metric_key, value, statistic, metrics=None, scene=None):
    if value is None or not np.isfinite(value):
        return '—'
    if metric_key == "A14":
        arr = series_to_array((metrics or {}).get("A14", [])) if metrics is not None else np.asarray([], dtype=float)
        arr = arr[np.isfinite(arr)]
        es = getattr(scene, "anali_language", "EN") == "ES" if scene is not None else False
        if statistic == 'MEAN' and arr.size:
            obj = 100.0 * float(np.mean(np.abs(arr - 1.0) <= 0.25))
            edit = 100.0 * float(np.mean(np.abs(arr - 2.0) <= 0.25))
            other = max(0.0, 100.0 - obj - edit)
            if other >= 0.5:
                return f"{'Obj' if es else 'Obj'} {obj:.0f}% · {'Edit' if es else 'Edit'} {edit:.0f}% · {'Otro' if es else 'Other'} {other:.0f}%"
            return f"Obj {obj:.0f}% · Edit {edit:.0f}%"
        if statistic in {'RAW', 'LAST', 'MIN', 'MAX', 'MEDIAN'}:
            code = int(round(float(value)))
            names = {0: ('Otro' if es else 'Other'), 1: ('Objeto' if es else 'Object'), 2: ('Edición' if es else 'Edit')}
            return names.get(code, f"{float(value):.2f}")
        return f"{float(value):.2f} (0/1/2)"
    if metric_key in {"A17", "A19"} and statistic != 'RAW':
        return f"{float(value):.1f}%"
    return _format_cell(value)

def _safe_name(value) -> str:
    return ''.join(ch if ch.isalnum() or ch in '_-' else '_' for ch in str(value))


def _table_prefix_cleanup(scene):
    for obj in list(scene.objects):
        if obj.name.startswith(('DataTable', 'TableGrid_', 'TableText_', 'TableTitle_', 'TableSubtitle_')):
            bpy.data.objects.remove(obj, do_unlink=True)


def clear_data_tables(scene):
    _table_prefix_cleanup(scene)


def _draw_line(x0, y0, x1, y1, name, color, z=0.0, thickness=0.008):
    create_axis(Vector((x0, y0, z)), Vector((x1, y1, z)), color, name, radius=thickness, vertices=6)




_MESH_METRIC_ORDER = [
    "N_faces", "N_meshes", "Face_by_mesh", "Angle", "Non_quads", "Non_quads_percentage",
    "Vertex_duplicate", "Vertex_duplicate_percentage", "Non_manifold", "Non_manifold_percentage",
    "Normal_count", "Normal_percentage", "UV_area", "UV_islands", "UV_stretch", "UV_textel_density",
    "Transformations", "Position", "Similarity",
]
_MESH_METRIC_LABELS = {
    "N_faces": "Polygon count",
    "N_meshes": "Mesh count",
    "Face_by_mesh": "Polygon per mesh",
    "Angle": "Mean edge angle",
    "Non_quads": "Non-quad polygon count",
    "Non_quads_percentage": "Non-quad polygon percentage",
    "Vertex_duplicate": "Duplicate vertices count",
    "Vertex_duplicate_percentage": "Duplicate vertices percentage",
    "Non_manifold": "Non-manifold vertex count",
    "Non_manifold_percentage": "Non-manifold vertex percentage",
    "Normal_count": "Inverted polygon normal count",
    "Normal_percentage": "Inverted polygon normal percentage",
    "UV_area": "UV coverage",
    "UV_islands": "Island count",
    "UV_stretch": "UV stretch percentage",
    "UV_textel_density": "Texel density deviation",
    "Transformations": "Transforms applied",
    "Position": "World origin alignment",
    "Similarity": "Similarity vs. Reference",
}
_MESH_METRIC_UNITS = {
    "N_faces": "polygons", "N_meshes": "meshes", "Face_by_mesh": "polygons/mesh", "Angle": "°",
    "Non_quads": "polygons", "Non_quads_percentage": "%",
    "Vertex_duplicate": "vertices", "Vertex_duplicate_percentage": "%",
    "Non_manifold": "vertices", "Non_manifold_percentage": "%",
    "Normal_count": "polygons", "Normal_percentage": "%",
    "UV_area": "%", "UV_islands": "islands", "UV_stretch": "%", "UV_textel_density": "%",
    "Similarity": "%",
}

def _plain_mapping(value):
    try:
        return {str(key): value[key] for key in value.keys()}
    except Exception:
        try:
            return dict(value)
        except Exception:
            return {}

def _generate_mesh_table(context, report):
    scn = context.scene
    flags = tuple(getattr(scn, 'anali_graph_mesh_metrics', (False,) * len(_MESH_METRIC_ORDER)))
    keys = [key for i, key in enumerate(_MESH_METRIC_ORDER) if i < len(flags) and flags[i]]
    records = []
    for name, values in _plain_mapping(scn.get('metrics_data', {})).items():
        records.append((str(name), _plain_mapping(values)))
    records.sort(key=lambda item: item[0].lower())
    if not records:
        report({'ERROR'}, tr(scn, UI_TEXT['CALCULATE_MESH_METRICS_BEFORE_CREATING_THE_TABLE']))
        return {'CANCELLED'}
    if not keys:
        report({'ERROR'}, tr(scn, UI_TEXT['SELECT_AT_LEAST_ONE_MESH_METRIC']))
        return {'CANCELLED'}
    rows_per_page=max(1,int(getattr(scn,'anali_table_rows_per_page',10))); cols_per_page=max(1,int(getattr(scn,'anali_table_cols_per_page',4)))
    rp=max(0,int(getattr(scn,'anali_table_row_page',1))-1); cp=max(0,int(getattr(scn,'anali_table_col_page',1))-1)
    cp=min(cp,max(0,math.ceil(len(keys)/cols_per_page)-1)); shown_keys=keys[cp*cols_per_page:(cp+1)*cols_per_page]
    rp=min(rp,max(0,math.ceil(len(records)/rows_per_page)-1)); shown=records[rp*rows_per_page:(rp+1)*rows_per_page]
    scn.anali_table_row_page=rp+1; scn.anali_table_col_page=cp+1
    clear_previous_graphs(scn); hide_non_graph_objects(scn); hide_viewport_guides(context)
    white=(0.94,0.94,0.97,1); subtle=(0.66,0.69,0.76,1); grid=(0.28,0.31,0.38,1); header=(0.80,0.84,0.92,1)
    percentage_keys = {"Non_quads_percentage", "Vertex_duplicate_percentage", "Non_manifold_percentage", "Normal_percentage", "UV_area", "UV_stretch", "UV_textel_density", "Similarity"}
    boolean_keys = {"Transformations", "Position"}

    def _mesh_cell_text(key, raw):
        if key in boolean_keys:
            if isinstance(raw, str):
                truth = raw.strip().lower() in {"1", "true", "yes", "sí", "si"}
            else:
                truth = bool(raw)
            return tr(scn, "Yes" if truth else "No")
        try:
            value = float(raw)
        except Exception:
            return '—'
        if key in percentage_keys:
            return f"{value:.2f}%"
        if key == "Angle":
            return f"{value:.2f}°"
        return _format_cell(value)

    headers=[]; widths=[]
    for key in shown_keys:
        label=tr(scn,_MESH_METRIC_LABELS.get(key,key)); unit=tr(scn,_MESH_METRIC_UNITS.get(key,'')); h=f"{label} ({unit})" if unit and key not in percentage_keys else label
        headers.append(h); vals=[]
        for _,data in shown:
            vals.append(_mesh_cell_text(key, data.get(key)))
        widths.append(max(2.35,min(5.2,0.115*max([len(h)]+[len(v) for v in vals])+0.72)))
    first=3.0; row_h=.62; table_w=first+sum(widths); table_h=row_h*(len(shown)+1); x0=-table_w/2; ytop=table_h/2; z=0
    create_text_label(tr(scn,UI_TEXT['MESH_METRICS_TABLE']),(0,ytop+1.15,z),.42,'TableTitle_Main',align_x='CENTER',color=white)
    create_text_label(f"{tr(scn,UI_TEXT['ROWS'])} {rp+1}/{max(1,math.ceil(len(records)/rows_per_page))} · {tr(scn,UI_TEXT['COLUMNS'])} {cp+1}/{max(1,math.ceil(len(keys)/cols_per_page))}",(0,ytop+.78,z),.22,'TableSubtitle_Main',align_x='CENTER',color=subtle)
    for r in range(len(shown)+2): _draw_line(x0,ytop-r*row_h,x0+table_w,ytop-r*row_h,f'TableGrid_H_{r}',grid,z=z)
    positions=[x0,x0+first]; run=x0+first; centers=[]
    for w in widths: centers.append(run+w*.5); run+=w; positions.append(run)
    for i,x in enumerate(positions): _draw_line(x,ytop,x,ytop-row_h*(len(shown)+1),f'TableGrid_V_{i}',grid,z=z)
    create_text_label(tr(scn,UI_TEXT['MESH_OBJECT']),(x0+.14,ytop-row_h*.66,z),.25,'TableText_Header_Mesh',align_x='LEFT',color=header)
    for i,h in enumerate(headers): create_text_label(h,(centers[i],ytop-row_h*.66,z),.20,f'TableText_Header_{i}',align_x='CENTER',color=header)
    for ri,(name,data) in enumerate(shown):
        y=ytop-row_h*(ri+1.66); create_text_label(name,(x0+.14,y,z),.22,f'TableText_Row_{ri}',align_x='LEFT',color=csv_color_by_index(ri,getattr(scn,'anali_color_palette',None)))
        for ci,key in enumerate(shown_keys):
            text = _mesh_cell_text(key, data.get(key))
            create_text_label(text,(centers[ci],y,z),.24,f'TableText_Cell_{ri}_{ci}',align_x='CENTER',color=white)
    frame_graph_camera(scn,scn); report({'INFO'},tr(scn,UI_TEXT['MESH_METRICS_TABLE_GENERATED'])); return {'FINISHED'}

def generate_data_table(context, report):
    scn = context.scene
    if getattr(scn, 'anali_table_source', 'DATA') == 'MESH':
        return _generate_mesh_table(context, report)

    # The list can be empty immediately after enabling the add-on or opening a
    # saved file. Initialise it here as a final safety net, without requiring
    # the user to change a graph option first.
    if len(scn.analysis_items) == 0:
        from .ui_helpers import refresh_analysis_list
        refresh_analysis_list(None, context)

    selected_csvs = selected_csv_sources(scn)
    metric_keys = [item.key for item in scn.analysis_items if item.enabled]
    if not selected_csvs:
        report({'ERROR'}, tr(scn, UI_TEXT['SELECT_AT_LEAST_ONE_CSV_FILE']))
        return {'CANCELLED'}
    if not metric_keys:
        report({'ERROR'}, tr(scn, UI_TEXT['SELECT_AT_LEAST_ONE_METRIC']))
        return {'CANCELLED'}

    statistic = getattr(scn, 'anali_table_statistic', 'MEAN')
    rows_per_page = max(1, int(getattr(scn, 'anali_table_rows_per_page', 10)))
    cols_per_page = max(1, int(getattr(scn, 'anali_table_cols_per_page', 4)))
    row_page = max(0, int(getattr(scn, 'anali_table_row_page', 1)) - 1)
    col_page = max(0, int(getattr(scn, 'anali_table_col_page', 1)) - 1)

    # Load all selected CSVs once. This supports both summary and raw modes.
    loaded = []
    for csv_idx, csv_path in enumerate(selected_csvs):
        try:
            _, data = read_csv(csv_path)
            metrics = compute_metrics_for_csv(
                data,
                max_reasonable_speed=getattr(scn, 'max_reasonable_speed', DEFAULT_MAX_REASONABLE_SPEED),
            )
            metrics = _table_metrics_with_local_view_units(metrics, data)
            loaded.append((os.path.basename(csv_path), metrics, csv_idx))
        except Exception as exc:
            print(f'[data table] {csv_path}: {exc}')

    if not loaded:
        report({'ERROR'}, tr(scn, UI_TEXT['NO_VALID_DATA_COULD_BE_LOADED_FOR_THE_TABLE']))
        return {'CANCELLED'}

    
    max_col_page = max(0, math.ceil(len(metric_keys) / cols_per_page) - 1)
    col_page = min(col_page, max_col_page)
    metric_slice = metric_keys[col_page * cols_per_page:(col_page + 1) * cols_per_page]

    raw_mode = statistic == 'RAW'
    all_rows = []
    if raw_mode:
        # One row per original observation index. Metrics with shorter series
        # show an em dash for missing positions; no mean or other aggregation is
        # performed.
        for csv_name, metrics, csv_idx in loaded:
            arrays = {key: series_to_array(metrics.get(key, [])) for key in metric_slice}
            max_len = max((arr.size for arr in arrays.values()), default=0)
            for sample_idx in range(max_len):
                values = [float(arr[sample_idx]) if sample_idx < arr.size else None for arr in arrays.values()]
                all_rows.append((csv_name, sample_idx + 1, values, csv_idx, metrics))
    else:
        for csv_name, metrics, csv_idx in loaded:
            values = [_stat_value(key, metrics.get(key, []), statistic) for key in metric_slice]
            all_rows.append((csv_name, None, values, csv_idx, metrics))

    if not all_rows:
        report({'ERROR'}, tr(scn, UI_TEXT['THE_SELECTED_METRICS_CONTAIN_NO_VALID_VALUES']))
        return {'CANCELLED'}

    max_row_page = max(0, math.ceil(len(all_rows) / rows_per_page) - 1)
    row_page = min(row_page, max_row_page)
    scn.anali_table_row_page = row_page + 1
    scn.anali_table_col_page = col_page + 1
    data_rows = all_rows[row_page * rows_per_page:(row_page + 1) * rows_per_page]

    # Tables and graphs are mutually exclusive visualisations. Remove every
    # previously generated Analysis3D graph/table object before drawing the
    # new table, while preserving the user's modelling objects.
    clear_previous_graphs(scn)
    hide_non_graph_objects(scn)
    hide_viewport_guides(context)

    white = (0.94, 0.94, 0.97, 1.0)
    subtle = (0.66, 0.69, 0.76, 1.0)
    grid = (0.28, 0.31, 0.38, 1.0)
    header = (0.80, 0.84, 0.92, 1.0)

    first_col_w = 3.0
    index_col_w = 1.15 if raw_mode else 0.0
    # Column widths include the translated metric name AND its unit. This keeps
    # headers such as "View speed (BU/h)" or long localized units readable.
    metric_headers = []
    metric_col_widths = []
    for key in metric_slice:
        label = tr(scn, ANALYSIS.get(key, {}).get('label', key))
        unit = _metric_unit(key, statistic, scn)
        header_text = f"{label} ({unit})" if unit else label
        metric_headers.append(header_text)
        # Consider the header and the longest value actually displayed on the
        # current page. Units and numeric magnitude therefore both affect width.
        metric_index = len(metric_headers) - 1
        shown_values = []
        for _csv_name, _sample_idx, row_values, _csv_idx, _metrics in data_rows:
            if metric_index < len(row_values):
                shown_values.append(_format_metric_cell(key, row_values[metric_index], statistic, _metrics, scn))
        longest_cell = max((len(value) for value in shown_values), default=1)
        required_chars = max(len(header_text), longest_cell)
        metric_col_widths.append(max(2.35, min(7.20, 0.115 * required_chars + 0.72)))
    row_h = 0.62
    table_w = first_col_w + index_col_w + sum(metric_col_widths)
    table_h = row_h * (len(data_rows) + 1)
    x0 = -table_w / 2.0
    y_top = table_h / 2.0
    z = 0.0

    title = tr(scn, UI_TEXT['RAW_DATA_TABLE_SELECTED_CSV_METRICS']) if raw_mode else tr(scn, UI_TEXT['DATA_TABLE_SELECTED_CSV_METRICS'])
    create_text_label(title, (0.0, y_top + 1.15, z), 0.42, 'TableTitle_Main', align_x='CENTER', color=white)
    if raw_mode:
        subtitle = f"{tr(scn, UI_TEXT['ALL_RECORDED_VALUES'])} · {tr(scn, UI_TEXT['NO_AGGREGATION'])} · {tr(scn, UI_TEXT['TWO_DECIMALS'])} · {tr(scn, UI_TEXT['ROWS'])} {row_page + 1}/{max_row_page + 1} · {tr(scn, UI_TEXT['COLUMNS'])} {col_page + 1}/{max_col_page + 1}"
    else:
        subtitle = f"{_stat_label(statistic, scn)} · {tr(scn, UI_TEXT['VALUES_SHOWN_WITH_TWO_DECIMALS'])} · {tr(scn, UI_TEXT['ROWS'])} {row_page + 1}/{max_row_page + 1} · {tr(scn, UI_TEXT['COLUMNS'])} {col_page + 1}/{max_col_page + 1}"
    create_text_label(subtitle, (0.0, y_top + 0.78, z), 0.22, 'TableSubtitle_Main', align_x='CENTER', color=subtle)

    for r in range(len(data_rows) + 2):
        y = y_top - r * row_h
        _draw_line(x0, y, x0 + table_w, y, f'TableGrid_H_{r}', grid, z=z)

    x_positions = [x0, x0 + first_col_w]
    if raw_mode:
        x_positions.append(x0 + first_col_w + index_col_w)
    metric_start = x0 + first_col_w + index_col_w
    running_x = metric_start
    metric_centers = []
    for width in metric_col_widths:
        metric_centers.append(running_x + width * 0.5)
        running_x += width
        x_positions.append(running_x)
    for c, x in enumerate(x_positions):
        _draw_line(x, y_top, x, y_top - row_h * (len(data_rows) + 1), f'TableGrid_V_{c}', grid, z=z)

    create_text_label(tr(scn, UI_TEXT['CSV_USER']), (x0 + 0.14, y_top - row_h * 0.66, z), 0.25, 'TableText_Header_CSV', align_x='LEFT', color=header)
    if raw_mode:
        create_text_label(tr(scn, UI_TEXT['ROW']), (x0 + first_col_w + index_col_w * 0.5, y_top - row_h * 0.66, z), 0.22, 'TableText_Header_Row', align_x='CENTER', color=header)
    for idx, key in enumerate(metric_slice):
        label_with_unit = metric_headers[idx]
        cx = metric_centers[idx]
        # Dynamic columns already account for units; only cap truly exceptional
        # labels rather than truncating every header at a fixed 23 characters.
        max_chars = max(23, int(metric_col_widths[idx] / 0.115))
        short = label_with_unit if len(label_with_unit) <= max_chars else label_with_unit[:max_chars - 1] + '…'
        create_text_label(short, (cx, y_top - row_h * 0.66, z), 0.21, f'TableText_Header_{_safe_name(key)}', align_x='CENTER', color=header)

    for row_idx, (csv_name, sample_idx, values, csv_idx, row_metrics) in enumerate(data_rows):
        y = y_top - row_h * (row_idx + 1.66)
        color = csv_color_by_index(csv_idx, getattr(scn, 'anali_color_palette', None))
        shown_name = csv_name if len(csv_name) <= 31 else csv_name[:29] + '…'
        create_text_label(shown_name, (x0 + 0.14, y, z), 0.22, f'TableText_Row_{row_idx}', align_x='LEFT', color=color)
        if raw_mode:
            create_text_label(str(sample_idx), (x0 + first_col_w + index_col_w * 0.5, y, z), 0.22, f'TableText_Index_{row_idx}', align_x='CENTER', color=subtle)
        for col_idx, value in enumerate(values):
            cx = metric_centers[col_idx]
            create_text_label(_format_metric_cell(metric_slice[col_idx], value, statistic, row_metrics, scn), (cx, y, z), 0.24, f'TableText_Cell_{row_idx}_{col_idx}', align_x='CENTER', color=white)

    footer_y = y_top - row_h * (len(data_rows) + 1) - 0.42
    row_description = tr(scn, UI_TEXT['RAW_OBSERVATIONS']) if raw_mode else tr(scn, UI_TEXT['CSV_FILES'])
    create_text_label(
        f"{tr(scn, UI_TEXT['SHOWING'])} {len(data_rows)} {tr(scn, UI_TEXT['OF'])} {len(all_rows)} {row_description} {tr(scn, UI_TEXT['AND'])} {len(metric_slice)} {tr(scn, UI_TEXT['OF'])} {len(metric_keys)} {tr(scn, UI_TEXT['METRICS'])}",
        (0.0, footer_y, z), 0.20, 'TableSubtitle_Footer', align_x='CENTER', color=subtle,
    )

    frame_graph_camera(scn, scn)
    report({'INFO'}, f"{tr(scn, UI_TEXT['DATA_TABLE_GENERATED'])}: {len(data_rows)} {tr(scn, UI_TEXT['ROWS'])} × {len(metric_slice)} {tr(scn, UI_TEXT['METRICS'])}")
    return {'FINISHED'}


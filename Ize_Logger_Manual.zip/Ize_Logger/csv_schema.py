"""CSV schema and backwards-compatibility helpers for Ize Logger."""
from __future__ import annotations

import csv
import io

SCHEMA_VERSION = "4"

CSV_HEADER = [
    "SchemaVersion", "LoggerVersion", "SessionID", "UserID",
    "TimeStamp",
    "UserX", "UserY", "UserZ",
    "ObjX", "ObjY", "ObjZ", "ObjRadius", "ObjectTransform",
    "VertexDelta", "NgonDelta", "TriDelta", "NormalDelta", "NonManifoldDelta",
    "ObjModeState", "EditModeState", "ModeChanged",
    "UVDeploy",
    "ObjectDelta", "ObjectCreated", "ObjectDeleted",
    "ModifierDelta", "ModifierCreated", "ModifierDeleted",
    "Duplicate", "Instance", "Undo", "Occlusion", "Orthographic",
]


def detect_csv_schema(header):
    normalized = [str(h).strip().lstrip("\ufeff") for h in header]
    if "SchemaVersion" in normalized:
        return 3
    if "USER_ID" in normalized:
        return 1
    return 0


def upgrade_csv_content_to_current(content: str) -> str:
    """Normalize historical logger CSV data to the compact current schema."""
    if not content.strip():
        return ",".join(CSV_HEADER) + "\n"

    reader = csv.DictReader(io.StringIO(content))
    if not reader.fieldnames:
        return ",".join(CSV_HEADER) + "\n"

    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=CSV_HEADER, extrasaction="ignore", lineterminator="\n")
    writer.writeheader()

    def _f(row, key):
        try:
            return float(row.get(key, 0) or 0)
        except Exception:
            return 0.0

    for row in reader:
        new_row = {key: row.get(key, "") for key in CSV_HEADER}
        if not new_row.get("UserID"):
            new_row["UserID"] = row.get("USER_ID", "")
        new_row["SchemaVersion"] = SCHEMA_VERSION

        od = _f(row, "ObjectDelta")
        md = _f(row, "ModifierDelta")
        if new_row.get("ObjectCreated", "") in (None, ""):
            new_row["ObjectCreated"] = max(od, 0.0)
        if new_row.get("ObjectDeleted", "") in (None, ""):
            new_row["ObjectDeleted"] = max(-od, 0.0)
        if new_row.get("ModifierCreated", "") in (None, ""):
            new_row["ModifierCreated"] = max(md, 0.0)
        if new_row.get("ModifierDeleted", "") in (None, ""):
            new_row["ModifierDeleted"] = max(-md, 0.0)

        new_row["ObjectTransform"] = int(bool(
            _f(row, "ObjectTransform")
            or _f(row, "ObjDeltaX") or _f(row, "ObjDeltaY")
            or _f(row, "ObjDeltaZ") or _f(row, "ObjDeltaRadius")
        ))
        new_row["UVDeploy"] = int(bool(_f(row, "UVDeploy") or _f(row, "UVAction") or _f(row, "UV")))
        new_row["Duplicate"] = int(bool(_f(row, "Duplicate") or _f(row, "CtrlV") or _f(row, "ShiftD")))
        new_row["Instance"] = int(bool(_f(row, "Instance") or _f(row, "AltD")))
        new_row["Undo"] = max(0, int(_f(row, "Undo")))
        new_row["NonManifoldDelta"] = row.get("NonManifoldDelta", 0)
        new_row["Occlusion"] = int(bool(_f(row, "Occlusion")))
        new_row["Orthographic"] = int(bool(_f(row, "Orthographic") or _f(row, "OrthoState")))
        writer.writerow(new_row)

    return out.getvalue()


def strip_user_id_from_csv(content: str) -> str:
    """Return a copy of the CSV without the user identifier."""
    if not content.strip():
        return content
    reader = csv.DictReader(io.StringIO(content))
    if not reader.fieldnames:
        return content
    fieldnames = [f for f in reader.fieldnames if f not in {"UserID", "USER_ID"}]
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=fieldnames, extrasaction="ignore", lineterminator="\n")
    writer.writeheader()
    for row in reader:
        writer.writerow(row)
    return out.getvalue()

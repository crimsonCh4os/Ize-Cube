# Tools for monitoring and analyzing 3D modeling workflows in Blender
# Copyright (C) 2026 María Molina Goyena
# SPDX-License-Identifier: GPL-3.0-or-later

bl_info = {
    "name": "Ize Logger Manual",
    "author": "Maria",
    "version": (1, 3, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Ize Logger",
    "category": "3D View",
}

# Manual and Consent intentionally share the same add-on package name. Blender
# can keep submodules from the previously installed variant in sys.modules when
# one ZIP is installed over the other in the same session. Reload the variant
# modules explicitly so this package can never inherit the other variant's
# config/texts/logger_core state.
import importlib
import sys

for _submodule in ("config", "texts", "csv_schema"):
    _fullname = f"{__name__}.{_submodule}"
    if _fullname in sys.modules:
        importlib.reload(sys.modules[_fullname])

from . import config as _config
_config.ENABLE_CONSENT_FLOW = False

_logger_name = f"{__name__}.logger_core"
if _logger_name in sys.modules:
    logger_core = importlib.reload(sys.modules[_logger_name])
else:
    from . import logger_core


def register():
    # Enforce the package variant again at registration time in case another
    # Ize Logger variant was imported earlier in the same Blender session.
    _config.ENABLE_CONSENT_FLOW = False
    logger_core.ENABLE_CONSENT_FLOW = False
    logger_core.register()


def unregister():
    logger_core.unregister()

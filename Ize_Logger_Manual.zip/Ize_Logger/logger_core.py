# Tools for monitoring and analyzing 3D modeling workflows in Blender
# Copyright (C) 2026 María Molina Goyena
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# at your option any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.

from . import bl_info
from .config import ENABLE_CONSENT_FLOW

import bpy
import bmesh
import time
import os
import tempfile
import hashlib
import uuid
import csv
import io
import math
import json
import mathutils
from bpy.app.handlers import persistent



# LOCALIZATION

from .texts import TRANSLATIONS

def current_language(context=None):
    scene = getattr(context, "scene", None) if context else getattr(bpy.context, "scene", None)
    return getattr(scene, "data_logger_language", "en") if scene else "en"

def tr(key, context=None):
    language = current_language(context)
    return TRANSLATIONS.get(language, TRANSLATIONS["en"]).get(key, key)


# PRIVACY / IDENTIFIERS

# A random UUID is generated and stored inside the .blend file as a Text Block.
USER_ID_TEXTBLOCK = "data_logger_user_id"
CONSENT_TEXTBLOCK = "consent_flag"

DATA_TEXTBLOCK = "data_log_internal.csv"
WARNINGS_TEXTBLOCK = "data_logger_warnings.txt"
LEGACY_MESH_METRICS_JSON_TEXTBLOCK = "data_logger_mesh_metrics.json"
MESH_METRICS_CSV_TEXTBLOCK = "data_logger_mesh_metrics.csv"

from .csv_schema import CSV_HEADER, SCHEMA_VERSION, upgrade_csv_content_to_current, strip_user_id_from_csv
LOGGER_VERSION = ".".join(str(v) for v in bl_info.get("version", (1, 1, 0)))
SESSION_ID = str(uuid.uuid4())

_WARNINGS = []
MAX_WARNINGS = 50

# UV tracking records completed unwrap/deploy operators only. Ordinary UV editing is ignored.
ENABLE_UV_CHANGE_TRACKING = True


def log_warning(context, exc=None):
    """Log recoverable warnings without interrupting the Blender session."""
    message = f"[Data Logger] {context}"
    if exc is not None:
        message += f": {type(exc).__name__}: {exc}"

    print(message)
    _WARNINGS.append(message)
    del _WARNINGS[:-MAX_WARNINGS]

    try:
        if WARNINGS_TEXTBLOCK in bpy.data.texts:
            txt = bpy.data.texts[WARNINGS_TEXTBLOCK]
        else:
            txt = bpy.data.texts.new(WARNINGS_TEXTBLOCK)
        txt.use_fake_user = True
        txt.use_module = False
        txt.filepath = ""
        txt.clear()
        txt.write("\n".join(_WARNINGS))
    except Exception as inner_exc:
        print(f"[Data Logger] Could not update {WARNINGS_TEXTBLOCK}: {inner_exc}")


def get_or_create_textblock(name):
    if name in bpy.data.texts:
        txt = bpy.data.texts[name]
    else:
        txt = bpy.data.texts.new(name)
    txt.use_fake_user = True
    txt.use_module = False
    txt.filepath = ""
    return txt


def get_or_create_user_id():
    txt = get_or_create_textblock(USER_ID_TEXTBLOCK)
    value = txt.as_string().strip()
    if value:
        return value

    new_id = str(uuid.uuid4())
    txt.clear()
    txt.write(new_id)
    txt.use_fake_user = True
    return new_id


def reset_user_id():
    txt = get_or_create_textblock(USER_ID_TEXTBLOCK)
    new_id = str(uuid.uuid4())
    txt.clear()
    txt.write(new_id)
    txt.use_fake_user = True
    return new_id


def clear_consent():
    if CONSENT_TEXTBLOCK in bpy.data.texts:
        bpy.data.texts.remove(bpy.data.texts[CONSENT_TEXTBLOCK])


def clear_logged_data():
    if DATA_TEXTBLOCK in bpy.data.texts:
        bpy.data.texts.remove(bpy.data.texts[DATA_TEXTBLOCK])
    if os.path.exists(TEMP_CSV_PATH):
        try:
            os.remove(TEMP_CSV_PATH)
        except Exception as exc:
            log_warning("Could not delete the temporary CSV", exc)



# GLOBAL STATE

timer_running = False
start_time = None
_baseline_ready = False
LOGGER_INITIAL_DELAY = 1.0
LOGGER_POLL_INTERVAL = 0.25
UNDO_BURST_DEBOUNCE = 0.45
LOGGER_IDLE_FULL_CHECK_INTERVAL = 8.0
# Expensive topology/UV scans are throttled independently from UI/navigation sampling.
LOGGER_FULL_SCAN_MIN_INTERVAL = 0.60
# Legacy settle interval retained for compatibility with helper code.
# The runtime logger no longer traverses live Edit Mode BMesh at all.
EDIT_MESH_SETTLE_DELAY = 0.75
# Edit Mode is sampled conservatively: lightweight activity rows are capped and
# geometry is synchronized only after Blender has been quiet for a short period.
EDIT_MODE_ROW_MIN_INTERVAL = 0.50
EDIT_MODE_SAFE_SCAN_INTERVAL = 1.00

# Fixed recording indicator shown in Blender's top bar.

_last_timestamp = -1.0
_force_log_pending = False
_last_lightweight_signature = None
_last_idle_full_check = 0.0
_last_full_scan_time = 0.0
_last_mesh_update_time = 0.0
_last_operator_index = 0
_last_edit_row_time = 0.0
_last_edit_safe_scan_time = 0.0
_undo_last_event_time = 0.0
_undo_wrapper_inflight = False

prev_vert_count = 0
prev_ngon_count = 0
prev_tri_count = 0
prev_inverted_normals = 0
prev_nonmanifold_count = 0
prev_object_count = 0
prev_object_ids = frozenset()
prev_modifier_ids = frozenset()
prev_total_mods = 0
prev_mode = None
prev_geometry_hash = ""
prev_snapshot_signature = None
prev_active_object_name = None
prev_object_state = (0.0, 0.0, 0.0, 0.0)

operator_flags = {
    "ctrl_v": 0,
    "shift_d": 0,
    "alt_d": 0,
    "merge": 0,
    "undo": 0,
}

_uv_action_pending = 0
addon_keymaps = []

# Internal developer switch. It is intentionally not exposed in Blender UI.
# True: show the Debug panel. False: keep it completely hidden.
SHOW_DEBUG_PANEL = False

DEBUG_ENABLED = True
DEBUG_LAST_OPERATOR = ""
DEBUG_LAST_LOG_REASON = ""
DEBUG_LAST_REBASE_REASON = ""
DEBUG_UV_PENDING = 0
DEBUG_LAST_FLAGS = "CtrlV=0 ShiftD=0 AltD=0 Merge=0 Undo=0"


# CSV

TEMP_CSV_PATH = os.path.join(tempfile.gettempdir(), "blender_data_log.csv")
TEMP_MESH_METRICS_CSV_PATH = os.path.join(tempfile.gettempdir(), "blender_mesh_metrics.csv")










def ensure_file_ends_with_newline(path):
    if not os.path.exists(path):
        return

    with open(path, "rb+") as f:
        f.seek(0, os.SEEK_END)
        size = f.tell()
        if size == 0:
            return
        f.seek(-1, os.SEEK_END)
        last = f.read(1)
        if last != b"\n":
            f.seek(0, os.SEEK_END)
            f.write(b"\n")


def init_csv():
    with open(TEMP_CSV_PATH, "w", encoding="utf-8", newline="\n") as f:
        f.write(",".join(CSV_HEADER) + "\n")


def append_csv(row):
    ensure_file_ends_with_newline(TEMP_CSV_PATH)
    with open(TEMP_CSV_PATH, "a", encoding="utf-8", newline="\n") as f:
        f.write(row + "\n")


def remove_duplicate_rows():
    if not os.path.exists(TEMP_CSV_PATH):
        return

    with open(TEMP_CSV_PATH, "r", encoding="utf-8") as f:
        lines = f.readlines()

    if not lines:
        return

    header = lines[0]
    unique_rows = list(dict.fromkeys(lines[1:]))

    with open(TEMP_CSV_PATH, "w", encoding="utf-8", newline="\n") as f:
        f.write(header)
        f.writelines(unique_rows)

    ensure_file_ends_with_newline(TEMP_CSV_PATH)


def import_csv_to_blend():
    if not os.path.exists(TEMP_CSV_PATH):
        return

    ensure_file_ends_with_newline(TEMP_CSV_PATH)

    text_name = DATA_TEXTBLOCK
    if text_name in bpy.data.texts:
        txt = bpy.data.texts[text_name]
        txt.clear()
    else:
        txt = bpy.data.texts.new(text_name)

    with open(TEMP_CSV_PATH, "r", encoding="utf-8") as f:
        content = f.read()

    if content and not content.endswith("\n"):
        content += "\n"

    txt.write(content)
    txt.use_fake_user = True
    txt.use_module = False
    txt.filepath = ""


def restore_csv_from_blend():
    if DATA_TEXTBLOCK not in bpy.data.texts:
        return False

    content = bpy.data.texts[DATA_TEXTBLOCK].as_string()
    if not content.strip():
        return False

    content = upgrade_csv_content_to_current(content)

    with open(TEMP_CSV_PATH, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)

    ensure_file_ends_with_newline(TEMP_CSV_PATH)
    return True

# UTILITIES

def trunc_2(value):
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return math.trunc(value * 100.0) / 100.0
    return value


def trunc_all(values):
    return [trunc_2(v) for v in values]


def force_log_soon():
    global _force_log_pending
    _force_log_pending = True


def mesh_edit_mode_active():
    """Return True when a mesh is currently being edited.

    This helper intentionally performs no mesh traversal. It is safe to call
    from timers and depsgraph handlers while Blender is mutating Edit Mode data.
    """
    try:
        edit_obj = getattr(bpy.context, "edit_object", None)
        if edit_obj is not None and getattr(edit_obj, "type", None) == "MESH":
            return True
        obj = getattr(bpy.context, "object", None)
        return bool(
            obj is not None
            and getattr(obj, "type", None) == "MESH"
            and safe_mode_of_object(obj) == "EDIT"
        )
    except Exception:
        return False


def edit_mesh_is_settling(now=None):
    """True while the active Edit-Mode mesh is still receiving updates.

    Blender edit operators may update the live BMesh over several depsgraph
    notifications.  Expensive BMesh reads are deferred until a short quiet
    period has elapsed, preventing timer/depsgraph races during bulk edits.
    """
    obj = getattr(bpy.context, "edit_object", None)
    if obj is None or getattr(obj, "type", None) != "MESH":
        return False
    if safe_mode_of_object(obj) != "EDIT":
        return False
    if now is None:
        now = time.time()
    return (now - _last_mesh_update_time) < EDIT_MESH_SETTLE_DELAY


def tag_blender_bars_for_redraw():
    """Redraw Blender bars so the recording indicator updates immediately."""
    try:
        wm = bpy.context.window_manager
        for window in wm.windows:
            screen = window.screen
            if screen is None:
                continue
            for area in screen.areas:
                if area.type in {'TOPBAR', 'STATUSBAR'}:
                    area.tag_redraw()
    except Exception as exc:
        log_warning("Could not redraw the recording indicator", exc)


def draw_recording_indicator(self, context):
    """Draw one red REC badge only in the right side of Blender's top bar."""
    if not timer_running:
        return

    # TOPBAR_HT_upper_bar is drawn once for each top-bar region. Restrict the
    # callback to the right-aligned region so the REC badge is not duplicated
    # on the left side.
    region = getattr(context, "region", None)
    if region is None or getattr(region, "alignment", "") != "RIGHT":
        return

    row = self.layout.row(align=True)
    row.alert = True
    row.label(text="REC", icon='REC')


def safe_mode_of_object(obj):
    try:
        return obj.mode
    except Exception:
        return "OBJECT"


def get_camera_pos():
    try:
        screen = bpy.context.screen
        if not screen:
            return (0.0, 0.0, 0.0)

        for area in screen.areas:
            if area.type == "VIEW_3D":
                r3d = area.spaces.active.region_3d
                pos = r3d.view_matrix.inverted().translation
                return (float(pos.x), float(pos.y), float(pos.z))
    except Exception as exc:
        log_warning("Could not get the camera position", exc)

    return (0.0, 0.0, 0.0)


def get_active_object_name():
    obj = bpy.context.object
    return obj.name if obj else ""


def get_active_object_data():
    obj = bpy.context.object
    if not obj:
        return (0.0, 0.0, 0.0, 0.0)

    try:
        bbox = [obj.matrix_world @ mathutils.Vector(corner) for corner in obj.bound_box]
        center = sum(bbox, mathutils.Vector()) / 8
        radius = max((v - center).length for v in bbox)
        return (float(center.x), float(center.y), float(center.z), float(radius))
    except Exception:
        return (0.0, 0.0, 0.0, 0.0)


def get_scene_radius():
    objs = [o for o in bpy.context.scene.objects if o.type == "MESH"]
    if not objs:
        return 0.0

    centers = []
    radii = []

    for o in objs:
        try:
            bbox = [o.matrix_world @ mathutils.Vector(corner) for corner in o.bound_box]
            center = sum(bbox, mathutils.Vector()) / 8
            radius = max((v - center).length for v in bbox)
            centers.append(center)
            radii.append(radius)
        except Exception as exc:
            log_warning(f"Could not calculate scene radius for {getattr(o, 'name', '?')}", exc)
            continue

    if not centers:
        return 0.0

    global_center = sum(centers, mathutils.Vector()) / len(centers)
    return float(max((c - global_center).length + r for c, r in zip(centers, radii)))


def _face_edge_direction(face, edge):
    """Return the directed vertex pair used by a face along an edge."""
    for loop in face.loops:
        if loop.edge == edge:
            return (loop.vert, loop.link_loop_next.vert)
    return None


def _component_signed_volume(faces, flip_state):
    """Signed volume of a component after applying virtual face flips."""
    volume6 = 0.0
    for face in faces:
        verts = [v.co for v in face.verts]
        if len(verts) < 3:
            continue

        v0 = verts[0]
        sign = -1.0 if flip_state.get(face, 0) else 1.0
        for i in range(1, len(verts) - 1):
            v1 = verts[i]
            v2 = verts[i + 1]
            volume6 += sign * v0.dot(v1.cross(v2))
    return volume6 / 6.0


def _count_faces_needing_normal_recalc(source_bm):
    """Count genuinely inconsistent face orientations.

    For open components, only local inconsistencies between neighbouring faces
    are errors. A globally reversed open surface is accepted because it has no
    unique outside.

    For closed manifold components, local consistency is checked first and
    signed volume is then used to decide whether the whole component points
    inward.
    """
    if source_bm is None or not source_bm.faces:
        return 0

    source_bm.faces.ensure_lookup_table()
    source_bm.edges.ensure_lookup_table()

    visited = set()
    total_errors = 0

    for seed in source_bm.faces:
        if seed in visited:
            continue

        parity = {seed: 0}
        stack = [seed]
        component = []
        closed_manifold = True
        contradictory = False

        while stack:
            face = stack.pop()
            if face in visited:
                continue

            visited.add(face)
            component.append(face)

            for edge in face.edges:
                linked = list(edge.link_faces)

                if len(linked) != 2:
                    closed_manifold = False
                    continue

                other = linked[0] if linked[1] == face else linked[1]

                d1 = _face_edge_direction(face, edge)
                d2 = _face_edge_direction(other, edge)
                if d1 is None or d2 is None:
                    continue

                same_direction = (d1[0] == d2[0] and d1[1] == d2[1])
                required_other = parity[face] ^ int(same_direction)

                if other in parity:
                    if parity[other] != required_other:
                        contradictory = True
                    continue

                parity[other] = required_other
                stack.append(other)

        if not component:
            continue

        ones = sum(parity.get(face, 0) for face in component)
        zeros = len(component) - ones

        if contradictory:
            total_errors += min(ones, zeros)
            continue

        if closed_manifold:
            signed_volume = _component_signed_volume(component, parity)
            total_errors += zeros if signed_volume < 0.0 else ones
        else:
            total_errors += min(ones, zeros)

    return int(total_errors)


def count_inverted_normals_object_mode(mesh_obj):
    """Count incorrectly oriented faces without depending on object origin."""
    if mesh_obj is None or mesh_obj.type != "MESH":
        return 0

    bm = bmesh.new()
    try:
        bm.from_mesh(mesh_obj.data)
        return _count_faces_needing_normal_recalc(bm)
    except Exception as exc:
        log_warning("Could not count normal errors in Object Mode", exc)
        return 0
    finally:
        bm.free()


def count_inverted_normals_edit_mode(obj):
    """Count incorrectly oriented faces from the live Edit Mode BMesh."""
    if obj is None or obj.type != "MESH":
        return 0

    try:
        live_bm = bmesh.from_edit_mesh(obj.data)
        return _count_faces_needing_normal_recalc(live_bm)
    except Exception as exc:
        log_warning("Could not count normal errors in Edit Mode", exc)
        return 0


def get_mesh_stats(obj):
    if obj.type != "MESH":
        return (0, 0, 0, 0)

    mode = safe_mode_of_object(obj)

    if mode == "EDIT":
        try:
            bm = bmesh.from_edit_mesh(obj.data)

            verts = len(bm.verts)
            ngons = 0
            tris = 0

            for f in bm.faces:
                vcount = len(f.verts)
                if vcount > 4:
                    ngons += 1
                elif vcount == 3:
                    tris += 1

            inverted = count_inverted_normals_edit_mode(obj)
            return (verts, ngons, tris, inverted)
        except Exception as exc:
            log_warning("Could not get mesh statistics in Edit Mode", exc)

    try:
        verts = len(obj.data.vertices)
        ngons = sum(1 for p in obj.data.polygons if len(p.vertices) > 4)
        tris = sum(1 for p in obj.data.polygons if len(p.vertices) == 3)
        inverted = count_inverted_normals_object_mode(obj)
        return (verts, ngons, tris, inverted)
    except Exception as exc:
        log_warning("Could not get mesh statistics in Object Mode", exc)
        return (0, 0, 0, 0)


def get_global_geometry_hash():
    """Hash actual 3D mesh geometry, excluding UV coordinates.

    This lets the logger distinguish a UV vertex move from a real mesh vertex
    move even when Blender reports both operations as transform.translate.
    """
    chunks = []

    for obj in sorted(
        (o for o in bpy.context.scene.objects if o.type == "MESH"),
        key=lambda o: o.name,
    ):
        try:
            mode = safe_mode_of_object(obj)

            if mode == "EDIT":
                bm = bmesh.from_edit_mesh(obj.data)
                bm.verts.ensure_lookup_table()
                bm.edges.ensure_lookup_table()
                bm.faces.ensure_lookup_table()

                vertices = tuple(
                    (
                        vert.index,
                        round(float(vert.co.x), 5),
                        round(float(vert.co.y), 5),
                        round(float(vert.co.z), 5),
                    )
                    for vert in bm.verts
                )
                edges = tuple(sorted(
                    tuple(sorted(v.index for v in edge.verts))
                    for edge in bm.edges
                ))
                faces = tuple(sorted(
                    tuple(v.index for v in face.verts)
                    for face in bm.faces
                ))
            else:
                mesh = obj.data
                vertices = tuple(
                    (
                        vert.index,
                        round(float(vert.co.x), 5),
                        round(float(vert.co.y), 5),
                        round(float(vert.co.z), 5),
                    )
                    for vert in mesh.vertices
                )
                edges = tuple(sorted(
                    tuple(sorted(edge.vertices))
                    for edge in mesh.edges
                ))
                faces = tuple(sorted(
                    tuple(poly.vertices)
                    for poly in mesh.polygons
                ))

            chunks.append((
                obj.name,
                vertices,
                edges,
                faces,
            ))

        except Exception as exc:
            log_warning(
                f"Could not calculate geometry hash for "
                f"{getattr(obj, 'name', '?')}",
                exc,
            )
            chunks.append(
                (getattr(obj, "name", "?"), "GEOMETRY_HASH_ERROR")
            )

    return hashlib.sha256(
        repr(chunks).encode("utf-8")
    ).hexdigest()








def _count_nonmanifold_vertices_bmesh(bm):
    """Count vertices that belong to non-manifold geometry.

    Boundary/wire vertices and isolated vertices are included. Using vertices
    keeps the count and percentage on the same denominator and distinguishes
    floating vertices/edges correctly.
    """
    count = 0
    for vert in bm.verts:
        try:
            is_manifold = bool(vert.is_manifold)
        except Exception:
            linked_edges = tuple(getattr(vert, "link_edges", ()))
            is_manifold = bool(linked_edges) and all(edge.is_manifold for edge in linked_edges)
        if not is_manifold:
            count += 1
    return count


def count_nonmanifold_vertices_safe(obj):
    """Count non-manifold vertices without modifying the mesh."""
    if obj is None or obj.type != "MESH":
        return 0
    try:
        if obj == getattr(bpy.context, "edit_object", None) and safe_mode_of_object(obj) == "EDIT":
            bm = bmesh.from_edit_mesh(obj.data)
            return _count_nonmanifold_vertices_bmesh(bm)
        bm = bmesh.new()
        try:
            bm.from_mesh(obj.data)
            return _count_nonmanifold_vertices_bmesh(bm)
        finally:
            bm.free()
    except Exception as exc:
        log_warning("Could not count non-manifold vertices", exc)
        return 0


def get_realtime_mesh_stats_safe(obj):
    """Read current mesh statistics, including live Edit Mode geometry."""
    if obj is None or obj.type != "MESH":
        return (0, 0, 0, 0)

    try:
        if obj == getattr(bpy.context, "edit_object", None) and safe_mode_of_object(obj) == "EDIT":
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            verts = len(bm.verts)
            ngons = sum(1 for f in bm.faces if len(f.verts) > 4)
            tris = sum(1 for f in bm.faces if len(f.verts) == 3)
            inverted = count_inverted_normals_edit_mode(obj)
            return (verts, ngons, tris, inverted)

        mesh = obj.data
        verts = len(mesh.vertices)
        ngons = sum(1 for p in mesh.polygons if len(p.vertices) > 4)
        tris = sum(1 for p in mesh.polygons if len(p.vertices) == 3)
        inverted = count_inverted_normals_object_mode(obj)
        return (verts, ngons, tris, inverted)

    except Exception as exc:
        log_warning("Could not read real-time mesh statistics", exc)
        return (0, 0, 0, 0)


def get_edit_mesh_snapshot_from_synced_data():
    """Return Edit Mode geometry using Mesh datablocks, never the live BMesh.

    This function is called only after a depsgraph quiet period.  Blender's
    supported ``update_from_editmode`` API copies the current edit data into the
    object Mesh; the logger then reads that ordinary Mesh datablock.  Expensive
    normal/non-manifold analysis is intentionally deferred until Object Mode.
    """
    scene = bpy.context.scene
    edit_obj = getattr(bpy.context, "edit_object", None)
    if edit_obj is None or getattr(edit_obj, "type", None) != "MESH":
        return None
    if safe_mode_of_object(edit_obj) != "EDIT":
        return None

    try:
        # Do not call bmesh.from_edit_mesh here.  This is the only supported
        # synchronization point used by the real-time Edit Mode logger.
        edit_obj.update_from_editmode()
    except Exception as exc:
        log_warning("Could not synchronize Edit Mode mesh safely", exc)
        return None

    total_verts = 0
    ngons = 0
    tris = 0
    hasher = hashlib.sha256()

    try:
        for obj in sorted((o for o in scene.objects if o.type == "MESH"), key=lambda o: o.name):
            mesh = obj.data
            total_verts += len(mesh.vertices)
            ngons += sum(1 for poly in mesh.polygons if len(poly.vertices) > 4)
            tris += sum(1 for poly in mesh.polygons if len(poly.vertices) == 3)

            # Stream coordinates directly into the hash: no giant tuples/lists.
            hasher.update(
                f"O|{obj.name}|{len(mesh.vertices)}|{len(mesh.edges)}|{len(mesh.polygons)};".encode("utf-8")
            )
            for vert in mesh.vertices:
                co = vert.co
                hasher.update(
                    f"V{vert.index}:{float(co.x):.5f},{float(co.y):.5f},{float(co.z):.5f};".encode("utf-8")
                )
            for edge in mesh.edges:
                hasher.update(f"E{int(edge.vertices[0])},{int(edge.vertices[1])};".encode("ascii"))
            for poly in mesh.polygons:
                hasher.update(b"F")
                for vertex_index in poly.vertices:
                    hasher.update(f"{int(vertex_index)},".encode("ascii"))
                hasher.update(b";")
    except Exception as exc:
        log_warning("Could not read synchronized Edit Mode mesh", exc)
        return None

    return {
        "verts": total_verts,
        "ngons": ngons,
        "tris": tris,
        # These require a topology walk/BMesh and are deliberately reconciled
        # once Object Mode is safe again.
        "inverted": prev_inverted_normals,
        "nonmanifold": prev_nonmanifold_count,
        "geometry_hash": hasher.hexdigest(),
    }


def get_realtime_geometry_hash_safe():
    """Stable geometry hash for the live logger with low temporary-memory use.

    The previous implementation built large nested tuples containing every
    vertex/edge/face before hashing them. This version streams values directly
    into hashlib, greatly reducing allocations on medium and large meshes.
    """
    hasher = hashlib.sha256()
    for obj in sorted(
        (o for o in bpy.context.scene.objects if o.type == "MESH"),
        key=lambda o: o.name,
    ):
        try:
            mesh = obj.data
            hasher.update(f"O|{obj.name}|{len(mesh.vertices)}|{len(mesh.edges)}|{len(mesh.polygons)};".encode("utf-8"))

            for v in mesh.vertices:
                co = v.co
                hasher.update(
                    f"V{v.index}:{float(co.x):.5f},{float(co.y):.5f},{float(co.z):.5f};".encode("utf-8")
                )
            for e in mesh.edges:
                hasher.update(f"E{int(e.vertices[0])},{int(e.vertices[1])};".encode("utf-8"))
            for p in mesh.polygons:
                hasher.update(b"F")
                for idx in p.vertices:
                    hasher.update(f"{int(idx)},".encode("ascii"))
                hasher.update(b";")
        except Exception as exc:
            log_warning(f"Could not calculate safe geometry hash for {getattr(obj, 'name', '?')}", exc)
            hasher.update(f"{getattr(obj, 'name', '?')}|ERROR;".encode("utf-8"))
    return hasher.hexdigest()






def get_occlusion_state():
    try:
        for area in bpy.context.screen.areas:
            if area.type == "VIEW_3D":
                space = area.spaces.active

                # Wireframe
                is_wireframe = (space.shading.type == 'WIREFRAME')

                # X-Ray
                is_xray = bool(space.shading.show_xray)

                return int(is_wireframe or is_xray)
    except Exception as exc:
        log_warning("Could not read occlusion state", exc)

    return 0


def get_orthographic_state():
    """Return 1 while a 3D viewport is in orthographic projection."""
    try:
        screen = getattr(bpy.context, "screen", None)
        if screen is None:
            return 0
        for area in screen.areas:
            if area.type != "VIEW_3D":
                continue
            space = area.spaces.active
            region_3d = getattr(space, "region_3d", None)
            if region_3d is not None:
                return int(getattr(region_3d, "view_perspective", "PERSP") == "ORTHO")
    except Exception as exc:
        log_warning("Could not read orthographic view state", exc)
    return 0


# MESH METRICS ON SAVE

def _almost_equal_2d(v1, v2, tol=1e-4):
    return abs(v1.x - v2.x) <= tol and abs(v1.y - v2.y) <= tol


def _uv_polygon_area(uvs):
    if len(uvs) < 3:
        return 0.0
    area = 0.0
    for i in range(1, len(uvs) - 1):
        area += abs((uvs[i] - uvs[0]).cross(uvs[i + 1] - uvs[0])) * 0.5
    return area


def _count_uv_islands(bm, uv_layer):
    if uv_layer is None:
        return 0
    visited = set()
    islands = 0
    for face in bm.faces:
        if face.index in visited:
            continue
        stack = [face]
        while stack:
            current = stack.pop()
            if current.index in visited:
                continue
            visited.add(current.index)
            for edge in current.edges:
                for linked in edge.link_faces:
                    if linked.index in visited:
                        continue
                    connected = any(
                        _almost_equal_2d(loop_a[uv_layer].uv, loop_b[uv_layer].uv)
                        for loop_a in current.loops
                        for loop_b in linked.loops
                    )
                    if connected:
                        stack.append(linked)
        islands += 1
    return islands


def _normal_percentage(obj, bm):
    if not bm.faces:
        return 0.0
    check_bm = bm.copy()
    try:
        check_bm.normal_update()
        check_bm.faces.ensure_lookup_table()
        original = [face.normal.copy() for face in check_bm.faces]
        bmesh.ops.recalc_face_normals(check_bm, faces=list(check_bm.faces))
        check_bm.normal_update()
        flipped = sum(
            1 for old, face in zip(original, check_bm.faces)
            if old.dot(face.normal) < 0.0
        )
        return round(100.0 * flipped / len(check_bm.faces), 2)
    finally:
        check_bm.free()


def _mean_face_angle(bm):
    angles = []
    bm.normal_update()
    for edge in bm.edges:
        if edge.is_valid and len(edge.link_faces) == 2:
            try:
                angle = abs(math.degrees(edge.calc_face_angle()))
            except ValueError:
                continue
            if angle > 90.0:
                angle = 180.0 - angle
            angles.append(angle)
    return round(sum(angles) / len(angles), 2) if angles else 0.0


def _flush_edit_mesh_uv_data(obj):
    """Synchronize current Edit Mode geometry and UV loop data with the mesh datablock.

    UV transforms performed in the UV Editor live first in the edit BMesh. During
    save_pre, evaluated_get().to_mesh() can otherwise read the previous UV
    coordinates, making UV area and texel density appear unchanged.
    """
    if obj is None or obj.type != "MESH" or safe_mode_of_object(obj) != "EDIT":
        return

    try:
        bmesh.update_edit_mesh(
            obj.data,
            loop_triangles=False,
            destructive=False,
        )
    except Exception as exc:
        log_warning(
            f"Could not synchronize Edit Mode UV data for {getattr(obj, 'name', '?')}",
            exc,
        )

    try:
        obj.update_from_editmode()
        obj.data.update()
    except Exception as exc:
        log_warning(
            f"Could not update Edit Mode mesh data for {getattr(obj, 'name', '?')}",
            exc,
        )


def _mesh_bmesh_copy(obj):
    bm = bmesh.new()
    if safe_mode_of_object(obj) == "EDIT":
        _flush_edit_mesh_uv_data(obj)
        edit_bm = bmesh.from_edit_mesh(obj.data)
        bm.free()
        return edit_bm.copy()
    bm.from_mesh(obj.data)
    return bm


def calculate_mesh_metrics(obj):
    """Calculate Analysis3D mesh metrics, excluding similarity."""
    if obj is None or obj.type != "MESH":
        return {}

    bm = _mesh_bmesh_copy(obj)
    try:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.normal_update()

        total_faces = len(bm.faces)
        total_verts = len(bm.verts)
        non_quads = round(
            100.0 * sum(1 for face in bm.faces if len(face.verts) != 4) / total_faces,
            2,
        ) if total_faces else 0.0

        merged = bm.copy()
        try:
            bmesh.ops.remove_doubles(merged, verts=list(merged.verts), dist=0.0001)
            duplicate_count = max(total_verts - len(merged.verts), 0)
        finally:
            merged.free()
        duplicate_percentage = round(
            100.0 * duplicate_count / total_verts, 2
        ) if total_verts else 0.0

        visited = set()
        parts = 0
        for face in bm.faces:
            if face.index in visited:
                continue
            stack = [face]
            while stack:
                current = stack.pop()
                if current.index in visited:
                    continue
                visited.add(current.index)
                for edge in current.edges:
                    stack.extend(
                        linked for linked in edge.link_faces
                        if linked.index not in visited
                    )
            parts += 1

        uv_layer = bm.loops.layers.uv.active
        uv_area = 0.0
        uv_islands = 0
        uv_stretch_values = []
        total_uv_area = 0.0
        total_3d_area = 0.0

        if uv_layer is not None:
            uv_islands = _count_uv_islands(bm, uv_layer)
            for face in bm.faces:
                verts = [loop.vert for loop in face.loops]
                uvs = [loop[uv_layer].uv.copy() for loop in face.loops]
                face_uv_area = _uv_polygon_area(uvs)
                face_3d_area = face.calc_area()
                uv_area += face_uv_area

                if face_3d_area > 1e-12 and face_uv_area > 0.0:
                    total_uv_area += face_uv_area
                    total_3d_area += face_3d_area

                scale_factor = (
                    math.sqrt(face_3d_area) / math.sqrt(face_uv_area)
                    if face_uv_area > 1e-8 else 1.0
                )
                edge_stretches = []
                for i, vert in enumerate(verts):
                    next_vert = verts[(i + 1) % len(verts)]
                    length_3d = (vert.co - next_vert.co).length
                    if length_3d <= 1e-5:
                        continue
                    uv_a = uvs[i] * scale_factor
                    uv_b = uvs[(i + 1) % len(uvs)] * scale_factor
                    edge_stretches.append(abs((uv_a - uv_b).length / length_3d - 1.0))
                if edge_stretches:
                    uv_stretch_values.append(sum(edge_stretches) / len(edge_stretches))

        uv_stretch = (
            round(sum(uv_stretch_values) / len(uv_stretch_values), 4)
            if uv_stretch_values else 0.0
        )
        uv_textel_density = (
            round(math.sqrt(total_uv_area / total_3d_area), 4)
            if total_uv_area > 0.0 and total_3d_area > 1e-12 else 0.0
        )

        nonmanifold_count = _count_nonmanifold_vertices_bmesh(bm)
        nonmanifold_percentage = round(
            100.0 * nonmanifold_count / total_verts, 2
        ) if total_verts else 0.0

        transforms_applied = (
            all(abs(value - 1.0) <= 1e-5 for value in obj.scale)
            and all(abs(value) <= 1e-5 for value in obj.rotation_euler)
        )
        at_origin = all(abs(value) <= 1e-5 for value in obj.location)

        return {
            "UV_area": round(uv_area * 100.0, 4),
            "UV_islands": int(uv_islands),
            "UV_stretch": round(uv_stretch * 100.0, 4),
            "UV_textel_density": uv_textel_density,
            "Normal_percentage": _normal_percentage(obj, bm),
            "Transformations": bool(transforms_applied),
            "Position": bool(at_origin),
            "Non_quads_percentage": non_quads,
            "Vertex_duplicate": int(duplicate_count),
            "Vertex_duplicate_percentage": duplicate_percentage,
            "Non_manifold": int(nonmanifold_count),
            "Non_manifold_percentage": nonmanifold_percentage,
            "N_faces": int(total_faces),
            "N_meshes": int(parts),
            "Face_by_mesh": round(total_faces / parts, 2) if parts else 0.0,
            "Angle": _mean_face_angle(bm),
        }
    finally:
        bm.free()


def _create_combined_scene_mesh_object():
    """Create one temporary world-space mesh from all convertible scene objects.

    Cameras and lights are excluded. Source objects are never selected, joined,
    converted, modified, or deleted. The temporary result is removed immediately
    after the metrics have been calculated, which is safer than invoking Undo from
    a save_pre handler and leaves the user's scene exactly as it was.
    """
    scene = bpy.context.scene
    depsgraph = bpy.context.evaluated_depsgraph_get()
    combined_bm = bmesh.new()
    source_names = []

    try:
        for obj in sorted(scene.objects, key=lambda item: item.name):
            if obj.type in {'CAMERA', 'LIGHT'}:
                continue

            # Objects without renderable/convertible geometry (empties, speakers,
            # light probes, etc.) are ignored naturally.
            if obj.type not in {
                'MESH', 'CURVE', 'SURFACE', 'META', 'FONT',
                'CURVES', 'POINTCLOUD', 'VOLUME', 'GREASEPENCIL'
            }:
                continue

            temp_mesh = None
            evaluated_obj = None
            try:
                if obj.type == 'MESH' and safe_mode_of_object(obj) == 'EDIT':
                    # Synchronize current UV loop coordinates as well as geometry.
                    # update_from_editmode() alone can leave UV Editor transforms
                    # unavailable to the evaluated mesh during save_pre.
                    _flush_edit_mesh_uv_data(obj)
                    depsgraph.update()

                evaluated_obj = obj.evaluated_get(depsgraph)
                temp_mesh = evaluated_obj.to_mesh(
                    preserve_all_data_layers=True,
                    depsgraph=depsgraph,
                )
                if temp_mesh is None or len(temp_mesh.vertices) == 0:
                    continue

                before = len(combined_bm.verts)
                combined_bm.from_mesh(temp_mesh)
                combined_bm.verts.ensure_lookup_table()
                new_verts = list(combined_bm.verts[before:])
                if new_verts:
                    bmesh.ops.transform(
                        combined_bm,
                        matrix=obj.matrix_world,
                        verts=new_verts,
                    )
                source_names.append(obj.name)
            except Exception as exc:
                log_warning(f"Could not add {getattr(obj, 'name', '?')} to combined mesh", exc)
            finally:
                if evaluated_obj is not None and temp_mesh is not None:
                    try:
                        evaluated_obj.to_mesh_clear()
                    except Exception as exc:
                        log_warning(f"Could not clear temporary mesh for {getattr(obj, 'name', '?')}", exc)

        if not combined_bm.verts:
            combined_bm.free()
            return None, None, []

        combined_bm.verts.ensure_lookup_table()
        combined_bm.edges.ensure_lookup_table()
        combined_bm.faces.ensure_lookup_table()
        combined_bm.normal_update()

        combined_mesh = bpy.data.meshes.new("DataLogger_CombinedMesh_TEMP")
        combined_bm.to_mesh(combined_mesh)
        combined_bm.free()
        combined_bm = None
        combined_mesh.update()

        combined_obj = bpy.data.objects.new("DataLogger_CombinedScene_TEMP", combined_mesh)
        # Do not link it to a collection: calculations can use the datablock directly,
        # and an unlinked temporary object cannot affect the visible scene or selection.
        return combined_obj, combined_mesh, source_names
    except Exception:
        if combined_bm is not None:
            combined_bm.free()
        raise


def _remove_combined_scene_mesh_object(combined_obj, combined_mesh):
    """Delete the temporary calculation datablocks without touching scene objects."""
    try:
        if combined_obj is not None:
            bpy.data.objects.remove(combined_obj, do_unlink=True)
    except Exception as exc:
        log_warning("Could not remove temporary combined object", exc)
    try:
        if combined_mesh is not None and combined_mesh.name in bpy.data.meshes:
            bpy.data.meshes.remove(combined_mesh, do_unlink=True)
    except Exception as exc:
        log_warning("Could not remove temporary combined mesh", exc)


def save_scene_mesh_metrics():
    """Calculate one metric set from all scene geometry except cameras and lights."""
    objects = {}
    combined_obj = None
    combined_mesh = None
    source_names = []

    try:
        combined_obj, combined_mesh, source_names = _create_combined_scene_mesh_object()
        if combined_obj is None:
            objects["CombinedSceneMesh"] = {
                "error": "No convertible geometry found after excluding cameras and lights"
            }
        else:
            metrics = calculate_mesh_metrics(combined_obj)
            metrics["Source_object_count"] = len(source_names)
            metrics["Source_objects"] = source_names
            objects["CombinedSceneMesh"] = metrics
    except Exception as exc:
        log_warning("Could not calculate combined scene mesh metrics", exc)
        objects["CombinedSceneMesh"] = {"error": f"{type(exc).__name__}: {exc}"}
    finally:
        _remove_combined_scene_mesh_object(combined_obj, combined_mesh)

    payload = {
        "schema_version": 2,
        "logger_version": LOGGER_VERSION,
        "saved_at_unix": round(time.time(), 3),
        "blend_file": bpy.data.filepath,
        "calculation_mode": "combined_scene_geometry",
        "excluded_object_types": ["CAMERA", "LIGHT"],
        "scene_restored": True,
        "objects": objects,
    }
    # Mesh metrics are stored only as CSV. Remove the legacy JSON text block so
    # old embedded data cannot be mistaken for the current export format.
    if LEGACY_MESH_METRICS_JSON_TEXTBLOCK in bpy.data.texts:
        bpy.data.texts.remove(bpy.data.texts[LEGACY_MESH_METRICS_JSON_TEXTBLOCK])

    metric_fields = [
        "SavedAtUnix", "ObjectName", "UV_area", "UV_islands",
        "UV_stretch", "UV_textel_density", "Normal_percentage",
        "Transformations", "Position", "Non_quads_percentage",
        "Vertex_duplicate", "Vertex_duplicate_percentage",
        "Non_manifold", "Non_manifold_percentage", "N_faces",
        "N_meshes", "Face_by_mesh", "Angle", "Source_object_count",
        "Source_objects", "Error",
    ]
    csv_buffer = io.StringIO()
    writer = csv.DictWriter(csv_buffer, fieldnames=metric_fields, lineterminator="\n")
    writer.writeheader()
    for object_name, metrics in objects.items():
        row = {field: "" for field in metric_fields}
        row["SavedAtUnix"] = payload["saved_at_unix"]
        row["ObjectName"] = object_name
        if isinstance(metrics, dict):
            for field in metric_fields:
                if field in metrics:
                    value = metrics[field]
                    if field == "Source_objects" and isinstance(value, list):
                        value = json.dumps(value, ensure_ascii=False)
                    row[field] = value
            row["Error"] = metrics.get("error", "")
        writer.writerow(row)

    csv_content = csv_buffer.getvalue()
    with open(TEMP_MESH_METRICS_CSV_PATH, "w", encoding="utf-8", newline="") as handle:
        handle.write(csv_content)
    metrics_csv_txt = get_or_create_textblock(MESH_METRICS_CSV_TEXTBLOCK)
    metrics_csv_txt.clear()
    metrics_csv_txt.write(csv_content)
    return payload

# OPERATOR DETECTION





UV_DEPLOY_OPS = {
    "uv.unwrap",
    "uv.smart_project",
    "uv.lightmap_pack",
    "uv.follow_active_quads",
    "uv.cube_project",
    "uv.cylinder_project",
    "uv.sphere_project",
    "uv.project_from_view",
    "uv.reset",
}

MERGE_OPS = {
    "mesh.merge",
    "mesh.remove_doubles",
    "mesh.merge_by_distance",
    "mesh.edge_collapse",
    "mesh.dissolve_verts",
    "mesh.dissolve_edges",
    "mesh.dissolve_faces",
}


def normalize_operator_name(bl_idname):
    return bl_idname.replace("_OT_", ".").lower()


def mark_uv_pending():
    global _uv_action_pending, DEBUG_UV_PENDING

    if not ENABLE_UV_CHANGE_TRACKING:
        _uv_action_pending = 0
        DEBUG_UV_PENDING = 0
        return False

    _uv_action_pending = 1
    DEBUG_UV_PENDING = 1
    return True


def detect_flags_from_operator(bl_idname):
    global operator_flags
    global DEBUG_LAST_OPERATOR, DEBUG_LAST_FLAGS

    op = normalize_operator_name(bl_idname)
    DEBUG_LAST_OPERATOR = op

    changed = False

    if (
        "view3d.pastebuffer" in op or
        "wm.paste" in op or
        "pastebuffer" in op or
        op.endswith(".paste")
    ):
        if operator_flags["ctrl_v"] == 0:
            operator_flags["ctrl_v"] = 1
            changed = True

    if (
        "object.duplicate_move" in op or
        op == "object.duplicate" or
        "mesh.duplicate_move" in op or
        op == "mesh.duplicate"
    ):
        if "linked" not in op:
            if operator_flags["shift_d"] == 0:
                operator_flags["shift_d"] = 1
                changed = True

    if (
        "object.duplicate_move_linked" in op or
        "object.duplicate_linked" in op
    ):
        if operator_flags["alt_d"] == 0:
            operator_flags["alt_d"] = 1
            changed = True

    if op in MERGE_OPS or "merge" in op:
        if operator_flags["merge"] == 0:
            operator_flags["merge"] = 1
            changed = True

    edit_obj = getattr(bpy.context, "edit_object", None)
    active_obj = getattr(bpy.context, "object", None)
    mesh_is_being_edited = bool(
        (edit_obj is not None and edit_obj.type == "MESH")
        or (
            active_obj is not None
            and active_obj.type == "MESH"
            and safe_mode_of_object(active_obj) == "EDIT"
        )
    )

    # Only real UV deployment/unwrap operations are logged. Editing, moving,
    # rotating, scaling, packing or other UV manipulation is intentionally ignored
    # because live UV edit tracking has historically been a source of instability.
    uv_detected = False
    if op in UV_DEPLOY_OPS:
        mark_uv_pending()
        uv_detected = True

    if uv_detected:
        changed = True

    DEBUG_LAST_FLAGS = (
        f"CtrlV={operator_flags['ctrl_v']} "
        f"ShiftD={operator_flags['shift_d']} "
        f"AltD={operator_flags['alt_d']} "
        f"Merge={operator_flags['merge']} "
        f"Undo={operator_flags['undo']}"
    )

    return changed


def process_new_operators():
    global _last_operator_index

    changed = False

    try:
        wm = bpy.context.window_manager
        ops = wm.operators
        count = len(ops)

        if count < _last_operator_index:
            _last_operator_index = 0

        if count == _last_operator_index:
            return False

        for i in range(_last_operator_index, count):
            try:
                bl_id = ops[i].bl_idname
            except Exception as exc:
                log_warning("Could not read a recent operator", exc)
                continue

            if detect_flags_from_operator(bl_id):
                changed = True

        _last_operator_index = count
    except Exception as exc:
        log_warning("Could not process new operators", exc)
        return False

    return changed


@persistent
def undo_tracker(*_args):
    """Accumulate every completed Undo and flush the burst as one sample."""
    global _last_operator_index, _undo_last_event_time, _force_log_pending, _undo_wrapper_inflight

    if not timer_running:
        return

    # Ctrl+Z in the 3D View is counted by our wrapper so every key press
    # survives Blender's Edit Mode local undo stack. undo_post remains as a
    # fallback for Undo invoked from menus/search/Python.
    if _undo_wrapper_inflight:
        return

    operator_flags["undo"] = int(operator_flags.get("undo", 0)) + 1
    _undo_last_event_time = time.time()
    _force_log_pending = True

    # Undo can shrink/rebuild Blender's recent-operator stack. Rebase the
    # cursor so old operators are not replayed as if they were new actions.
    try:
        _last_operator_index = len(bpy.context.window_manager.operators)
    except Exception:
        pass


@persistent
def operator_tracker(scene, depsgraph):
    """Wake the logger for Blender data updates without touching live BMesh.

    The depsgraph handler deliberately does no geometry traversal.  For mesh
    updates in Edit Mode it only records the update time; logger_timer waits for
    a quiet period before performing the expensive snapshot.
    """
    global _last_mesh_update_time

    meaningful_update = process_new_operators()
    mesh_update = False

    try:
        for update in depsgraph.updates:
            datablock = getattr(update, "id", None)
            if isinstance(datablock, bpy.types.Mesh):
                meaningful_update = True
                mesh_update = True
            elif isinstance(datablock, bpy.types.Object):
                meaningful_update = True
    except Exception as exc:
        log_warning("Could not inspect depsgraph updates", exc)

    if mesh_update:
        _last_mesh_update_time = time.time()

    if meaningful_update:
        force_log_soon()


# UNDO WRAPPER

class VIEW3D_OT_undo_logger(bpy.types.Operator):
    """Count every Ctrl+Z press, including mesh Edit Mode local undos."""
    bl_idname = "view3d.undo_logger"
    bl_label = "Undo"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        global _undo_wrapper_inflight, _undo_last_event_time, _force_log_pending

        if not timer_running:
            # Preserve normal Blender behaviour even when logging is stopped.
            try:
                bpy.ops.ed.undo()
                return {'FINISHED'}
            except Exception:
                return {'CANCELLED'}

        # Count the user action before invoking Blender's undo.  In Edit Mode
        # Blender may collapse several local undos into one undo_post event, so
        # the key press is the reliable unit we need for the metric.
        operator_flags["undo"] = int(operator_flags.get("undo", 0)) + 1
        _undo_last_event_time = time.time()
        _force_log_pending = True

        try:
            _undo_wrapper_inflight = True
            bpy.ops.ed.undo()
            return {'FINISHED'}
        except Exception as exc:
            # Undo did not execute: roll back the metric increment.
            operator_flags["undo"] = max(0, int(operator_flags.get("undo", 0)) - 1)
            log_warning("Could not execute Undo", exc)
            return {'CANCELLED'}
        finally:
            _undo_wrapper_inflight = False


# DUPLICATION / PASTE WRAPPERS

class VIEW3D_OT_duplicate_logger(bpy.types.Operator):
    """Exact Shift+D wrapper so normal duplication cannot be confused with linked duplication."""
    bl_idname = "view3d.duplicate_logger"
    bl_label = TRANSLATIONS["en"]["duplicate_logging"]
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global operator_flags
        operator_flags["shift_d"] = 1
        operator_flags["alt_d"] = 0
        force_log_soon()
        try:
            if context.object is not None and safe_mode_of_object(context.object) == "EDIT":
                bpy.ops.mesh.duplicate_move('INVOKE_DEFAULT')
            else:
                bpy.ops.object.duplicate_move('INVOKE_DEFAULT')
            return {'FINISHED'}
        except Exception as exc:
            self.report({'WARNING'}, f"{tr('duplicate_failed', context)}: {exc}")
            return {'CANCELLED'}


class VIEW3D_OT_instance_logger(bpy.types.Operator):
    """Exact Alt+D wrapper for linked object duplication / instancing."""
    bl_idname = "view3d.instance_logger"
    bl_label = TRANSLATIONS["en"]["instance_logging"]
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global operator_flags
        operator_flags["alt_d"] = 1
        operator_flags["shift_d"] = 0
        force_log_soon()
        try:
            bpy.ops.object.duplicate_move_linked('INVOKE_DEFAULT')
            return {'FINISHED'}
        except Exception as exc:
            self.report({'WARNING'}, f"{tr('instance_failed', context)}: {exc}")
            return {'CANCELLED'}


class VIEW3D_OT_paste_logger(bpy.types.Operator):
    """Paste in the 3D View and flag the action for logging."""
    bl_idname = "view3d.paste_logger"
    bl_label = TRANSLATIONS["en"]["paste_logging"]
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global operator_flags

        try:
            bpy.ops.view3d.pastebuffer()
            operator_flags["ctrl_v"] = 1
            force_log_soon()
            return {'FINISHED'}
        except Exception as e:
            self.report({'WARNING'}, f"{tr('paste_failed', context)}: {e}")
            return {'CANCELLED'}


# STATE SNAPSHOT

def _is_smooth_by_angle_modifier(modifier):
    """Return True for Blender's Smooth by Angle geometry-nodes effect."""
    try:
        name = str(getattr(modifier, "name", "") or "").strip().lower()
        if name == "smooth by angle" or name.startswith("smooth by angle."):
            return True
        if getattr(modifier, "type", "") == "NODES":
            group = getattr(modifier, "node_group", None)
            group_name = str(getattr(group, "name", "") or "").strip().lower()
            if group_name == "smooth by angle" or group_name.startswith("smooth by angle."):
                return True
    except Exception:
        pass
    return False


def _counted_modifiers(scene):
    """Yield actual modifiers while excluding the Smooth by Angle shading effect."""
    for obj in scene.objects:
        for modifier in obj.modifiers:
            if not _is_smooth_by_angle_modifier(modifier):
                yield modifier


def build_snapshot(expensive=True, safe_edit_geometry=False):
    """Build a logger snapshot.

    expensive=True performs geometry scans and polygon statistics.
    expensive=False reuses the last mesh baseline and only reads cheap state
    such as camera, active-object transform, object/modifier counts and occlusion.
    """
    scene = bpy.context.scene

    user = get_camera_pos()
    active_name = get_active_object_name()
    counted_modifiers = tuple(_counted_modifiers(scene))
    total_mods = len(counted_modifiers)
    object_ids = frozenset(int(o.as_pointer()) for o in scene.objects)
    modifier_ids = frozenset(int(m.as_pointer()) for m in counted_modifiers)

    active_obj = bpy.context.object
    if active_obj is not None and safe_mode_of_object(active_obj) == "EDIT":
        mode = "EDIT_MESH"
    else:
        mode = "OBJECT"

    # Never ask Blender for geometry-derived bounds while its live edit mesh is
    # being mutated. Object transforms cannot change from vertex editing, so the
    # previous safe object state is the correct logger value in this window.
    if mode == "EDIT_MESH":
        ox, oy, oz, orad = prev_object_state
    else:
        ox, oy, oz, orad = get_active_object_data()

    # In Edit Mode, geometry can only be sampled through a synchronized Mesh
    # datablock after a quiet period. The live BMesh is never traversed.
    edit_snapshot = None
    if mode == "EDIT_MESH" and expensive and safe_edit_geometry:
        edit_snapshot = get_edit_mesh_snapshot_from_synced_data()

    expensive_object_mode = bool(expensive and mode != "EDIT_MESH")

    if edit_snapshot is not None:
        total_verts = edit_snapshot["verts"]
        ngons = edit_snapshot["ngons"]
        tris = edit_snapshot["tris"]
        total_inverted = edit_snapshot["inverted"]
        total_nonmanifold = edit_snapshot["nonmanifold"]
        geometry_hash = edit_snapshot["geometry_hash"]
        # Bounds can depend on edited coordinates. Avoid forcing an evaluated
        # bounds update here; Object Mode will reconcile scene radius safely.
        scene_radius = prev_snapshot_signature[1] if prev_snapshot_signature is not None else 0.0
    elif expensive_object_mode:
        meshes = [o for o in scene.objects if o.type == "MESH"]
        total_verts = 0
        ngons = 0
        tris = 0
        total_inverted = 0
        total_nonmanifold = 0

        for obj in meshes:
            v, n, t, inv = get_realtime_mesh_stats_safe(obj)
            total_verts += v
            ngons += n
            tris += t
            total_inverted += inv
            total_nonmanifold += count_nonmanifold_vertices_safe(obj)

        scene_radius = get_scene_radius()
        geometry_hash = get_realtime_geometry_hash_safe()
    else:
        total_verts = prev_vert_count
        ngons = prev_ngon_count
        tris = prev_tri_count
        total_inverted = prev_inverted_normals
        total_nonmanifold = prev_nonmanifold_count
        geometry_hash = prev_geometry_hash

        if prev_snapshot_signature is not None:
            scene_radius = prev_snapshot_signature[1]
        else:
            scene_radius = get_scene_radius()

    snapshot = {
        "user": (user[0], user[1], user[2]),
        "scene_radius": scene_radius,
        "object": (ox, oy, oz, orad),
        "active_name": active_name,
        "verts": total_verts,
        "ngons": ngons,
        "tris": tris,
        "inverted": total_inverted,
        "nonmanifold": total_nonmanifold,
        "obj_count": len(scene.objects),
        "object_ids": object_ids,
        "modifier_ids": modifier_ids,
        "mods": total_mods,
        "mode": mode,
        "geometry_hash": geometry_hash,
        "occlusion": get_occlusion_state(),
        "orthographic": get_orthographic_state(),
    }

    signature = (
        tuple(trunc_all(snapshot["user"])),
        trunc_2(snapshot["scene_radius"]),
        tuple(trunc_all(snapshot["object"])),
        snapshot["active_name"],
        snapshot["verts"],
        snapshot["ngons"],
        snapshot["tris"],
        snapshot["inverted"],
        snapshot["nonmanifold"],
        snapshot["obj_count"],
        snapshot["mods"],
        snapshot["mode"],
        snapshot["geometry_hash"],
        snapshot["occlusion"],
        snapshot["orthographic"],
    )

    return snapshot, signature


def apply_snapshot_as_baseline(snapshot, signature):
    global prev_vert_count
    global prev_ngon_count
    global prev_tri_count
    global prev_inverted_normals
    global prev_nonmanifold_count
    global prev_object_count
    global prev_object_ids
    global prev_modifier_ids
    global prev_total_mods
    global prev_mode
    global prev_geometry_hash
    global prev_snapshot_signature
    global prev_active_object_name
    global prev_object_state

    prev_vert_count = snapshot["verts"]
    prev_ngon_count = snapshot["ngons"]
    prev_tri_count = snapshot["tris"]
    prev_inverted_normals = snapshot["inverted"]
    prev_nonmanifold_count = snapshot["nonmanifold"]
    prev_object_count = snapshot["obj_count"]
    prev_total_mods = snapshot["mods"]
    prev_object_ids = snapshot["object_ids"]
    prev_modifier_ids = snapshot["modifier_ids"]
    prev_mode = snapshot["mode"]
    prev_geometry_hash = snapshot["geometry_hash"]
    prev_snapshot_signature = signature
    prev_active_object_name = snapshot["active_name"]
    prev_object_state = snapshot["object"]


def init_state_full():
    global _last_operator_index
    global _last_timestamp, _force_log_pending
    global _uv_action_pending
    global operator_flags, _undo_last_event_time
    global DEBUG_LAST_LOG_REASON, DEBUG_LAST_REBASE_REASON, DEBUG_UV_PENDING

    snapshot, signature = build_snapshot()
    apply_snapshot_as_baseline(snapshot, signature)

    _last_timestamp = -1.0
    _uv_action_pending = 0
    operator_flags = {
        "ctrl_v": 0,
        "shift_d": 0,
        "alt_d": 0,
        "merge": 0,
        "undo": 0,
    }

    DEBUG_LAST_LOG_REASON = ""
    DEBUG_LAST_REBASE_REASON = ""
    DEBUG_UV_PENDING = 0
    _undo_last_event_time = 0.0

    try:
        _last_operator_index = len(bpy.context.window_manager.operators)
    except Exception as exc:
        log_warning("Could not initialize the operator index", exc)
        _last_operator_index = 0


def init_state_deferred():
    """Reset cheap logger state without scanning every mesh immediately."""
    global _last_operator_index, _last_timestamp, _force_log_pending
    global _uv_action_pending, operator_flags, _undo_last_event_time
    global prev_snapshot_signature, _baseline_ready
    global DEBUG_LAST_LOG_REASON, DEBUG_LAST_REBASE_REASON
    global DEBUG_UV_PENDING

    _last_timestamp = -1.0
    _force_log_pending = False
    _uv_action_pending = 0
    prev_snapshot_signature = None
    _baseline_ready = False
    operator_flags = {
        "ctrl_v": 0,
        "shift_d": 0,
        "alt_d": 0,
        "merge": 0,
        "undo": 0,
    }
    DEBUG_LAST_LOG_REASON = "starting"
    DEBUG_LAST_REBASE_REASON = "baseline_deferred"
    DEBUG_UV_PENDING = 0
    _undo_last_event_time = 0.0

    try:
        _last_operator_index = len(bpy.context.window_manager.operators)
    except Exception as exc:
        log_warning("Could not initialize the operator index", exc)
        _last_operator_index = 0


def ensure_deferred_baseline():
    """Create a baseline without ever traversing a live Edit Mode mesh."""
    global _baseline_ready
    if _baseline_ready or not timer_running:
        return
    snapshot, signature = build_snapshot(expensive=not mesh_edit_mode_active())
    apply_snapshot_as_baseline(snapshot, signature)
    _baseline_ready = True

# LOGGER CONTROL

def has_accepted_consent():
    """Return whether recording is allowed by the internal consent policy."""
    if not ENABLE_CONSENT_FLOW:
        return True
    if CONSENT_TEXTBLOCK not in bpy.data.texts:
        return False
    return "ACCEPTED" in bpy.data.texts[CONSENT_TEXTBLOCK].as_string()


def accept_consent_from_start_button():
    """Treat the explicit Start Logger action as consent without showing a popup."""
    if not ENABLE_CONSENT_FLOW:
        return
    consent_text = get_or_create_textblock(CONSENT_TEXTBLOCK)
    consent_text.clear()
    consent_text.write("ACCEPTED")
    consent_text.use_fake_user = True


def should_prompt_for_consent_on_load():
    """Request consent only when opening an actual saved .blend file.

    This prevents the popup from appearing when the add-on is installed or enabled.
    Intended flow: install add-on -> save .blend -> close -> reopen -> show consent.
    """
    if not ENABLE_CONSENT_FLOW:
        return False
    return bool(bpy.data.filepath) and not has_accepted_consent()


def request_consent_popup(delay=0.5, only_if_saved_file=False):
    """Show the consent dialog after a short delay so Blender has an active window."""
    if not ENABLE_CONSENT_FLOW:
        return

    def _show():
        if only_if_saved_file and not should_prompt_for_consent_on_load():
            return None

        if not has_accepted_consent() and not timer_running:
            try:
                bpy.ops.wm.data_logger_consent('INVOKE_DEFAULT')
            except Exception as exc:
                log_warning("Could not show the consent dialog", exc)
        return None

    bpy.app.timers.register(_show, first_interval=delay)


def start_logger():
    global timer_running
    global start_time
    global _last_lightweight_signature, _last_idle_full_check, _last_full_scan_time
    global _last_mesh_update_time
    global _last_edit_row_time, _last_edit_safe_scan_time

    # Safety guard used only when the internal consent workflow is enabled.
    if ENABLE_CONSENT_FLOW and not has_accepted_consent():
        print("Data Logger blocked: consent is required before starting.")
        request_consent_popup()
        return

    if timer_running:
        return

    restored = restore_csv_from_blend()
    if not restored:
        init_csv()
    else:
        ensure_file_ends_with_newline(TEMP_CSV_PATH)

    init_state_deferred()
    start_time = time.time()

    _last_lightweight_signature = None
    _last_idle_full_check = 0.0
    _last_full_scan_time = 0.0
    _last_mesh_update_time = 0.0
    _last_edit_row_time = 0.0
    _last_edit_safe_scan_time = 0.0
    timer_running = True
    bpy.app.timers.register(logger_timer, first_interval=LOGGER_INITIAL_DELAY)
    tag_blender_bars_for_redraw()
    print("Data Logger started.")


def stop_logger():
    global timer_running, _baseline_ready
    global _last_lightweight_signature, _last_idle_full_check, _last_full_scan_time
    global _last_mesh_update_time
    global _last_edit_row_time, _last_edit_safe_scan_time

    timer_running = False
    _baseline_ready = False
    _last_lightweight_signature = None
    _last_idle_full_check = 0.0
    _last_full_scan_time = 0.0
    _last_mesh_update_time = 0.0
    _last_edit_row_time = 0.0
    _last_edit_safe_scan_time = 0.0
    tag_blender_bars_for_redraw()

    # Persist once when recording stops instead of after every row.
    if not ENABLE_CONSENT_FLOW or has_accepted_consent():
        remove_duplicate_rows()
        import_csv_to_blend()
    print("Data Logger stopped.")


def hard_stop_logger_on_file_load():
    """Stop any previous timer when another .blend file is opened.

    This prevents a session that was recording another file from writing to
    the newly opened file before consent has been confirmed.
    """
    global timer_running, start_time, _force_log_pending, _baseline_ready
    global _last_lightweight_signature, _last_idle_full_check
    timer_running = False
    start_time = None
    _force_log_pending = False
    _baseline_ready = False
    tag_blender_bars_for_redraw()


class WM_OT_data_logger_toggle(bpy.types.Operator):
    """Start or stop the workflow logger."""
    bl_idname = "wm.data_logger_toggle"
    bl_label = TRANSLATIONS["en"]["toggle_logger"]
    bl_description = TRANSLATIONS["en"]["toggle_logger_tip"]

    @classmethod
    def description(cls, context, properties):
        return tr("stop_logger_tip" if timer_running else "start_logger_tip", context)

    def execute(self, context):
        if timer_running:
            stop_logger()
            self.report({'INFO'}, tr("logger_stopped", context))
            return {'FINISHED'}

        if ENABLE_CONSENT_FLOW and not has_accepted_consent():
            # Pressing Start Logger is itself an explicit user action, so record
            # consent directly and start without opening a separate dialog.
            accept_consent_from_start_button()

        start_logger()
        self.report({'INFO'}, tr("logger_started", context))
        return {'FINISHED'}


# DATA COLLECTION

def collect_data(force=False, expensive=True, safe_edit_geometry=False):
    """Collect one row only when a measurable supported event occurred.

    Completed UV operators are logged once as UV actions. A lightweight event
    hash is stored with that row, so translate/rotate/scale operations are not
    sampled continuously frame by frame and UV coordinates are not exported.
    """
    global _last_timestamp, _force_log_pending
    global prev_mode, prev_active_object_name, prev_object_state
    global operator_flags, _uv_action_pending
    global prev_geometry_hash
    global prev_nonmanifold_count, prev_object_ids, prev_modifier_ids
    global prev_snapshot_signature
    global DEBUG_LAST_LOG_REASON, DEBUG_LAST_REBASE_REASON
    global DEBUG_UV_PENDING

    if not _baseline_ready:
        ensure_deferred_baseline()
        return None

    process_new_operators()
    snapshot, signature = build_snapshot(expensive=expensive, safe_edit_geometry=safe_edit_geometry)

    # In Edit Mode, depsgraph mesh updates are themselves a supported event.
    # We record that activity without reading BMesh/topology. Geometry deltas
    # remain at the last safe baseline until Object Mode is restored.
    edit_mesh_activity = bool(
        snapshot["mode"] == "EDIT_MESH" and _force_log_pending
    )

    active_object_changed = (
        prev_active_object_name != snapshot["active_name"]
    )
    mode_changed_now = prev_mode != snapshot["mode"]

    geometry_changed = bool(expensive and snapshot["geometry_hash"] != prev_geometry_hash)

    current_user = tuple(trunc_all(snapshot["user"]))
    previous_user = (
        prev_snapshot_signature[0]
        if prev_snapshot_signature is not None
        else current_user
    )
    camera_changed = current_user != previous_user

    previous_occlusion = (
        prev_snapshot_signature[-2]
        if prev_snapshot_signature is not None
        else snapshot["occlusion"]
    )
    occlusion_changed = snapshot["occlusion"] != previous_occlusion

    previous_orthographic = (
        prev_snapshot_signature[-1]
        if prev_snapshot_signature is not None
        else snapshot["orthographic"]
    )
    orthographic_changed = snapshot["orthographic"] != previous_orthographic

    ox, oy, oz, orad = snapshot["object"]
    prev_ox, prev_oy, prev_oz, prev_orad = prev_object_state

    if active_object_changed:
        obj_dx = obj_dy = obj_dz = obj_drad = 0.0
    else:
        obj_dx = ox - prev_ox
        obj_dy = oy - prev_oy
        obj_dz = oz - prev_oz
        obj_drad = orad - prev_orad

    object_transform_changed = any(
        abs(value) > 1e-6
        for value in (obj_dx, obj_dy, obj_dz, obj_drad)
    )

    v_delta = snapshot["verts"] - prev_vert_count
    n_delta = snapshot["ngons"] - prev_ngon_count
    t_delta = snapshot["tris"] - prev_tri_count
    normal_delta = snapshot["inverted"] - prev_inverted_normals
    nonmanifold_delta = snapshot["nonmanifold"] - prev_nonmanifold_count
    obj_delta = snapshot["obj_count"] - prev_object_count
    mod_delta = snapshot["mods"] - prev_total_mods
    object_created = len(snapshot["object_ids"] - prev_object_ids)
    object_deleted = len(prev_object_ids - snapshot["object_ids"])
    modifier_created = len(snapshot["modifier_ids"] - prev_modifier_ids)
    modifier_deleted = len(prev_modifier_ids - snapshot["modifier_ids"])

    explicit_uv_operator = bool(_uv_action_pending)
    explicit_operator = bool(
        operator_flags["ctrl_v"]
        or operator_flags["shift_d"]
        or operator_flags["alt_d"]
        or operator_flags["undo"]
        or explicit_uv_operator
    )

    meaningful_change = bool(
        camera_changed
        or geometry_changed
        or object_transform_changed
        or active_object_changed
        or mode_changed_now
        or occlusion_changed
        or orthographic_changed
        or v_delta != 0
        or n_delta != 0
        or t_delta != 0
        or normal_delta != 0
        or nonmanifold_delta != 0
        or obj_delta != 0
        or mod_delta != 0
        or object_created != 0
        or object_deleted != 0
        or modifier_created != 0
        or modifier_deleted != 0
        or explicit_operator
        or edit_mesh_activity
    )

    # force=True may accelerate a check, but may not invent an event.
    if not meaningful_change:
        _uv_action_pending = 0
        DEBUG_UV_PENDING = 0
        _force_log_pending = False
        return None

    now = time.time()
    timestamp = trunc_2(now)

    if timestamp == _last_timestamp and not force:
        return None

    _last_timestamp = timestamp

    user = snapshot["user"]

    obj_mode_state = int(snapshot["mode"] == "OBJECT")
    edit_mode_state = int(snapshot["mode"] == "EDIT_MESH")

    # Only completed UV deployment/unwrap operators are exported.
    # Ordinary UV editing is ignored and no UV-coordinate data is written.
    uv_deploy = int(bool(_uv_action_pending))

    record = trunc_all([
        SCHEMA_VERSION, LOGGER_VERSION, SESSION_ID,
        get_or_create_user_id(),
        timestamp,
        user[0], user[1], user[2],
        ox, oy, oz, orad, int(object_transform_changed),
        v_delta, n_delta, t_delta, normal_delta, nonmanifold_delta,
        obj_mode_state, edit_mode_state, int(mode_changed_now),
        uv_deploy,
        obj_delta, object_created, object_deleted,
        mod_delta, modifier_created, modifier_deleted,
        int(bool(operator_flags["ctrl_v"] or operator_flags["shift_d"])), int(bool(operator_flags["alt_d"])),
        int(operator_flags["undo"]), snapshot["occlusion"], snapshot["orthographic"],
    ])

    reasons = []
    if camera_changed:
        reasons.append("camera_change")
    if geometry_changed:
        reasons.append("geometry_change")
    if edit_mesh_activity and not geometry_changed:
        reasons.append("edit_mesh_activity")
    if uv_deploy:
        reasons.append("uv_deploy")
    if object_transform_changed:
        reasons.append("object_transform")
    if active_object_changed:
        reasons.append("active_object_change")
    if mode_changed_now:
        reasons.append("mode_change")
    if occlusion_changed:
        reasons.append("occlusion_toggle")
    if orthographic_changed:
        reasons.append("orthographic_toggle")
    if obj_delta:
        reasons.append("object_count_change")
    if mod_delta or modifier_created or modifier_deleted:
        reasons.append("modifier_change")
    if nonmanifold_delta:
        reasons.append("nonmanifold_change")
    if operator_flags["ctrl_v"]:
        reasons.append("ctrl_v")
    if operator_flags["shift_d"]:
        reasons.append("shift_d")
    if operator_flags["alt_d"]:
        reasons.append("alt_d")
    if operator_flags["undo"]:
        reasons.append("undo")

    DEBUG_LAST_LOG_REASON = ",".join(reasons) or "measured_change"
    DEBUG_LAST_REBASE_REASON = ""

    apply_snapshot_as_baseline(snapshot, signature)

    operator_flags = {
        "ctrl_v": 0,
        "shift_d": 0,
        "alt_d": 0,
        "merge": 0,
        "undo": 0,
    }
    _uv_action_pending = 0
    DEBUG_UV_PENDING = 0
    _force_log_pending = False

    return ",".join(str(v) for v in record)

def build_lightweight_signature():
    """Return a cheap UI/navigation state without scanning mesh topology."""
    obj = getattr(bpy.context, "object", None)
    if obj is None:
        obj_state = ("", "", ())
    else:
        try:
            matrix_values = tuple(round(float(v), 5) for row in obj.matrix_world for v in row)
        except Exception:
            matrix_values = ()
        obj_state = (obj.name, safe_mode_of_object(obj), matrix_values)

    camera = tuple(round(float(v), 3) for v in get_camera_pos())
    return (camera, obj_state, get_occlusion_state(), get_orthographic_state())


def write_log_row(force=False, expensive=True, safe_edit_geometry=False):
    """Append one new CSV row without rewriting the complete log.
    """
    row = collect_data(force=force, expensive=expensive, safe_edit_geometry=safe_edit_geometry)
    if row:
        append_csv(row)


def logger_timer():
    global _force_log_pending, _last_lightweight_signature
    global _last_idle_full_check, _last_full_scan_time
    global _last_edit_row_time, _last_edit_safe_scan_time

    if not timer_running:
        return None

    if not _baseline_ready:
        ensure_deferred_baseline()
        _last_lightweight_signature = build_lightweight_signature()
        now = time.time()
        _last_idle_full_check = now
        _last_full_scan_time = now
        return LOGGER_POLL_INTERVAL

    if process_new_operators():
        # Operator-only actions (notably Undo) may not always produce a distinct
        # lightweight viewport signature. Wake the logger explicitly so the
        # action is still written once.
        force_log_soon()

    previous_lightweight = _last_lightweight_signature
    lightweight = build_lightweight_signature()
    _last_lightweight_signature = lightweight

    camera_changed = False
    object_state_changed = False
    occlusion_changed = False
    orthographic_changed = False
    if previous_lightweight is not None:
        camera_changed = lightweight[0] != previous_lightweight[0]
        object_state_changed = lightweight[1] != previous_lightweight[1]
        occlusion_changed = lightweight[2] != previous_lightweight[2]
        orthographic_changed = lightweight[3] != previous_lightweight[3]

    now = time.time()

    # Wait until a rapid Ctrl+Z burst is quiet before flushing it.  The Undo
    # field remains an integer counter until collect_data writes the row.
    if operator_flags.get("undo", 0) and _undo_last_event_time:
        if (now - _undo_last_event_time) < UNDO_BURST_DEBOUNCE:
            return LOGGER_POLL_INTERVAL

    # Edit Mode remains fully observable without traversing Blender's live BMesh.
    # During an update burst we emit only coalesced lightweight rows. After a
    # short quiet period we synchronize edit data into the ordinary Mesh
    # datablock and take one bounded geometry snapshot. Randomize/Proportional
    # Edit/sculpt-like bursts therefore cannot cause a BMesh read/write race.
    if mesh_edit_mode_active():
        activity = _force_log_pending or object_state_changed or camera_changed or occlusion_changed or orthographic_changed
        quiet = not edit_mesh_is_settling(now)
        safe_scan_due = (now - _last_edit_safe_scan_time) >= EDIT_MODE_SAFE_SCAN_INTERVAL
        row_due = (now - _last_edit_row_time) >= EDIT_MODE_ROW_MIN_INTERVAL

        if activity and quiet and safe_scan_due:
            _last_edit_safe_scan_time = now
            _last_edit_row_time = now
            write_log_row(force=True, expensive=True, safe_edit_geometry=True)
        elif activity and row_due:
            _last_edit_row_time = now
            write_log_row(force=True, expensive=False)

        return LOGGER_POLL_INTERVAL

    idle_full_check_due = (
        now - _last_idle_full_check
    ) >= LOGGER_IDLE_FULL_CHECK_INTERVAL
    full_scan_allowed = (
        now - _last_full_scan_time
    ) >= LOGGER_FULL_SCAN_MIN_INTERVAL

    # Once Object Mode is safe again, perform a full snapshot. This reconciles
    # the net geometry/topology change made during Edit Mode without replaying
    # every intermediate BMesh state.
    if (_force_log_pending or object_state_changed) and full_scan_allowed:
        _last_full_scan_time = now
        _last_idle_full_check = now
        write_log_row(force=True, expensive=True)
        _force_log_pending = False
    elif (camera_changed or occlusion_changed or orthographic_changed) and not _force_log_pending:
        write_log_row(force=True, expensive=False)
    elif idle_full_check_due and full_scan_allowed:
        _last_full_scan_time = now
        _last_idle_full_check = now
        write_log_row(force=False, expensive=True)

    return LOGGER_POLL_INTERVAL


# KEYMAPS

def register_keymaps():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if not kc:
        return
    km = kc.keymaps.new(name="3D View", space_type="VIEW_3D")
    kmi = km.keymap_items.new("view3d.undo_logger", 'Z', 'PRESS', ctrl=True)
    addon_keymaps.append((km, kmi))
    kmi = km.keymap_items.new("view3d.paste_logger", 'V', 'PRESS', ctrl=True)
    addon_keymaps.append((km, kmi))
    kmi = km.keymap_items.new("view3d.duplicate_logger", 'D', 'PRESS', shift=True)
    addon_keymaps.append((km, kmi))
    kmi = km.keymap_items.new("view3d.instance_logger", 'D', 'PRESS', alt=True)
    addon_keymaps.append((km, kmi))


def unregister_keymaps():
    for km, kmi in addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception as exc:
            log_warning("Could not remove a logger keymap", exc)
    addon_keymaps.clear()


# CONSENT / AUTORUN

def get_consent_textblock():
    return get_or_create_textblock(CONSENT_TEXTBLOCK)


class DATA_LOGGER_OT_ConsentPopup(bpy.types.Operator):
    bl_idname = "wm.data_logger_consent"
    bl_label = TRANSLATIONS["en"]["consent_title"]

    def execute(self, context):
        consent_text = get_consent_textblock()
        consent_text.clear()
        consent_text.write("ACCEPTED")
        consent_text.use_fake_user = True
        start_logger()
        self.report({'INFO'}, tr("consent_accept", context))
        return {'FINISHED'}

    def cancel(self, context):
        # If the user cancels, consent is not stored
        # and data capture does not start.
        clear_consent()
        self.report({'INFO'}, tr("consent_cancel", context))
        return {'CANCELLED'}

    def invoke(self, context, event):
        wm = context.window_manager
        available = _available_ui_width(context, fallback=620)
        width = max(460, min(680, int(available * 0.86)))
        return wm.invoke_props_dialog(self, width=width, title=tr("consent_title", context))

    def draw(self, context):
        layout = self.layout
        width_px = max(390, _available_ui_width(context, fallback=620) - 54)
        _draw_wrapped(layout, tr("consent_q", context), context, width_px=width_px)
        _draw_wrapped(layout, tr("consent_detail", context), context, width_px=width_px)
        _draw_wrapped(layout, tr("consent_save", context), context, width_px=width_px)


class DATA_LOGGER_OT_AutoRunWarning(bpy.types.Operator):
    bl_idname = "wm.data_logger_autorun_warning"
    bl_label = TRANSLATIONS["en"]["autorun_title"]
    _timer = None

    def modal(self, context, event):
        if bpy.context.preferences.filepaths.use_scripts_auto_execute:
            wm = context.window_manager
            wm.event_timer_remove(self._timer)
            bpy.ops.wm.data_logger_consent('INVOKE_DEFAULT')
            return {'FINISHED'}
        return {'PASS_THROUGH'}

    def execute(self, context):
        bpy.ops.screen.userpref_show('INVOKE_DEFAULT')
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        return {'CANCELLED'}

    def invoke(self, context, event):
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.5, window=context.window)
        wm.modal_handler_add(self)
        return wm.invoke_props_dialog(self, width=450)

    def draw(self, context):
        layout = self.layout
        layout.label(text=tr("autorun_disabled", context), icon='ERROR')
        layout.separator()
        layout.label(text=tr("autorun_path", context))
        layout.separator()
        layout.label(text=tr("autorun_wait", context))


@persistent
def check_consent_on_load(dummy):
    # When a .blend file is opened, stop any previous capture before checking
    # whether this file has consent.
    hard_stop_logger_on_file_load()

    # With consent disabled, never auto-start and never show a popup.
    # Recording can begin only through the Start Logger button.
    if not ENABLE_CONSENT_FLOW:
        return

    # Show nothing while installing/enabling the add-on or in the initial unsaved file.
    # Consent is requested only when opening a saved .blend file.
    if not bpy.data.filepath:
        return

    prefs = bpy.context.preferences.filepaths

    if not prefs.use_scripts_auto_execute:
        bpy.app.timers.register(
            lambda: bpy.ops.wm.data_logger_autorun_warning('INVOKE_DEFAULT'),
            first_interval=0.5
        )
        return

    if has_accepted_consent():
        start_logger()
    else:
        request_consent_popup(delay=0.5, only_if_saved_file=True)


# HANDLERS

@persistent
def handle_save(dummy):
    # CSV persistence is safe in Edit Mode because it never traverses geometry.
    # The expensive mesh-metric export is deferred until a later save outside
    # Edit Mode; this prevents save_pre from touching Blender's live edit mesh.
    if not ENABLE_CONSENT_FLOW or has_accepted_consent():
        remove_duplicate_rows()
        import_csv_to_blend()
    if not mesh_edit_mode_active():
        save_scene_mesh_metrics()




def _ui_scale(context):
    """Return Blender UI scale safely."""
    try:
        return max(0.5, float(context.preferences.system.ui_scale))
    except Exception:
        return 1.0


def _available_ui_width(context, fallback=420):
    """Estimate the usable width of the current region or window in UI pixels."""
    try:
        region = getattr(context, "region", None)
        if region is not None and getattr(region, "width", 0):
            return max(180, int(region.width / _ui_scale(context)))
        window = getattr(context, "window", None)
        if window is not None and getattr(window, "width", 0):
            return max(180, int(window.width / _ui_scale(context)))
    except Exception:
        pass
    return fallback


def _wrap_text(text, context, width_px=None, min_chars=18, max_chars=96):
    """Wrap UI text according to the current Blender region and interface scale."""
    if width_px is None:
        width_px = _available_ui_width(context)
    # Blender's default UI font averages roughly 7 px per character.
    chars = int(max(min_chars, min(max_chars, (width_px - 34) / 7.0)))
    words = str(text).split()
    lines, line = [], ""
    for word in words:
        candidate = f"{line} {word}".strip()
        if line and len(candidate) > chars:
            lines.append(line)
            line = word
        else:
            line = candidate
    if line:
        lines.append(line)
    return lines or [""]


def _draw_wrapped(layout, text, context, icon='NONE', width_px=None):
    """Draw wrapped labels without assuming a fixed Blender window width."""
    for index, line in enumerate(_wrap_text(text, context, width_px=width_px)):
        layout.label(text=line, icon=icon if index == 0 else 'NONE')

# PANEL AND EXPORT

class DATA_LOGGER_OT_Help(bpy.types.Operator):
    """Show extensive localized documentation for the add-on."""
    bl_idname = "wm.data_logger_help"
    bl_label = TRANSLATIONS["en"]["help_title"]
    bl_description = TRANSLATIONS["en"]["help"]

    dialog_width: bpy.props.IntProperty(default=640, options={'HIDDEN'})

    @classmethod
    def description(cls, context, properties):
        """Return the icon tooltip in the language selected for this scene."""
        return tr("help", context)

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        
        # Keep the help usable on small windows and HiDPI displays.
        available = _available_ui_width(context, fallback=720)
        width = max(420, min(720, int(available * 0.82)))
        self.dialog_width = width
        return context.window_manager.invoke_props_dialog(
            self,
            width=width,
            title=tr("help_title", context),
        )

    def draw(self, context):
        layout = self.layout
        help_keys = ["help_intro", "help_save", "help_metrics"]
        help_keys.append("help_privacy" if ENABLE_CONSENT_FLOW else "help_manual_start")
        for key in help_keys:
            box = layout.box()
            col = box.column(align=True)
            col.scale_y = 0.9
            text = tr(key, context)
            # Wrap to the dialog width, not to the 3D View behind it.
            _draw_wrapped(col, text, context, width_px=max(320, self.dialog_width - 44))


class DATA_LOGGER_OT_HelpES(bpy.types.Operator):
    """Spanish-title variant so Blender's tooltip title follows the add-on language."""
    bl_idname = "wm.data_logger_help_es"
    bl_label = "Ayuda contextual"
    bl_description = "Abrir ayuda detallada"

    dialog_width: bpy.props.IntProperty(default=640, options={'HIDDEN'})

    @classmethod
    def description(cls, context, properties):
        return tr("help", context)

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        available = _available_ui_width(context, fallback=720)
        width = max(420, min(720, int(available * 0.82)))
        self.dialog_width = width
        return context.window_manager.invoke_props_dialog(
            self, width=width, title=tr("help_title", context),
        )

    def draw(self, context):
        layout = self.layout
        help_keys = ["help_intro", "help_save", "help_metrics"]
        help_keys.append("help_privacy" if ENABLE_CONSENT_FLOW else "help_manual_start")
        for key in help_keys:
            box = layout.box()
            col = box.column(align=True)
            col.scale_y = 0.9
            _draw_wrapped(col, tr(key, context), context, width_px=max(320, self.dialog_width - 44))



class DATA_LOGGER_PT_Panel(bpy.types.Panel):
    bl_label = TRANSLATIONS["en"]["title"]
    bl_idname = "DATA_LOGGER_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Ize Logger"

    def draw_header_preset(self, context):
        # draw_header() is rendered before the panel title.  The preset slot is
        # Blender's dedicated trailing/right side of the header.
        self.layout.operator("wm.data_logger_help_es" if current_language(context) == "es" else "wm.data_logger_help", text="", icon='INFO', emboss=False)

    def draw(self, context):
        layout = self.layout

        available_width = _available_ui_width(context)
        if available_width < 250:
            language_col = layout.column(align=True)
            language_col.label(text=tr("language", context), icon='WORLD')
            language_col.prop(context.scene, "data_logger_language", text="")
        else:
            language_row = layout.row(align=True)
            language_row.label(text=tr("language", context), icon='WORLD')
            language_row.prop(context.scene, "data_logger_language", text="")

        variant_key = "variant_manual"
        layout.label(text=tr(variant_key, context), icon='INFO_LARGE')

        box = layout.box()
        box.label(text=tr("status", context))
        box.label(text=tr("running", context) if timer_running else tr("stopped", context))

        button_text = tr("stop", context) if timer_running else tr("start", context)
        button_icon = "PAUSE" if timer_running else "PLAY"
        box.operator("wm.data_logger_toggle", text=button_text, icon=button_icon)

        layout.separator()
        layout.label(text=tr("export", context))
        layout.operator("wm.data_logger_export_csv", text=tr("export_csv", context), icon="EXPORT")
        layout.operator("wm.data_logger_export_csv_anonymous", text=tr("export_anon", context), icon="EXPORT")

        layout.separator()
        layout.label(text=tr("mesh_metrics_section", context))
        layout.operator(
            "wm.data_logger_export_mesh_metrics",
            text=tr("export_mesh_metrics", context),
            icon="MESH_DATA",
        )

        layout.separator()
        layout.label(text=tr("privacy", context))
        layout.operator("wm.data_logger_reset_user_id", text=tr("reset_id", context), icon="FILE_REFRESH")
        if ENABLE_CONSENT_FLOW:
            layout.operator("wm.data_logger_clear_consent", text=tr("clear_consent", context), icon="X")
        layout.operator("wm.data_logger_clear_logged_data", text=tr("clear_data", context), icon="TRASH")


class DATA_LOGGER_PT_DebugPanel(bpy.types.Panel):
    bl_label = TRANSLATIONS["en"]["debug"]
    bl_idname = "DATA_LOGGER_PT_debug_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Ize Logger"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return bool(SHOW_DEBUG_PANEL)

    def draw(self, context):
        layout = self.layout

        col = layout.column(align=True)
        col.label(text=f"{tr('timer', context)}: {'ON' if timer_running else 'OFF'}")
        col.label(text=f"{tr('last_operator', context)}: {DEBUG_LAST_OPERATOR or '-'}")
        col.label(text=f"{tr('last_reason', context)}: {DEBUG_LAST_LOG_REASON or '-'}")
        col.label(text=f"{tr('last_rebase', context)}: {DEBUG_LAST_REBASE_REASON or '-'}")
        col.separator()
        col.label(text=f"{tr('uv_tracking', context)}: {'ON' if ENABLE_UV_CHANGE_TRACKING else 'OFF'}")
        col.label(text=f"{tr('uv_pending', context)}: {DEBUG_UV_PENDING}")
        col.separator()
        col.label(text=DEBUG_LAST_FLAGS)
        col.separator()
        col.label(text=f"{tr('active_object', context)}: {get_active_object_name() or '-'}")
        col.label(text=f"{tr('mode', context)}: {bpy.context.mode}")
        col.separator()
        col.label(text=tr("warnings", context))
        for warning in _WARNINGS[-5:]:
            col.label(text=warning[:90])


def _export_csv_content(context, operator, anonymize=False):
    # Synchronize the incremental temporary log before exporting.
    if timer_running and os.path.exists(TEMP_CSV_PATH):
        remove_duplicate_rows()
        import_csv_to_blend()
    blend_path = bpy.data.filepath

    if not blend_path:
        operator.report({'ERROR'}, "Save the .blend file before exporting.")
        return {'CANCELLED'}

    if DATA_TEXTBLOCK not in bpy.data.texts:
        operator.report({'ERROR'}, "There is no embedded CSV to export.")
        return {'CANCELLED'}

    content = bpy.data.texts[DATA_TEXTBLOCK].as_string()
    if not content.strip():
        operator.report({'WARNING'}, "The CSV is empty.")
        return {'CANCELLED'}

    content = upgrade_csv_content_to_current(content)
    if anonymize:
        content = strip_user_id_from_csv(content)

    directory = os.path.dirname(blend_path)
    suffix = "_data_anon.csv" if anonymize else "_data.csv"
    filename = os.path.splitext(os.path.basename(blend_path))[0] + suffix
    csv_path = os.path.join(directory, filename)

    try:
        with open(csv_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(content)
    except Exception as exc:
        log_warning("Could not save the exported CSV", exc)
        operator.report({'ERROR'}, f"Could not save the CSV: {exc}")
        return {'CANCELLED'}

    operator.report({'INFO'}, f"Data exported successfully: {csv_path}")
    return {'FINISHED'}


class DATA_LOGGER_OT_ExportCSV(bpy.types.Operator):
    """Export the logger CSV beside the current .blend file."""
    bl_idname = "wm.data_logger_export_csv"
    bl_label = TRANSLATIONS["en"]["export_csv"]
    bl_description = TRANSLATIONS["en"]["export_csv_tip"]

    @classmethod
    def description(cls, context, properties):
        return tr("export_csv_tip", context)

    def execute(self, context):
        return _export_csv_content(context, self, anonymize=False)


class DATA_LOGGER_OT_ExportCSVAnonymous(bpy.types.Operator):
    """Export the CSV after removing the UserID column."""
    bl_idname = "wm.data_logger_export_csv_anonymous"
    bl_label = TRANSLATIONS["en"]["export_anon"]
    bl_description = TRANSLATIONS["en"]["export_anon_tip"]

    @classmethod
    def description(cls, context, properties):
        return tr("export_anon_tip", context)

    def execute(self, context):
        return _export_csv_content(context, self, anonymize=True)


def _export_mesh_metrics_csv(context, operator):
    """Calculate current scene mesh metrics and export them beside the .blend."""
    blend_path = bpy.data.filepath

    if not blend_path:
        operator.report({'ERROR'}, tr("mesh_metrics_no_blend", context))
        return {'CANCELLED'}

    try:
        # Recalculate now so the button always exports the current scene state.
        save_scene_mesh_metrics()

        if MESH_METRICS_CSV_TEXTBLOCK not in bpy.data.texts:
            operator.report({'ERROR'}, tr("mesh_metrics_empty", context))
            return {'CANCELLED'}

        content = bpy.data.texts[MESH_METRICS_CSV_TEXTBLOCK].as_string()
        if not content.strip():
            operator.report({'ERROR'}, tr("mesh_metrics_empty", context))
            return {'CANCELLED'}

        directory = os.path.dirname(blend_path)
        blend_name = os.path.splitext(os.path.basename(blend_path))[0]
        csv_path = os.path.join(directory, f"{blend_name}_mesh_metrics.csv")

        with open(csv_path, "w", encoding="utf-8", newline="") as handle:
            handle.write(content)

        operator.report(
            {'INFO'},
            f"{tr('mesh_metrics_saved', context)}: {csv_path}"
        )
        return {'FINISHED'}

    except Exception as exc:
        log_warning("Could not export mesh metrics CSV", exc)
        operator.report(
            {'ERROR'},
            f"{tr('mesh_metrics_error', context)}: {exc}"
        )
        return {'CANCELLED'}


class DATA_LOGGER_OT_ExportMeshMetrics(bpy.types.Operator):
    """Calculate and export the current scene mesh metrics to CSV."""
    bl_idname = "wm.data_logger_export_mesh_metrics"
    bl_label = TRANSLATIONS["en"]["export_mesh_metrics_label"]

    @classmethod
    def description(cls, context, properties):
        return tr("export_mesh_metrics_tip", context)

    def execute(self, context):
        return _export_mesh_metrics_csv(context, self)


class DATA_LOGGER_OT_ResetUserID(bpy.types.Operator):
    """Replace the current UserID with a new random UUID."""
    bl_idname = "wm.data_logger_reset_user_id"
    bl_label = TRANSLATIONS["en"]["reset_user_id_label"]
    bl_description = TRANSLATIONS["en"]["reset_id_tip"]

    @classmethod
    def description(cls, context, properties):
        return tr("reset_id_tip", context)

    def execute(self, context):
        new_id = reset_user_id()
        self.report({'INFO'}, f"{tr('new_user_id', context)}: {new_id[:8]}...")
        return {'FINISHED'}


class DATA_LOGGER_OT_ClearConsent(bpy.types.Operator):
    """Clear the current runtime consent."""
    bl_idname = "wm.data_logger_clear_consent"
    bl_label = TRANSLATIONS["en"]["clear_consent_label"]
    bl_description = TRANSLATIONS["en"]["clear_consent_tip"]

    @classmethod
    def description(cls, context, properties):
        return tr("clear_consent_tip", context)

    def execute(self, context):
        clear_consent()
        self.report({'INFO'}, tr("consent_cleared", context))
        return {'FINISHED'}


class DATA_LOGGER_OT_ClearLoggedData(bpy.types.Operator):
    """Delete the logger data for the current session/file."""
    bl_idname = "wm.data_logger_clear_logged_data"
    bl_label = TRANSLATIONS["en"]["clear_data_label"]
    bl_description = TRANSLATIONS["en"]["clear_data_tip"]

    @classmethod
    def description(cls, context, properties):
        return tr("clear_data_tip", context)

    def execute(self, context):
        clear_logged_data()
        self.report({'INFO'}, tr("logger_data_cleared", context))
        return {'FINISHED'}


# REGISTRATION

classes = [
    VIEW3D_OT_undo_logger,
    VIEW3D_OT_duplicate_logger,
    VIEW3D_OT_instance_logger,
    VIEW3D_OT_paste_logger,
    WM_OT_data_logger_toggle,
    DATA_LOGGER_OT_ConsentPopup,
    DATA_LOGGER_OT_AutoRunWarning,
    DATA_LOGGER_OT_Help,
    DATA_LOGGER_OT_HelpES,
    DATA_LOGGER_PT_Panel,
    DATA_LOGGER_PT_DebugPanel,
    DATA_LOGGER_OT_ExportCSV,
    DATA_LOGGER_OT_ExportCSVAnonymous,
    DATA_LOGGER_OT_ExportMeshMetrics,
    DATA_LOGGER_OT_ResetUserID,
    DATA_LOGGER_OT_ClearConsent,
    DATA_LOGGER_OT_ClearLoggedData,
]


def register():
    bpy.types.Scene.data_logger_language = bpy.props.EnumProperty(
        name="Language / Idioma",
        description="Interface language / Idioma de la interfaz",
        items=[
            ('en', "English", "Use the interface in English"),
            ('es', "Español", "Usar la interfaz en español"),
        ],
        default='en',
    )

    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.TOPBAR_HT_upper_bar.append(draw_recording_indicator)
    register_keymaps()

    if check_consent_on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(check_consent_on_load)

    if handle_save not in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.append(handle_save)

    if operator_tracker not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(operator_tracker)

    if undo_tracker not in bpy.app.handlers.undo_post:
        bpy.app.handlers.undo_post.append(undo_tracker)

    # Do not call check_consent_on_load() during register().
    # This prevents the consent dialog from appearing during installation or activation.
    # The popup is shown from load_post when a saved .blend file is reopened.

    print("Data Logger loaded successfully.")


def unregister():
    unregister_keymaps()

    if hasattr(bpy.types.Scene, "data_logger_language"):
        del bpy.types.Scene.data_logger_language

    try:
        bpy.types.TOPBAR_HT_upper_bar.remove(draw_recording_indicator)
    except Exception:
        pass

    if check_consent_on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(check_consent_on_load)

    if handle_save in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.remove(handle_save)

    if operator_tracker in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(operator_tracker)

    if undo_tracker in bpy.app.handlers.undo_post:
        bpy.app.handlers.undo_post.remove(undo_tracker)

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception as exc:
            log_warning(f"Could not unregister class {getattr(cls, '__name__', cls)}", exc)


if __name__ == "__main__":
    register()
